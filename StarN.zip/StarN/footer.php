 <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>Copyright &copy; <a href="delinnova.com">Delinnova Technology Solutions</a></p>
                </div>
            </div>
        </div>
    </footer>