<!DOCTYPE html>
<html lang="en">

<head>


</head>

<body>
	<?php include 'header.php';?>

    <div class="container">


   <div class="row">
           <div class="box">
            <div class="row text-center">
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Enterprise Solutions</h4>
                    <p class="text-muted">ERP</p>
					<p class="text-muted">CRM</p>
					<p class="text-muted">Consulting</p>
					<p class="text-muted">Development</p>
					<p class="text-muted">QA</p>
                </div>
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Products</h4>
                    <p class="text-muted">SalesBolt</p>
					<p class="text-muted">PharmaBolt</p>
					<p class="text-muted">TextiBolt</p>
					<p class="text-muted">HospoBolt</p>
					<p class="text-muted">ConstroBolt</p>
					<p class="text-muted">EducaBolt</p>
					<p class="text-muted">GoverBolt</p>
                </div>
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Security Services</h4>
                    <p class="text-muted">Secure your Business against Digital threats</p>

                </div>
				<div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Security Services</h4>
                    <p class="text-muted">Secure your Business against Digital threats</p>
				</div>
			</div>
       </div>
   </div> 
<div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center">Our
                        <strong>Team</strong>
                    </h2>
                    <hr>
                </div>
                <div class="col-sm-4 text-center">
                    <img class="img-responsive" src="http://placehold.it/750x450" alt="">
                    <h3>John Smith
                        <small>Job Title</small>
                    </h3>
                </div>
                <div class="col-sm-4 text-center">
                    <img class="img-responsive" src="http://placehold.it/750x450" alt="">
                    <h3>John Smith
                        <small>Job Title</small>
                    </h3>
                </div>
                <div class="col-sm-4 text-center">
                    <img class="img-responsive" src="http://placehold.it/750x450" alt="">
                    <h3>John Smith
                        <small>Job Title</small>
                    </h3>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <!-- /.container -->

     <?php include 'footer.php';?>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
