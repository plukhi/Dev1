package com.converter;

public class TestXml {

	public static void main(String[] args) {
		
		XMLCreators xml=new XMLCreators();
		xml.convertFile("C:\\Parth\\ring\\testcsv.csv", "C:\\Parth\\ring\\xmlfilename", ",");

	}

}
