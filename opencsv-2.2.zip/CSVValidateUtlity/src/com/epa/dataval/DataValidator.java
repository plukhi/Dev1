package com.epa.dataval;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import org.ini4j.Ini;
import org.ini4j.Ini.Section;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

import com.csvreader.CsvWriter;


public class DataValidator {

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Properties prop = new Properties();
		InputStream input = null;
		String[] fields=null;
		String[] pattern=null;
		int fieldCount=0;
		BufferedReader br=null;
		String line=null;
		final String SPLIT_BY = ",";
		File outputFile = null;
		final String FILE="File";		
		CsvWriter csvOutput= null;
		Map<Integer,String> map =new HashMap<Integer,String>(); 
		Object[] setIndex=null;
		Integer[] arrIndexHeader=null;
		StringBuffer patternString=new StringBuffer();
		String validationMessage=null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		CsvListReader csvReader = null;
		CsvListWriter csvWriter = null;
		File file=null;
		List<String> columns=null;
		List<String> errMessage=null;
		boolean createErrFile = false;
		Long start=System.currentTimeMillis();
		int rowNumber=1;
		StringBuffer fileName=new StringBuffer("");
		 Ini ini = null;
		 int i=0;
		 String outputFolder="";
		try {
			input = new FileInputStream("C:\\home\\validation.properties");
			System.out.println(args[0]);
			if(args[0].toString().contains(".csv")){
				args[0]=args[0];
			}else{
				args[0]=args[0]+".csv";
			}
					
			file=new File(args[0]);
			
			 ini = new Ini();
			 ini.load(input);
			// Section section = ini.get("header");  // "dev", "prod", etc.
			 //System.out.println(section.get("key"));
			 for (String sectionName: ini.keySet()) {
				 //System.out.println(file.getParentFile().getName());
				 /*if(sectionName.equalsIgnoreCase(file.getName().replaceFirst("[.][^.]+$", ""))){*/
				 if(sectionName.equalsIgnoreCase(file.getParentFile().getName())){
					 Section section = ini.get(sectionName);
					 outputFolder=sectionName;
						Set<String> keys = section.keySet();
						// get the property value and print it out	
						fieldCount=keys.size();
						fields=new String[fieldCount];
						pattern=new String[fieldCount];
						 i=0;
						for(String k:keys){
							String key = k;
								fields[i]=key;
								pattern[i]=section.get(key);
								i++;
						}
			    		/*for (String optionKey: section.keySet()) {
			    			System.out.println("\t"+optionKey+"="+section.get(optionKey));
			    		}*/
					 
				 }
		    		
		    	}
			
			/* input.close();
			 input = new FileInputStream("C:\\home\\CompanyMaster.properties");
			 ini.clear();
			 ini.load(input);
			 for (String sectionName: ini.keySet()) {
				 //System.out.println(file.getParentFile().getName());
				 if(sectionName.equalsIgnoreCase(file.getName().replaceFirst("[.][^.]+$", ""))){
				 if(sectionName.equalsIgnoreCase(file.getParentFile().getName())){
					 Section section = ini.get(sectionName);
					 outputFolder=sectionName;
						Set<String> keys = section.keySet();
						// get the property value and print it out	
						fieldCount=keys.size();
						fields=new String[fieldCount];
						pattern=new String[fieldCount];
						 i=0;
						for(String k:keys){
							String key = k;
								fields[i]=key;
								pattern[i]=section.get(key);
								i++;
						}
			    		for (String optionKey: section.keySet()) {
			    			System.out.println("\t"+optionKey+"="+section.get(optionKey));
			    		}
					 
				 }
		    		
		    	}
			
			*/
			i=0;
		
			File	file1=new File("C:\\home\\DataFileResult\\"+outputFolder+"\\"+file.getName());
		
			//File	file1=new File("C:\\home\\DataFile\\"+file.getName());
			br = new BufferedReader(new FileReader(file));  
			csvReader=new CsvListReader(new FileReader(file), CsvPreference.STANDARD_PREFERENCE);
			line = br.readLine();
			String[] headerdataRow = line.split(SPLIT_BY);
			validationMessage ="";
			for(int propCount=0;propCount<fieldCount;propCount++){
				for(int headerCount=0;headerCount<headerdataRow.length;headerCount++){
					if(fields[propCount].equalsIgnoreCase(headerdataRow[headerCount])){
						//map.put(pattern[propCount], headerCount);
						map.put(headerCount,pattern[propCount]);
						break;
					}else{
						//Error
					}
				}
			}
			setIndex=map.keySet().toArray();
			if(setIndex !=null && setIndex.length!=0){
				arrIndexHeader=new Integer[setIndex.length];
			}
			i=0;
			for(Object lIndex : setIndex){
				arrIndexHeader[i]=(Integer) lIndex;
				i++;
			}

			errMessage=new ArrayList<String>();
			errMessage.add("Error");
			if(arrIndexHeader!=null && arrIndexHeader.length>0){
				rowNumber=0;
				while ((line = br.readLine()) != null) {
					boolean result=true;
					validationMessage ="";
					//String[] dataRow = line.split(SPLIT_BY); 
					//str.split("(?<!\\\\), ");
					//String[] dataRow = line.split("(?<!\\\\), ");
					String[] dataRow = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1);
					int headerCnt=arrIndexHeader.length;
				
					i=0;
					
					//System.out.println(rowNumber);
					for(i=0;i<headerCnt;i++){
						
					 int localInt=(int) setIndex[i];
					//System.out.println(map.get(localInt));
					 try{
						 result=validate(map.get(localInt).toString(),dataRow[localInt]);
						 if(result!=true){
								validationMessage=validationMessage+headerdataRow[localInt]+" is invalid ";
							}
					 }catch(Exception ex){
						 File errorLog=new File("C:\\home\\DataFileResult\\ErrorFiles.txt");
							PrintStream ps = null;
							try {
								ps = new PrintStream(errorLog);
							} catch (FileNotFoundException e) {
								JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
								e.printStackTrace(ps);
							}
							ps.append("Error in File "+file.getName());
							ps.println();
							ex.printStackTrace(ps);ps.println();
							ps.flush();
							ps.close();
					
						 
					 }
					 
					 
					}
					if(validationMessage.equalsIgnoreCase("")){
						errMessage.add("Valid");
					}else{
						errMessage.add(validationMessage);
						createErrFile=true;
					}
					//System.out.println("Time taken  :"+((System.currentTimeMillis()-start)/1000));
					//csvOutput.writeRecord(new String[]{Integer.toString(rowNumber),validationMessage});
					rowNumber++;
				}
				
			}else{
				JOptionPane.showMessageDialog(null,"Please Check your validation.property");
			}
			
			rowNumber=0;
			if(createErrFile){
				file1.getParentFile().mkdir();
				file1.createNewFile();

				csvWriter=new CsvListWriter(new FileWriter(file1), CsvPreference.STANDARD_PREFERENCE);
				while ((columns = csvReader.read()) != null) {
			    columns.add(errMessage.get(rowNumber));
			    csvWriter.write(columns);
			    rowNumber++;
			}
			csvReader.close();
			csvWriter.close();
			//thdataRow new Exception("Date format is not valid"); 
			if(br !=null){
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			file.delete();
			}
			} catch (IOException ex) {
				ex.printStackTrace();
				File errorLog=new File("C:\\home\\DataFileResult\\ErrorStack.txt");
				PrintStream ps = null;
				try {
					ps = new PrintStream(errorLog);
				} catch (FileNotFoundException e) {
					JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
					e.printStackTrace(ps);
				}
				ex.printStackTrace(ps);
				ps.flush();
				ps.close();
		} catch (Exception ex) {
			
			File errorLog=new File("C:\\home\\DataFileResult\\ErrorStack.txt");
			PrintStream ps = null;
			try {
				ps = new PrintStream(errorLog);
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
				e.printStackTrace(ps);
			}
			ex.printStackTrace(ps);
			ps.flush();
			ps.close();
	} finally {
			if(br !=null){
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(	csvOutput!=null){
				csvOutput.flush();
				csvOutput.close();
			}

		}

	}

	private static void exit(int i) {
	
		
	}

	private static boolean validate(String reg, String dataFiled) {
		String regex=reg;
		String ldata=dataFiled;
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(ldata);
		//System.out.println(ldata+" is  like "+pattern+" "+matcher.matches());
		return  matcher.matches();
	}


}
