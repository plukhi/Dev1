'use strict';

/**
 * @ngdoc service
 * @name angularGanttDemoApp.Sample
 * @description
 * # Sample
 * Service in the angularGanttDemoApp.
 */
angular.module('angularGanttDemoApp')
    .service('Sample', function Sample() {
        return {
            getSampleData: function() {
                return [
                        // Order is optional. If not specified it will be assigned automatically
                        
                        {name: 'Documentation', tasks: [
                            {name: 'Technical/User documentation', color: '#F1C232', from: new Date(2013, 10, 26, 8, 0, 0), to: new Date(2013, 10, 28, 18, 0, 0),fromActual:new Date(2013, 10, 26, 8, 0, 0),toActual:new Date(2013, 10, 25, 8, 0, 0),est: new Date(2013, 10, 26, 7, 0, 0), lct: new Date(2013, 10, 28, 0, 0, 0)}
                        ]},
                        {name: 'Status meetings', tasks: [
                            {name: 'Demo #1', color: '#9FC5F8', from: new Date(2013, 10, 25, 15, 0, 0), to: new Date(2013, 10, 25, 18, 30, 0)}
                            
                        ]}
                    ];
            },
            getSampleTimespans: function() {
                return [
                        {
                            from: new Date(2013, 9, 21, 8, 0, 0),
                            to: new Date(2013, 9, 25, 15, 0, 0),
                            name: 'Sprint 1 Timespan'
                            //priority: undefined,
                            //classes: [],
                            //data: undefined
                        }
                    ];
            }
        };
    })
;
