﻿(function () {
    'use strict';

    angular
        .module('delinnovaDemo')
        .controller('CSVDefController', CSVDefController);
		
		

    CSVDefController.$inject = ['$scope','$location','$window','$http','$route'];
    function CSVDefController($scope,$location, $window,$http,$route) {
		  
			var vm = this;
			
		    vm.myFunc = myFunc;
			$scope.data=[[{'indexNo':'','headerName':''}]];
			$scope.valid=true;
				   
	  $scope.removeRow = function(index){
				// remove the row specified in index
				$scope.data.splice( index, 1);
				// if no rows left in the array create a blank array
				if ($scope.data.length === 0){
				  $scope.data = [];
				}
			  };
			  
	//add a row in the array
			  $scope.addRow = function(){
				// create a blank array
				var newrow =[];
					console.log($scope.data.length) 
				  // if array is blank add a standard item
				  if ($scope.data.length === 0) {
					    
					newrow = [{'indexNo':'','headerName':''}];
				  } else {
					// else cycle thru the first row's columns
					// and add the same number of items
					
						newrow.push({'indexNo':'','headerName':''});
				
				  }
			
				// add the new row at the end of the array 
				$scope.data.push(newrow);
			  };
			  
			  $scope.submit = function() {
	
				  if ($scope.data.length === 0) {
					 $scope.valid=false;
				     $scope.validMessage="Please enter some definition";
					return false;
				  }else{
					  	var src_index_arr = [];
						var src_header_arr = [];
					    $scope.data.forEach(function (row) {
							row.forEach(function (subrow) {
								src_index_arr.push(subrow.indexNo);
								src_header_arr.push(subrow.headerName);
							});
						});
						
						var results=[];
						for (var i = 0; i <= src_index_arr.length - 1; i++) {
						if (src_index_arr[i]=='') {
							$scope.valid=false;
							$scope.validMessage="Please enter index";
							return false;
						}
						if (src_index_arr[i + 1] == src_index_arr[i]) {
							results.push(src_index_arr[i]);
						}
					}
					
					if(results.length!=0){
					
						$scope.valid=false;
						$scope.validMessage="Please check column index";
						return false;
					}
					
						var results=[];
					for (var i = 0; i <= src_header_arr.length - 1; i++) {
							if (src_header_arr[i]=='') {
							$scope.valid=false;
							$scope.validMessage="Please enter header";
							return false;
						}
						if (src_header_arr[i + 1] == src_header_arr[i]) {
							results.push(src_header_arr[i]);
						}
					}
					  
				  if(results.length!=0){
					
						 $scope.valid=false;
						$scope.validMessage="Please check Header Name";
						return false;
					}
				  }
				  		
				  $scope.valid=true;
				  $scope.post();
				  return true;
			};

			
			 $scope.post = function() {
					console.log($scope.data);
					$scope.json = angular.toJson($scope.data);
						console.log($scope.json);
						var dataObj = $.param({
								reqParam: $scope.json
							});
						
					var config = {
						headers : {
							'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
						}
					}
					  var res = $http.post('/savecompany_json', dataObj);
							res.success(function(data, status, headers, config) {
								$scope.message = data;
							});
							res.error(function(data, status, headers, config) {
								alert( "failure message: " + JSON.stringify({data: data}));
							});	

				
			 };
        (function initController() {
            // reset login status
            //AuthenticationService.ClearCredentials();
        })();

		   $scope.reset = function() {
			   $route.reload();
		   };
		 function myFunc() {
			 
		
        };
    }

})();
