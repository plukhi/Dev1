﻿(function () {
    'use strict';

    angular
        .module('delinnovaDemo')
        .controller('CSVRuleController', CSVRuleController);
		
		

    CSVRuleController.$inject = ['$scope','$location','$window'];
    function CSVRuleController($scope,$location,$window) {
		  
		var vm = this;
		$scope.valid=true;
	     $scope.data=[[{'cell':'','value':''}]];	
		
        (function initController() {
            // reset login status
            //AuthenticationService.ClearCredentials();
        })();

         $scope.addColumn = function(){
			$scope.data.forEach(function($row){
			  $row.push({"en":""})
			});
		  };
    }

})();
