﻿(function () {
    'use strict';

    angular
        .module('delinnovaDemo')
        .controller('HomeController', HomeController);
		
		

    HomeController.$inject = ['$scope','$location','$window','$http'];
    function HomeController($scope,$location, $window,$http) {
		  
		
        (function initController() {
            // reset login status
            //AuthenticationService.ClearCredentials();
        })();

  
		
		 function myFunc() {
			 
		
        };
    }

})();
