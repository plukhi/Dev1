﻿(function () {
    'use strict';

    angular
        .module('delinnovaDemo')
        .controller('LoginController', LoginController);
		
		

    LoginController.$inject = ['$scope','$location','AuthenticationService', 'FlashService','Session','$window'];
    function LoginController($scope,$location, AuthenticationService, FlashService,Session,$window) {
		  
			var vm = this;
			vm.login = login;
		    vm.myFunc = myFunc;
			
		$scope.session = Session;
        (function initController() {
            // reset login status
            //AuthenticationService.ClearCredentials();
        })();

        function login() {
	
            vm.dataLoading = true;
            /*AuthenticationService.Login(vm.username, vm.password, function (response) {
                if (response.success) {
                    AuthenticationService.SetCredentials(vm.username, vm.password);
                    $location.path('/');
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });*/
			AuthenticationService.SetCredentials(vm.username, vm.password);
			Session.data.username='test';
			$location.path('/userrole');
			  
			 
        };
		
		 function myFunc() {
			 
			alert(Session.data.username);
			alert(vm.selectedRole);
            Session.data.role=vm.selectedRole;
			$window.location.href ='home/home.html';
			//$location.url ('test1/test');
        };
    }

})();
