﻿(function () {
    'use strict';

   var app= angular
        .module('delinnovaDemo',['ngRoute','ngCookies'])
        .config(config)
        .run(run);

		
    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/csvdef', {
                controller: 'CSVDefController',
                templateUrl: 'csv/views/csvdef.view.html',
                controllerAs: 'vm'
            })

          
			  .when('/csvrule', {
                controller: 'CSVRuleController',
                templateUrl: 'csv/views/csvrule.view.html',
                controllerAs: 'vm'
            })
			.when('/', {
                controller: 'CSVDefController',
                templateUrl: 'csv/views/home.view.html',
                controllerAs: 'vm'
            })
			  

           .otherwise({ redirectTo: '/' });
            
    }

       run.$inject = ['$rootScope', '$location', '$cookieStore', '$http'];
		function run($rootScope, $location, $cookieStore, $http) {
		
		

			$rootScope.$on('$locationChangeStart', function (event, next, current) {
			
			});
		}
})();