﻿(function () {
    'use strict';

    angular
        .module('delinnovaDemo')
        .factory('UserSessionService', UserSessionService);

		UserSessionService.$inject = ['$http'];
		function UserSessionService($http) {
			

         this.userData = {yearSetCount: 0};

		  this.user = function() {
				return this.userData;
		  };

		  this.setEmail = function(email) {
				this.userData.email = email;
		  };

		  this.getEmail = function() {
				return this.userData.email;
		  };

		  this.setSetCount = function(setCount) {
				this.userData.yearSetCount = setCount;
		  };

		  this.getSetCount = function() {
				return this.userData.yearSetCount;
		  };	

})();
