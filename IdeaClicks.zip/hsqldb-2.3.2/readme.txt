Readme File
2014/02/13-17:49:36
This package contains HyperSQL v. 2.3.2

HyperSQL is a relational database engine and a set of tools written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
