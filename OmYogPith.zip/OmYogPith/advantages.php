<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Yoga Advantages,Yoga Cure</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">
	  
      <!-- CUSTOM STYLE -->  
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>   
	  <meta name="description" content="Om Yog Pith,Surat,Yoga,Yoga Center,Great Advantages of Yoga" />
	<meta name="keywords" content="Yoga,Yoga Center,Yoga Point,Om Yog,Yog pith,Yog peeth,Stress release,Piecse,Manubhai Dhhola,Advantages,Cancer,Cholesterol,Stress,Diabetes,heart Problem,Asthma,Liver,haemoglobin,Joint Pain,Muscular Pain" />
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]-->
	  <style>
	  
			ul.advantages {
				margin-bottom: 14px;
				list-style: none;
				display: inline-block;
			}
			
			li a.linkAdv{ 
				
				width: 100%;
				height: 30px;
				margin: 0 0 7px 0;
				background: #F7F5F2 
				font-size: 18px;
				color: #333;
				padding: 5px 0 0 20px;
				text-decoration: none;
			}

			li a:hover { background-color: #EFEFEF;  }

			.orange { border-left: 5px solid #F5876E;  width: 100%; height: 30px;  margin: 0 0 7px 0; }

			.blue{ border-left: 5px solid #61A8DC;  width: 100%; height: 30px;  margin: 0 0 7px 0; }

			.green{ border-left: 5px solid #8EBD40;  width: 100%; height: 30px;  margin: 0 0 7px 0;}

			.purple { border-left: 5px solid #988CC3;  width: 100%; height: 30px;  margin: 0 0 7px 0;}

			.gold { border-left: 5px solid #D8C86E;  width: 100%; height: 30px;  margin: 0 0 7px 0; }
	  </style>
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->  
        <?php
        // do php stuff
        
        include('header.php');
     
        
        ?>
      <section>
         <div id="head">
            <div class="line">
               <h1>Great Advantages of Yoga</h1>
            </div>
         </div>
         <div id="content">
            <div class="line" >
			  
                    <h2>Yoga adds Value to meaning of life</h2>
					
					 <ul  class="advantages">
						<li class="orange"><a class="linkAdv" href="#">Enhance  flexibility</a></li>
						<li class="blue"><a href="#">Prevents cartilage and joint breakdown</a></li> 
						<li class="green"><a href="#"> Drops your blood pressure</a></li> 
						<li class="purple"><a href="#">Lowers blood sugar</a></li> 
						<li class="gold"><a href="#">Increases your blood flow</a></li> 
						<li class="orange"><a href="#">Founds a healthy lifestyle</a></li>
						<li class="blue"><a href="#">Drains your lymphs and boosts immunity</a></li> 
						<li class="green"><a href="#">  Relaxes your system </a></li> 
						<li class="purple"><a href="#">Helps keep you drug free</a></li> 
						<li class="gold"><a href="#">Helps you sleep deeper</a></li> 
						<li class="orange"><a href="#">Founds a healthy lifestyle</a></li>
						<li class="blue"><a href="#">Guides your body’s healing in your mind’s eye</a></li> 
						<li class="green"><a href="#"> Prevents cartilage and joint breakdown</a></li> 
						<li class="purple"><a href="#">Maintains your nervous system</a></li> 
						<li class="gold"><a href="#">Regulates your adrenal glands</a></li> 
						
					</ul>
                   
				
             
             
			</div>
			  <div class="line">
               <h2>Add On benefits of yoga against disease</h2>
			    <ul  class="advantages">
						<li class="orange"><a href="#">Diabetes</a></li>
						<li class="blue"><a href="#">Blood Pressure</a></li> 
						<li class="green"><a href="#"> Heart Problems</a></li> 
						<li class="purple"><a href="#"> Lung Problems</a></li> 
						<li class="gold"><a href="#">Stress Problems</a></li> 
						<li class="orange"><a href="#">Founds a healthy lifestyle</a></li>
					</ul>
			
				</div>
            </div>
         </div>
         <!-- GALLERY -->	
         
   
      </section>
      <!-- FOOTER -->   
       <?php
        // do php stuff
        
        include('footer.php');
     
        
        ?>
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>   
      <script type="text/javascript">
         jQuery(document).ready(function($) {  
           $("#owl-demo").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : false,
         	singleItem:true
           });
           $("#owl-demo2").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : true,
         	singleItem:true
           });
         });	
          
      </script> 
   </body>
</html>