  <!DOCTYPE html>
  <html lang="en-US">
     <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Please visit Om Yogi Pith Surat</title>
        <link rel="stylesheet" href="css/components.css">
        <link rel="stylesheet" href="css/responsee.css">
        <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
        <link rel="stylesheet" href="owl-carousel/owl.theme.css">
        <!-- CUSTOM STYLE -->  
        <link rel="stylesheet" href="css/template-style.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
        <script type="text/javascript" src="js/modernizr.js"></script>
        <script type="text/javascript" src="js/responsee.js"></script>   
        <!--[if lt IE 9]>
            <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
          <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->
     </head>
     <body class="size-1140">
        <!-- TOP NAV WITH LOGO -->  
         <!-- TOP NAV WITH LOGO -->  
          <?php
          // do php stuff
          
          include('header.php');
       
          
          ?>
        <section>
           <div id="head">
              <div class="line">
                 <h1>Om Yogi Pith, on the bank of SURYAPUTRY Tapi</h1>
              </div>
           </div>
           <div id="content" class="left-align contact-page">
              <div class="line">
                 <div class="margin">
                    <div class="s-12 l-6">
                       <h2>Om Yog Pith</h2>
                       <address>
                          <p><i class="icon-home icon"></i> Besides River Tapi and River View Appt,Mota Varachha ,Surat</p>
                          <p><i class="icon-globe_black icon"></i>Gujaat - India  </p>
                          <p><i class="icon-mail icon"></i> info@omyogpith.com</p>
                       </address>
                       <br />
                       <h2>Social</h2>
                       <p><i class="icon-facebook icon"></i> <a href="https://www.facebook.com/">Om Yog Pith Surat</a></p>
                       <p class="margin-bottom"><i class="icon-twitter icon"></i> <a href="https://twitter.com/MyResponsee">Om Yog Pith</a></p>
                    </div>
                   <!-- <div class="s-12 l-6">
                       <h2>Be In Touch</h2>
                       <form class="customform" action="">
                          <div class="s-12 l-7"><input name="" placeholder="Your e-mail" title="Your e-mail" type="text" /></div>
                          <div class="s-12 l-7"><input name="" placeholder="Your name" title="Your name" type="text" /></div>
                          <div class="s-12"><textarea placeholder="Your massage" name="" rows="5"></textarea></div>
                          <div class="s-12 m-6 l-4"><button type="submit">Submit Button</button></div>
                       </form>
                    </div> -->
                 </div>
              </div>
           </div>
           <!-- MAP -->	
           
          <div id="googleMap" style="height:400px;width:100%;"></div>
          
          <!-- Add Google Maps -->
          <script src="http://maps.googleapis.com/maps/api/js"></script>
          <script>
          var myCenter = new google.maps.LatLng(21.241801, 72.893562);
            
          function initialize() {
          var mapProp = {
            center:myCenter,
            zoom:12,
            scrollwheel:false,
            draggable:false,
            mapTypeId:google.maps.MapTypeId.ROADMAP
            };
          
          var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
          
          var marker = new google.maps.Marker({
            position:myCenter,
            });
          
          marker.setMap(map);
          }
          
          google.maps.event.addDomListener(window, 'load', initialize);
          </script>
            <div id="fourth-block">
              <div class="line">
                 <div id="owl-demo2" class="owl-carousel owl-theme">
                    <div class="item">
                       <h4>Amazing Miracles of Recovery</h4>
                       <p class="s-12 m-12 l-8 center"> <h2>Cancer </h2>
                       </p>
                    </div>
                     <div class="item">
                       <h4>Amazing Miracles of Recovery</h4>
                       <p class="s-12 m-12 l-8 center"> <h2>Cancer </h2>
                       </p>
                    </div>
                    <div class="item">
                        <div class="item">
                       <h4>Amazing Miracles of Recovery</h4>
                       <p class="s-12 m-12 l-8 center"> <h2>Cancer </h2>
                       </p>
                    </div>
                    </div>
                 </div>
              </div>
           </div>
        </section>
        <!-- FOOTER -->   
        <?php
          // do php stuff
          
          include('footer.php');
       
          
          ?>
        <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>   
        <script type="text/javascript">
           jQuery(document).ready(function($) {  
             $("#owl-demo").owlCarousel({
              slideSpeed : 300,
              autoPlay : true,
              navigation : false,
              pagination : false,
              singleItem:true
             });
             $("#owl-demo2").owlCarousel({
              slideSpeed : 300,
              autoPlay : true,
              navigation : false,
              pagination : true,
              singleItem:true
             });
           });	
            
        </script> 
     </body>
  </html>