<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Om Yog Pith,Suart</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">
      <!-- CUSTOM STYLE -->  
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>   
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]-->
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->  
        <?php
        // do php stuff
        
        include('header.php');
     
        
        ?>
      <section>
         <!-- CAROUSEL -->  	
         <div id="carousel">
            <div id="owl-demo-banner" class="owl-carousel owl-theme">
               <div class="item">
                  <img src="img/ombest3.jpg" alt="">      
                  <div class="carousel-text">
                     <div class="line">
                        <div class="s-12 l-9">
                           <h2>Understand & Yoga your self </h2>
                        </div>
                        <div class="s-12 l-9">
                           <p>Om Yog Pith is the spritual center for life of yoga
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="item">
                  <img src="img/omkar2.jpg" alt="">      
                  <div class="carousel-text">
                     <div class="line">
                        <div class="s-12 l-9">
                           <h2>Make time for your Yoga</h2>
                        </div>
                        <div class="s-12 l-9">
                           <p>Yoga is the journery of the self,  through the self, to the self
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="item">
                  <img src="img/ombest1.jpg" alt="">      
                  <div class="carousel-text">
                     <div class="line">
                        <div class="s-12 l-9">
                           <h2>Keep calm and do Yoga</h2>
                        </div>
                        <div class="s-12 l-9">
                            <p>Yoga is the journery of the self,  through the self, to the self
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- FIRST BLOCK --> 	
         <div id="first-block">
            <div class="line">
               <h2>The Yoga Way of Life!</h2>
               <p class="subtitile">Om Yogi Pith way
               </p>
               <div class="margin">
                  <div class="s-24 m-12 l-6 margin-bottom">
                     <i class="icon-paperplane_ico icon2x"></i>
                     <h3>About Yoga </h3>
                     <p class="xx">The origins of yoga have been speculated to date back to pre-Vedic Indian traditions, is mentioned in the Rigveda, but most likely developed around the sixth and fifth centuries BCE, in ancient India's ascetic and śramaṇa movements.The chronology of earliest texts describing yoga-practices is unclear, varyingly credited to Hindu Upanishadsand Buddhist Pāli Canon,probably of third century BCE or later. The Yoga Sutras of Patanjali date from the first half of the 1st millennium CE, but only gained prominence in the West in the 20th century. Hatha yoga texts emerged around the 11th century with origins in tantra.</p>
                  </div>
                   <div class="s-24 m-12 l-6 margin-bottom">
                     <i class="icon-star icon2x"></i>
                     <h3>Pith of Yoga</h3>
                      <p class="xx">The Pith of Yoga is a holistic place of life that integrates all elements of ancient knowledge of Yoga, to make a prayerful discipline uniting the body, mind and soul. Along with the ways of simple, yet meaningful yoga postures ,breathing techniques and living habits a greater emphasis is placed on the inner experience of meditation, for the well-being of mind and other hidden elements of human existence. 
                     </p>
                  </div>
                  
             
               </div>
            </div>
         </div>
         <!-- SECOND BLOCK --> 	
         <div id="second-block">
            <div class="line">
               <div class="margin-bottom">
                  <div class="margin">
                     <article class="s-12 l-8 center">
                        <h1>Om Yogi Pith</h1>
                        <p class="margin-bottom" style="font-size:24px">
                        	Om Yogi pith is sitauted at heavnely place on the bank of river TAPI which is daughter of SUN and sister of KARNA.
                        </p>
                        <a class="button s-12 l-4 center" href="product.html">Read more</a>  			
                     </article>
                  </div>
               </div>
            </div>
         </div>
         <!-- GALLERY --> 	
         <div id="third-block">
            <div class="line">
               <h2>Yoga Pith gallery</h2>
               <p class="subtitile">Om Yoga Pith
               </p>
               <div class="margin">
                  <div class="s-12 m-6 l-3">
                     <img src="img/asan1.jpg" alt="alternative text">      
                     <p class="subtitile">Om Yoga Pith
                     </p>
                  </div>
                  <div class="s-12 m-6 l-3">
                     <img src="img/asan2.jpg" alt="alternative text">      
                     <p class="subtitile">Om Yoga Pith
                     </p>
                  </div>
                  <div class="s-12 m-6 l-3">
                     <img src="img/asan3.jpg" alt="alternative text">      
                     <p class="subtitile">Om Yoga Pith
                     </p>
                  </div>
                  <div class="s-12 m-6 l-3">
                     <img src="img/asan4.jpg" alt="alternative text">      
                     <p class="subtitile">Om Yoga Pith
                     </p>
                  </div>
               </div>
            </div>
         </div>
         <div id="fourth-block">
            <div class="line">
               <div id="owl-demo2" class="owl-carousel owl-theme">
                  <div class="item">
                     <h4>Amazing Miracles of Recovery</h4>
                     <p class="s-12 m-12 l-8 center"> <h2>Cancer </h2>
                     </p>
                  </div>
                   <div class="item">
                     <h4>Amazing Miracles of Recovery</h4>
                     <p class="s-12 m-12 l-8 center"> <h2>Cancer </h2>
                     </p>
                  </div>
                  <div class="item">
                      <div class="item">
                     <h4>Amazing Miracles of Recovery</h4>
                     <p class="s-12 m-12 l-8 center"> <h2>Cancer </h2>
                     </p>
                  </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- FOOTER -->   
       <?php
        // do php stuff
        
        include('footer.php');
     
        
        ?>
      
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>   
      <script type="text/javascript">
         jQuery(document).ready(function($) {  
           $("#owl-demo").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : false,
         	singleItem:true
           });
		      $("#owl-demo-banner").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : false,
         	singleItem:true
           });
           $("#owl-demo2").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : true,
         	singleItem:true
           });
         });	
          
      </script> 
   </body>
</html>