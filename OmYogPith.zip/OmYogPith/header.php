<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body>
<header>
         <nav>
            <div class="line">
               <div class="top-nav">              
                  <div class="logo hide-l">
                     <a href="index.php">Om <br /><strong>Yog Pith</strong></a>
                  </div>                  
                  <p class="nav-text">Om Yog Pith Menu</p>
                  <div class="top-nav s-12 l-5">
                     <ul class="right top-ul chevron">
                        <li><a href="index.php">Om Yog Home</a>
                        </li>
                        <li><a href="advantages.php">Advantages</a>
                        </li>
                        <li><a href="testimonial.php">Testimonial</a>
                        </li>
                     </ul>
                  </div>
                  <ul class="s-12 l-2">
                     <li class="logo hide-s hide-m">
                        <a href="index.php">Om <br /><strong>Yog Pith</strong></a>
                     </li>
                  </ul>
                  <div class="top-nav s-12 l-5">
                     <ul class="top-ul chevron">
                        <li><a href="gallery.php">Gallery</a>
                        </li>
               
                        <li><a href="contact.php">Contact</a>
                        </li>
                     </ul> 
                  </div>
               </div>
            </div>
         </nav>
      </header>
</body>
</html>