<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>
  <footer>
         <div class="line">
            <div class="s-12 l-6">
               <p>Copyright 2016, Delinnova Technology Solutions.
               </p>
            </div>
            <div class="s-12 l-6">
               <p class="right">
                  <a class="right" href="http://www.delinnova.com" title="Business and Socila Solutions">Design and coding by Delinnova Team</a>
               </p>
            </div>
         </div>
      </footer>
<body>
</body>
</html>