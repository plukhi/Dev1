<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Responsive Design website template</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">
      <!-- CUSTOM STYLE -->  
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>   
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]--> 
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->  
      <!-- TOP NAV WITH LOGO -->  
        <?php
        // do php stuff
        
        include('header.php');
     
        
        ?>
      <section>
         <div id="head">
            <div class="line">
               <h1>Responsive image gallery</h1>
            </div>
         </div>
         <div id="content">
            <div class="line">
               <div class="margin">
                   <div class="s-12 m-6 l-4">
                      <img src="img/first-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/second-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/third-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/fourth-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/first-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/second-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/third-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/fourth-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/first-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/second-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/third-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
                   <div class="s-12 m-6 l-4">
                      <img src="img/fourth-small.jpg">      
                      <p class="subtitile">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                      </p>
                   </div>
               </div>
            </div>
         </div>
         <div id="fourth-block">
            <div class="line">
               <div id="owl-demo2" class="owl-carousel owl-theme">
                  <div class="item">
                     <h2>Amazing responsive template</h2>
                     <p class="s-12 m-12 l-8 center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                     </p>
                  </div>
                  <div class="item">
                     <h2>Responsive components</h2>
                     <p class="s-12 m-12 l-8 center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                     </p>
                  </div>
                  <div class="item">
                     <h2>Retina ready</h2>
                     <p class="s-12 m-12 l-8 center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- FOOTER -->   
      <?php
        // do php stuff
        
        include('footer.php');
     
        
        ?>
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>   
      <script type="text/javascript">
         jQuery(document).ready(function($) {  
           $("#owl-demo").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : false,
         	singleItem:true
           });
           $("#owl-demo2").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : true,
         	singleItem:true
           });
         });	
          
      </script> 
   </body>
</html>