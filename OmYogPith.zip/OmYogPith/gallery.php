<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Om Yog Pith ,Yoga  Gallery</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">
      <!-- CUSTOM STYLE -->  
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script> 
	   <script type="text/javascript" src="js/jquery.lightbox-0.5.min.js"></script>
	    <link rel="stylesheet" type="text/css" media="all" href="css/jquery.lightbox-0.5.css">
	<meta name="description" content="Gallery,Om Yog Pith,Surat,Yoga,Yoga Center" />
		<meta name="keywords" content="Yoga,Yoga Center,Yoga Point,Om Yog,Yog pith,Yog peeth,Stress release,peace,Manubhai Dhhola,relaxation,Galley,img,Surat" />	  
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]--> 
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->  
      <!-- TOP NAV WITH LOGO -->  
        <?php
        // do php stuff
        
        include('header.php');
     
        
        ?>
      <section>
         <div id="head">
            <div class="line">
               <h1>Om Yog Pith Events Gallery</h1>
            </div>
         </div>
	<div id="w">
		<div id="content">
			 <div id="thumbnails">
     
			   <ul class="clearfix">
			
				   <li>
                    <div class="s-9 m-9 l-9">
				    <a href="img/second-small.jpg" title="Om Yog Asan">
                      <img src="img/second-small.jpg">    
				   </a>					  
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                   </div>
				   </li>
				    <li>
                   <div class="s-9 m-9 l-9">
				    <a href="img/third-small.jpg" title="Om Yog Asan">
                      <img src="img/third-small.jpg">   
					</a>
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                  </div>
				   </li>
				    <li>
                    <div class="s-9 m-9 l-9">
				    <a href="img/fourth-small.jpg" title="Om Yog Asan">
                      <img src="img/fourth-small.jpg">    
					</a>
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                    </div>
				    </li>
					 <li>
					<div class="s-9 m-9 l-9">
				    <a href="img/first-small.jpg" title="Om Yog Asan">
                      <img src="img/first-small.jpg">   
					</a>
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                   </div>
				   </li>
				    <li>
					<div class="s-9 m-9 l-9">
                      <a href="img/second-small.jpg" title="Om Yog Asan">
						<img src="img/second-small.jpg">    
					</a>	   
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                     </div>
				   </li>
				    <li>
                                      <div class="s-9 m-9 l-9">
                      <img src="img/third-small.jpg">      
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                 
				   </li>
				    <li>
                      <div class="s-9 m-9 l-9">
                      <a href="img/fourth-small.jpg" title="Om Yog Asan">
						<img src="img/fourth-small.jpg">    
						</a>   
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                    </div>
				   </li>
				    <li>
                     <div class="s-9 m-9 l-9">
                        <a href="img/third-small.jpg" title="Om Yog Asan">
                      <img src="img/third-small.jpg">   
					</a>  
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                   </div>
				   </li>
				    <li>
                     <div class="s-9 m-9 l-9">
				   <a href="img/second-small.jpg" title="Om Yog Asan">
                      <img src="img/second-small.jpg">     
					</a> 
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                     </div>
				   </li>
				    <li>
					<div class="s-9 m-9 l-9">
				    <a href="img/third-small.jpg" title="Om Yog Asan">
                      <img src="img/third-small.jpg">   
						</a>
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
					</div>
				   </li>
				   <li>
                                      <div class="s-9 m-9 l-9">
				   <a href="img/fourth-small.jpg" title="Om Yog Asan">
                      <img src="img/fourth-small.jpg">  
						</a>
                      <p class="subtitile">Om Yog Pith Surat
                      </p>
                      </div>
				   </li>
             
			   </div>
            
			  </div>
         </div>
          <!--div id="w1">
    <div id="conten1t">
     
      <div id="thumbnailqas">
        <ul class="clearfix">
 
          <li><a href="img/first-small.jpg" title="Turntable by Jens Kappelmann"><img src="img/first-small.jpg" alt="turntable"></a></li>
          

          <li><a href="img/first-small.jpg" title="DIY Robot by Jory Raphael"><img src="img/first-small.jpg" alt="DIY Robot Kit"></a></li>
          

          <li><a href="img/photos/03-todly-green-monster.png" title="Todly by Scott Wetterschneider"><img src="img/photos/03-todly-green-monster-thumbnail.png" alt="Todly"></a></li>
          

          <li><a href="img/photos/04-loz-tea-party.png" title="LoZ Tea Party by Joseph Le"><img src="img/photos/04-loz-tea-party-thumbnail.png" alt="legend of zelda tea party"></a></li>
          

          <li><a href="img/photos/05-klaxon-air-horn.png" title="Klaxon Icon by John Khester"><img src="img/photos/05-klaxon-air-horn-thumbnail.png" alt="airhorn icon"></a></li>
          

          <li><a href="img/photos/06-flat-coffee.png" title="Flat Coffee by Baglan Dosmagambetov"><img src="img/photos/06-flat-coffee-thumbnail.png" alt="flat coffee"></a></li>
          

          <li><a href="img/photos/07-ipad-music-player.png" title="iPad Music Player by Angel Bartolli"><img src="img/photos/07-ipad-music-player-thumbnail.png" alt="player ui"></a></li>
          

          <li><a href="img/photos/08-extreme-fish-bowl.png" title="Extreme Fish Bowl by Brian Franco"><img src="img/photos/08-extreme-fish-bowl-thumbnail.png" alt="extreme skateboarding fish bowl"></a></li>
          

          <li><a href="img/photos/09-city-building-illustration.png" title="Illustration by Brandon Ancone"><img src="img/photos/09-city-building-illustration-thumbnail.png" alt="city illustration"></a></li>
          

          <li><a href="img/photos/10-big-restaurant.png" title="Restaurant Illustration by Dury"><img src="img/photos/10-big-restaurant-thumbnail.png" alt="restaurant illustration"></a></li>
        </ul>
      </div>
    </div><!-- @end #content -->
  <!--/div --><!-- @end #w -->
      </section>
      <!-- FOOTER -->   
      <?php
        // do php stuff
        
        include('footer.php');
     
        
        ?>
		 <script type="text/javascript">
        $(document).ready(function(){
          
        });
        </script>
      
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>   
      <script type="text/javascript">
         jQuery(document).ready(function($) {  
           $("#owl-demo").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : false,
         	singleItem:true
           });
           $("#owl-demo2").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : true,
         	singleItem:true
           });
         });	
          $('#thumbnails a').lightBox();
      </script> 
		
</script>
   </body>
</html>