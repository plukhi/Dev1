<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Testimonial Om Yog Pith</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css">
      <!-- CUSTOM STYLE -->  
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="js/modernizr.js"></script>
      <script type="text/javascript" src="js/responsee.js"></script>   
	    <meta name="description" content="Testimonial,Om Yog Pith,Surat,Yoga,Yoga Center" />
		<meta name="keywords" content="Testimonial,Yoga,Yoga Center,Yoga Point,Om Yog,Yog pith,Yog peeth,Stress release,peace,Manubhai Dhhola,relaxation" />
      <!--[if lt IE 9]>
	      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <![endif]-->
   </head>
   <body class="size-1140">
      <!-- TOP NAV WITH LOGO -->  
        <?php
        // do php stuff
        
        include('header.php');
     
        
        ?>
      <section>
         <div id="head">
            <div class="line">
               <h1>Testimonials</h1>
            </div>
         </div>
         <div id="content">
            <div class="line">
			  <div id="owl-demo2" class="owl-carousel owl-theme">
               <div class="item">
                  <div class="s-12 m-12 l-12">
                     <div class="content-block margin-bottom">
					 	 <div class="cd-author">
							<img src="img/avatar-6.jpg" alt="Author image"/>
							<ul class="cd-author-info">
								<li><h4>Ghanshyam Lukhi </h4></li>
								<li>Chairman, Tapi Food Product</li>
							</ul>
						</div> <!-- cd-author -->
						<br/>
						<p>"I was shocked when I came to know that I was having high sugar and cholesterol.Then I directly went to Om Yog Pith Shibir and within 11 days I lost 11kg and my sugar and  cholesterol wen tback to more than normal"                        </p>
						
					
                     </div>
                  </div>
				  </div>
				  <div class="item">
                 <div class="s-12 m-12 l-12">
                     <div class="content-block margin-bottom">
						<div class="cd-author">
							<img src="img/Om-Avatar.png" alt="Author image"/>
							<ul class="cd-author-info">
								<li><h4>Vallabh Patel</h4></li>
							</ul>
						</div> <!-- cd-author -->
							<br/>
                        <p>"After seeing many reputed doctors in Gujarat At last I find some hope at Om Yog Pith Surat."
                        </p>
                     </div>
                  </div>
				  </div>
				  <div class="item">
                  <div class="s-12 m-12 l-12">
                     <div class="content-block margin-bottom">
                   	<div class="cd-author">
							<img src="img/Om-Avatar.png" alt="Author image"/>
							<ul class="cd-author-info">
								<li><h4>Meenaben Shah</h4></li>
								<li>Housewife</li>
							</ul>
						</div> <!-- cd-author -->
                       	<br/>
                        <p>"Joint of leg was become rigid and I was unable to sit also.But after attending Om Yog Shibir at Vyara I can do my routine activities."
                        </p>
                     </div>
                  </div>
				  </div>
				  <div class="item">
                 <div class="s-12 m-12 l-12">
                     <div class="content-block margin-bottom">
                     
						<div class="cd-author">
							<img src="img/Om-Avatar.png" alt="Author image"/>
							<ul class="cd-author-info">
								<li><h4>Amit Patel</h4></li>
								<li>Software Engineer</li>
							</ul>
						</div> <!-- cd-author -->
							<br/>
                        <p>"After doctors denied for permanent solutions for my heart disease ,I gave up hope.Then I met Manubhai at Om yog pith and gave me a reason to live healty life."
                        </p>
                     </div>
                  </div>
				  </div>
				  <div class="item">
                 <div class="s-12 m-12 l-12">
                     <div class="content-block margin-bottom">
                     	<div class="cd-author">
							<img src="img/Om-Avatar.png" alt="Author image"/>
							<ul class="cd-author-info">
								<li><h4>Krishna Parekh</h4></li>
								<li>Software Engineer</li>
							</ul>
						</div> <!-- cd-author -->
							<br/>
                        <p>"Both the kidneys are failed but still My body is responding well.Thanks to Om Yog Ptih. "
                        </p>
                     </div>
                  </div>
				  </div>
				  <div class="item">
                  <div class="s-12 m-12 l-12">
                     <div class="content-block margin-bottom">
                        <div class="cd-author">
							<img src="img/Om-Avatar.png" alt="Author image"/>
							<ul class="cd-author-info">
								<li><h4>Manoj Sing</h4></li>
								<li>Diamond Worker</li>
							</ul>
						</div> <!-- cd-author -->
							<br/>
                        <p>"At the age of 26 I came to know about my Cancer of lungs and my world changed.Thanks to Om Yog optih that gave me life."
                        </p>
                     </div>
                  </div>
				</div>
               </div>
            </div>
			</div>
         </div>
         <!-- GALLERY -->	
         <div id="third-block">
            <div class="line">
               <h2>Responsive gallery</h2>
               <p class="subtitile">Om Yog pith
               </p>
               <div class="margin">
                  <div class="s-12 m-6 l-3">
                     <img src="img/om11.jpg">      
                     <p class="subtitile">Om Yog pith
                  </div>
                  <div class="s-12 m-6 l-3">
                     <img src="img/om12.jpg">      
                     <p class="subtitile">Om Yog pith
                     </p>
                  </div>
                  <div class="s-12 m-6 l-3">
                     <img src="img/om3.jpg">      
                     <p class="subtitile">Om Yog pith
                     </p>
                  </div>
                  <div class="s-12 m-6 l-3">
                     <img src="img/om5.jpg">      
                     <p class="subtitile">Om Yog pith
                     </p>
                  </div>
               </div>
            </div>
         </div>
		  

      </section>
      <!-- FOOTER -->   
      <?php
        // do php stuff
        
        include('footer.php');
     
        
        ?>
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>   
      <script type="text/javascript">
         jQuery(document).ready(function($) {  
           $("#owl-demo").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : false,
         	singleItem:true
           });
           $("#owl-demo2").owlCarousel({
         	slideSpeed : 300,
         	autoPlay : true,
         	navigation : false,
         	pagination : true,
         	singleItem:true
           });
         });	
          
      </script> 
   </body>
</html>