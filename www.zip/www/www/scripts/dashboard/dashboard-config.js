angular.module('akritivEpa.dashboard', [])
    .constant('appConstants', {
        'CHARTS_API_PATH': '/services/apexrest/asv/EPAWSChartData?dbnm=',
        //    'CHARTS_API_PATH': '/services/apexrest/asv/ZGoogleChartDataForMobile2?dbnm=',
        'REPORTS_API_PATH': '/services/data/v35.0/analytics/reports/',
        'DASHBOARD_META_DATA_PATH': '/services/apexrest/asv/EPAWSChartDetailMobile?dbnm=',
        //  'DASHBOARD_META_DATA_PATH': '/services/apexrest/ZGoogleChartDetailForMobile1?dbnm=',
    });