angular.module('akritivEpa.dashboard')
    .controller('dashboardController', function ($scope, $state, EPAMetaDataService, $rootScope, $ionicPopover) {

        console.log("------------ Dashboard controller ----------------");

        init();

        /**
         * Creator : Deepak
         * Function : Initializes data for the controller
         */
        function init() {
            $scope.selectedDashboardName = EPAMetaDataService.metaData[EPAMetaDataService.selectedDashboard].title;
            $scope.dashboards = EPAMetaDataService.metaData;

        }

        /**
         * Creator : Deepak
         * Function : Changes the views between dashboard and metrics
         */
        $scope.changeView = function (view) {
            if (view != $scope.selectedView) {
                console.log("selecte view== " + view);
                $scope.selectedView = view;
            }
        };

        /**
         * Creator : Deepak
         * Function : recieves change view and reloads dashboard accordingly
         */
        $scope.$on('changeView', function (event, view) {
            $scope.selectedView = view;
            init();
        });

        /**
         * Creator : Deepak
         * Function : reloads charts data
         */
        $scope.reloadCharts = function (selectedDashboard) {
            $scope.popover.hide();
            EPAMetaDataService.selectedDashboard = selectedDashboard;
            $scope.$broadcast('reloadCharts');
            init();

        };



        /** 
         * Creator : Deepak
         * On refresh - refreshes the data 
         */
        $scope.$on('refresh', function (event) {
            console.log('refresh event recieved at dashboard controller');
            EPAMetaDataService.fetchMetaData().then(function (metaData) {
                init();
                $scope.$broadcast('reloadCharts');
            }, function (error) {
                // handle error part here
            });
        });

        /** 
         * Creator : Deepak
         * On refresh - creates modal for dashboard dropdown
         */
        $ionicPopover.fromTemplateUrl('templates/popover.html', {
            scope: $scope,
        }).then(function (popover) {
            $scope.popover = popover;
        });

    });
