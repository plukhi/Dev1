angular.module('akritivEpa.dashboard')
    .controller('LoadingCtrl', function ($state, ServerConfig, errorModule, $scope, EPAMetaDataService) {
        $scope.msg = "Please wait, fetching data from server";
        $scope.helperMsg = "";
        $scope.error = false;
        EPAMetaDataService.fetchMetaData().then(function (data) {
            if (data) {
                $scope.isDataLoading = false;
                console.log("epa meta data loaded , redirecting to epanew.dashboard");
                $state.transitionTo("epa.dashboard");
            } else {
                // Something went wrong , please try again later
                $scope.error = true;
                $scope.msg = "Couldn't fetch data!!";
                $scope.helperMsg = "Something Went Wrong!! Please try again later";
            }
        }, function (error) {
            console.log(error);
            $scope.error = true;
            $scope.msg = "Couldn't fetch data!!";
            $scope.helperMsg = error;
        });
    });