/**
 * Creator : Deepak 24-1-16
 * Controller : controller for the dashboard , loads and manipulates charts  
 */
angular.module('akritivEpa.dashboard')
    .controller('dashboardChartsController', function ($scope, $state, dashboardMetaDataService, EPAMetaDataService, $rootScope, dashboardChartsService, $state, $timeout, $ionicModal, QueryAPI) {
        console.log("------- dashboard charts controller called ------------");

        $scope.isPageDataLoaded = false;
        $scope.isError = false;

        $scope.errorObject = {
            "message": "Couldn't fetch data!!",
            "helperMessage": ""
        }
        $scope.screenChartRelationArr = {};
        var screensLoaded = [];
        init();
        /**
         * Creator : Deepak 22-1-16
         * Function : Initialized the dashboard charts everytime controller get initialized
         * 
         */
        function init() {
            var selectedDashboardName = EPAMetaDataService.selectedDashboard;
            $scope.selectedDasbhoard = EPAMetaDataService.metaData[selectedDashboardName].name;
            dashboardMetaDataService.getDashboardMetaData(selectedDashboardName).then(function (response) {
                $scope.isPageDataLoaded = true;
                buildChartsObj(response);
            }, function (error) {
                //console.log(error);
                $scope.isPageDataLoaded = true;
                $scope.isError = true;
                // $scope.errorObject["helperMessage"] = error;
                $scope.errorObject["helperMessage"] = 'Please check your network connection.';
            });
        }

        /**
         * Creator :  Deepak - 24-01-16
         * Function : Chart Counting, No of screens to display counting and chart object building starts here, 
         */

        function buildChartsObj(response) {
            var chartsToDisplay = 4;
            if (!$rootScope.isIpad) {
                chartsToDisplay = 2;
            }
            $scope.screens = [];
            var viewCount = Math.floor(response.noOfCharts % chartsToDisplay == 0 ? response.noOfCharts / chartsToDisplay : (response.noOfCharts / chartsToDisplay) + 1);
            for (var i = 0; i < viewCount; i++) {
                $scope.screens.push({});
            }
            var chartsCounter = 0;
            var screenCounter = 0;
            angular.forEach(response.chartsData, function (chartMetaData, chartId) {
                if (!$scope.screens[screenCounter]) {
                    $scope.screens[screenCounter] = {};
                }
                if (chartsCounter >= chartsToDisplay) {
                    screenCounter++;
                    chartsCounter = 0;
                }
                $scope.screens[screenCounter][chartId] = chartMetaData;
                $scope.screens[screenCounter][chartId].isLoading = true;
                $scope.screenChartRelationArr[chartId] = screenCounter;
                chartsCounter++;
                // initially loads charts for only first screen
                if (screenCounter == 0) {
                    screensLoaded.push(screenCounter);
                    getChart(screenCounter, chartId);
                }

            });
        }
        /**
         * Creator : Deepak   
         * Function : Chart data is requested and assigned to its corresponding object --
         * param1 screenNumber - screen number where to display this chart
         * ID of that particular chart
         */
        function getChart(screenNumber, chartId) {
            //var chartId = dashboardMetaDataService.chartAndChartMetadataRelation[chartName].chartId;
            if (chartId) {
                dashboardChartsService.loadChart(EPAMetaDataService.selectedDashboard, chartId).then(function (response) {
                    $scope.screens[screenNumber][chartId].chartData = response;
                    $scope.screens[screenNumber][chartId].isLoading = false;
                }, function (error) {
                    $scope.screens[screenNumber][chartId].isLoading = false;
                    $scope.screens[screenNumber][chartId].isErrorInFetchingData = true;
                });
            }

        }
        /**
         * Creator : Deepak 
         * Function : On swipe, loads charts for currently selected screen.
         */
        $scope.loadChartsForScreen = function (screenNumber) {
            if (screensLoaded.indexOf(screenNumber) == -1) {
                for (chartId in $scope.screens[screenNumber]) {
                    getChart(screenNumber, chartId)
                }
                screensLoaded.push(screenNumber);
            }
        };

        /**
         * Creator : Deepak
         * catching reload event, calling reload to reload dashboard chart objects
         */
        $scope.$on('reloadCharts', function (event) {
            console.log("reload charts called");
            $scope.isError = false;
            reload();
        });

        /**
         * Creator : Deepak 
         * Function: Reloading data- rebuilding chart objects
         */
        function reload() {
            $scope.screens = [];
            $scope.isPageDataLoaded = false;
            $scope.isDataLoaded = false;
            screensLoaded = [];
            $scope.isFullScreenView = false;
            $scope.selectedAndExpandedChartObj = null;
            $timeout(function () {
                init();
            }, 100);

        }

        /**
         * Creator : Deepak
         * Function : handles click event recieved from google chart directive
         * checks whats next to perform redirects to report or another dashboard
         */
        $scope.handleClickEvent = function (chartId, selectedObj) {
            console.log(selectedObj);
            var screenNumber = $scope.screenChartRelationArr[chartId];
            var chartMetaData = $scope.screens[screenNumber][chartId];
            var drillDownOption = chartMetaData.drillDownTo.toLowerCase();
            if (drillDownOption == 'source report' || drillDownOption == 'filtered source report') {
                var queryToGetFilters = "";
                if (drillDownOption == 'filtered source report') {
                    console.log("=========filtered by source report=====");
                    var groupingAPIArr = chartMetaData.groupingColumn.split(',');
                    console.log(groupingAPIArr);
                    queryToGetFilters += "cnm=" + chartMetaData.id;
                    queryToGetFilters += "&dataType=" + selectedObj.dataType;
                    queryToGetFilters += "&filterLabel=" + (groupingAPIArr.length > 1 ? encodeURIComponent(selectedObj.value + ' _!_~_' + selectedObj.columnLabel) : encodeURIComponent(selectedObj.value));
                    queryToGetFilters += "&curSelColumn=" + selectedObj.currentlySelectedColumn;
                    console.log("=========QUERY CREATED=======");
                    console.log(queryToGetFilters);
                }
                //get report Id from reports
                var query = "select Id from report where DeveloperName = '" + chartMetaData.reportUniqueName + "' ";
                console.log("query to get report id " + query);
                console.log("query to get filters " + queryToGetFilters);
                QueryAPI.executeQuery(query).then(function (response) {
                    console.log(response);
                    if (response.done && response.records.length > 0) {
                        var reportId = response.records[0].Id;
                        $state.go('epa.summarizedMetrics', {
                            'reportId': reportId,
                            'filters': queryToGetFilters == "" ? null : queryToGetFilters
                        });
                    }
                }, function (error) {
                    $scope.errorObject.helperMessage = error;
                    $scope.isError = true;
                });
                force.query(query, function (response) {
                    if (response.done && response.records.length > 0) {
                        var reportId = response.records[0].Id;
                        if (drillDownOption == 'filtered source report') {
                            // How to get filters
                            var filters = [];
                        }
                        $state.go('epa.summarizedMetrics', {
                            'reportId': reportId
                        });
                    }
                });
            } else
            if (drillDownOption == 'epa dashboard') {
                console.log("report unique name " + chartMetaData.reportUniqueName);
                EPAMetaDataService.selectedDashboard = chartMetaData.reportUniqueName;
                $rootScope.$broadcast('reloadCharts');
            } else {
                //do nothing
            }
        };

        /**
         *  Dashboard Chart Expand View Function
         *  Created By Brahm & Deepak
         * 
         */

        $scope.isFullScreenView = false;
        $scope.expandChartView = function (screenId, chartId) {
            console.log(screen.orientation);
            // screen.unlockOrientation();
            //screen.lockOrientation('portrait');
            if ($scope.isFullScreenView) {
                $scope.isFullScreenView = false;
                $scope.selectedAndExpandedChartObj = null;
            } else {
                $scope.selectedAndExpandedChartObj = $scope.screens[screenId][chartId];
                $scope.isFullScreenView = true;

            }
        }

        window.addEventListener("orientationchange", function () {
            console.log(screen.orientation); // e.g. portrait
            screen.lockOrientation('portrait');
        });

        /**
         * 
         */
        $scope.isDrilldownAvailable = function (chartId) {
            var screenNumber = $scope.screenChartRelationArr[chartId];
            var chartMetaData = $scope.screens[screenNumber][chartId];
            var drillDownOption = chartMetaData.drillDownTo.toLowerCase();
            if (drillDownOption == 'source report' || drillDownOption == 'filtered source report' || drillDownOption == 'epa dashboard') {
                return true;
            } else {
                return false;
            }
        }


    });