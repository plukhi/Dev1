angular.module('akritivEpa.dashboard')
    .factory("metricsData", function (AppData, $q, appConfig) {

        return {

            fetchJSON: function (api) {
                var deferred = $q.defer();
                if (appConfig.demoMode) {
                    $http.get('js/static-data/transactional-data.json')
                        .success(function (data) {
                            deferred.resolve(data);
                        })
                        .error(function (error) {
                            deferred.reject(error);
                        });
                } else {
                    var obj = {
                        "path": api,
                        "method": "POST",
                        "data": {}
                    };

                    force.request(obj,
                        function (response) {
                            // console.log("executive summary");
                            // console.log(response);
                            deferred.resolve(response);
                        },
                        function (error) {
                            if (typeof error != "string")
                                error = error[0];
                            error = errorModule.throwException(error, false);
                            deferred.reject(error);
                        });
                }
                return deferred.promise;


            }
        }
    });