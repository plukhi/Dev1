angular.module('akritivEpa.dashboard')
    .factory('createArray', function () {
        var filterArray = {};
        return {
            formArray: function (data, tabName) {
                //            if (tabName === "Quarterly SLA Table by Region") {
                //                filterArray["Quarter"] = [];
                //                for (var i = 0; i < data; i++) {
                //                    filterArray["Quarter"].push({
                //                        "process": "",
                //                        "subProcess": "",
                //                        "region": ""
                //                    });
                //                }
                //            } else if (tabName === "Monthly SLA Trend by Region") {
                //                filterArray["Month"] = [];
                //                for (var i = 0; i < data; i++) {
                //                    filterArray["Month"].push({
                //                        "process": "",
                //                        "subProcess": "",
                //                        "region": ""
                //                    });
                //                }
                //            } else if (tabName === "Yearly SLA Trend by Region") {
                //                filterArray["Year"] = [];
                //                for (var i = 0; i < data; i++) {
                //                    filterArray["Quarter"].push({
                //                        "process": "",
                //                        "subProcess": "",
                //                        "region": ""
                //                    });
                //                }
                //            }

            },
            getFilter: function (region, label, process, subProcess, selectRegion) {
                try {
                    filterArray[region][label];
                } catch (e) {
                    filterArray[region] = [];
                    filterArray[region].push(label);
                    filterArray[region][label] = [];
                    filterArray[region][label].push({
                        "process": "",
                        "subProcess": "",
                        "region": ""
                    });
                }
                return filterArray[region][label];
            },
            setFilter: function (region, label, process, subProcess, selectRegion) {
                try {
                    if (process == "undefined" || subProcess == "undefined" || selectRegion == "undefined") {
                        filterArray[region][label] = [];
                        filterArray[region][label].push({
                            "process": process,
                            "subProcess": subProcess,
                            "region": selectRegion
                        });
                    } else {
                        filterArray[region][label] = [];
                        filterArray[region][label].push({
                            "process": process,
                            "subProcess": subProcess,
                            "region": selectRegion
                        });
                    }

                } catch (e) {
                    filterArray[region] = [];
                    filterArray[region].push(label);
                    filterArray[region][label] = [];
                    filterArray[region][label].push({
                        "process": "",
                        "subProcess": "",
                        "region": ""
                    });
                }
            }


        }
    });