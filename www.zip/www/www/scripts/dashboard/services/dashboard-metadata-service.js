 angular.module('akritivEpa.dashboard')
     .factory('dashboardMetaDataService', function (QueryAPI, $q, errorModule, EPAMetaDataService, appConstants, QueryAPI, appConfiguration, $rootScope) {
         var self = this;
         refresh();

         /**
          * Creator : Deepak
          * Function : refereshes service variables
          */
         function refresh() {
             self.dashboardMetaData = {};
             self.dashboardFilters = {};
             self.chartAndChartMetadataRelation = {};
         }

         /**
          * Creator : Deepak
          * Function : gets relation between chart meta data and chart
          */
         function getChartMetaDataRelation(queryParams) {
             console.log("get chart relation called");
             var deferred = $q.defer();
             console.log(appConfiguration.getQueries().dashboardMetaDataPath.query + EPAMetaDataService.selectedDashboard);

             var requestPath = appConfiguration.getQueries().dashboardMetaDataPath.query + EPAMetaDataService.selectedDashboard;
             QueryAPI.get(requestPath).then(function (response) {
                 console.log(response);
                 console.log($rootScope.isDemoOrg);
                 var resp = JSON.parse(response);
                 if (!resp.isError) {
                     buildChartMetadataRelation(resp.chartList, queryParams);
                     deferred.resolve(true);
                 } else {
                     deferred.reject(response);
                 }
             }, function (error) {
                 deferred.reject(error);
             });
             return deferred.promise;
         }

         function buildChartMetadataRelation(response, params) {
             console.log(response);
             console.log(params);
             angular.forEach(response, function (relationObj) {
                 var itemField = params.name;
                 var itemValue = relationObj[itemField];
                 self.chartAndChartMetadataRelation[itemValue] = new ChartMetaDataRelation(relationObj, params);
             });
             console.log(self.chartAndChartMetadataRelation);
         }

         function ChartMetaDataRelation(relationObj) {
             this.dashboardId = relationObj.asv__EPADashboardMeta__c;
             this.chartId = relationObj.Id;
         }

         /**
          * Creator : Deepak 
          * Function : Fetching dashboard meta data
          */
         self.getDashboardMetaData = function () {
             var deferred = $q.defer();
             var dashboardMetaDataQueryObj = appConfiguration.getQueries().getDashboardMetaData;
             console.log(dashboardMetaDataQueryObj);
             getChartMetaDataRelation(dashboardMetaDataQueryObj.params).then(function () {
                 var query = dashboardMetaDataQueryObj.query;
                 query = query.replace('/developerName/', EPAMetaDataService.selectedDashboard);
                 console.log(query);
                 QueryAPI.executeQuery(query).then(function (data) {
                     console.log(data);
                     if (data.done) {
                         var chartsData = processChartMetaData(data, dashboardMetaDataQueryObj);
                         self.getDashboardFilters().then(function (response) {
                             deferred.resolve(chartsData);
                         });
                     }
                 }, function (error) {
                     deferred.reject(error);
                 });
             }, function (error) {
                 deferred.reject(error);
             });
             return deferred.promise;
         };

         /**
          * Creator : Deepak
          * Function : building metadata object for dashboard
          */

         // TODO: EITHER DO : to be checked if data is not present earlier then request - OR DO : to change object to hold single data
         function processChartMetaData(chartMetaData, dashboardMetaDataQueryObj) {
             // Time being line
             self.dashboardMetaData = {};
             //  ---- Ended --- 
             self.dashboardMetaData[EPAMetaDataService.selectedDashboard] = {};
             self.dashboardMetaData[EPAMetaDataService.selectedDashboard].noOfCharts = chartMetaData.totalSize;
             self.dashboardMetaData[EPAMetaDataService.selectedDashboard].chartsData = {};
             angular.forEach(chartMetaData.records, function (chartObj) {
                 var chartIdField = dashboardMetaDataQueryObj.params.id;
                 var chartId = chartObj[chartIdField];
                 self.dashboardMetaData[EPAMetaDataService.selectedDashboard].chartsData[chartId] = new DashBoardChartObj(chartObj, dashboardMetaDataQueryObj.params);
             });
             return self.dashboardMetaData[EPAMetaDataService.selectedDashboard];
         }

         /**
          * CREATOR : Deepak
          * Function : fetches filters for the currently selected dashboard
          */

         // TODO: EITHER DO : to be checked if data is not present earlier then request - OR DO : to change object to hold single data
         self.getDashboardFilters = function () {
             var deferred = $q.defer();
             var dashboardId = EPAMetaDataService.metaData[EPAMetaDataService.selectedDashboard].id;
             var filterQueryObj = appConfiguration.getQueries().getDashboardFilters;
             var query = filterQueryObj.query;
             query = query.replace('/dashboardId/', dashboardId);
             console.log(query);
             QueryAPI.executeQuery(query).then(function (data) {
                 if (data.done) {
                     console.log(data.records);
                     self.dashboardFilters[EPAMetaDataService.selectedDashboard] = data.records;
                 }
                 deferred.resolve(true);
             }, function (error) {
                 deferred.reject(error);
             });

             return deferred.promise;
         };

         /**
          * Creator : Deepak
          * Function : creating chart metadata object
          */
         function DashBoardChartObj(chartMetaData, queryParams) {
             console.log(queryParams);
             var self = this;
             angular.forEach(queryParams, function (value, key) {
                 self[key] = chartMetaData[value];
             });
             console.log(self);
             /*    this.title = chartMetaData.asv__Title__c;
                 this.chartType = chartMetaData.asv__ChartType__c;
                 this.dataSource = chartMetaData.asv__DataSource__c;
                 this.decimalPlaces = chartMetaData.asv__DecimalPlaces__c;
                 this.drillDownTo = chartMetaData.asv__DrillDownTo__c;
                 this.gridPosition = chartMetaData.asv__GridPosition__c;
                 this.groupingColumn = chartMetaData.asv__GroupingColumn__c;
                 this.hAxisOptions = chartMetaData.asv__hAxisOptions__c;
                 this.legendPosition = chartMetaData.asv__LegendPosition__c;
                 this.reportUniqueName = chartMetaData.asv__ReportUniqueName__c;
                 this.showValues = chartMetaData.asv__ShowValues__c;
                 this.sortField = chartMetaData.asv__SortField__c;
                 this.vAxisOptions = chartMetaData.asv__vAxisOptions__c;
                 this.verticalAxisTitle = chartMetaData.asv__VerticalAxisTitle__c;
                 this.toolTipConfig = chartMetaData.asv__TooltipConfig__c;
                 this.showTimeRangeFilter = chartMetaData.asv__ShowTimeRangeFilter__c;
                 this.name = chartMetaData.Name;
                 this.dateForamt = chartMetaData.asv__DateDisplayFormat__c
                 this.id = chartMetaData.Id;*/
         };

         /**
          * Creator : Deepak 
          * Function : calls refresh
          */
         self.refreshData = function () {
             refresh();
         }
         return this;
     });