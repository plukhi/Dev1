angular.module('akritivEpa').filter('dashboardDropDown', function () {
    return function (dashboardList, filterOption) {
        if (filterOption) {
            var filteredList = {};
            angular.forEach(dashboardList, function (dashboardObj, key) {
                var dashboardObjCopy = dashboardObj.title ? angular.copy(dashboardObj.title) : angular.copy(dashboardObj.name);
                if (dashboardObjCopy && dashboardObjCopy.toLowerCase().indexOf(filterOption.toLowerCase()) != -1) {
                    filteredList[key] = dashboardObj;
                }
            });
            return filteredList;
        } else {
            return dashboardList;
        }

    }
});


angular.module('akritivEpa.dashboard')
    .factory('EPAMetaDataService', function (QueryAPI, $q, errorModule, appConfiguration) {
        var self = this;
        refresh();

        /**
         * Creator : Deepak
         * Function : refreshes service variables
         */

        function refresh() {
            self.metaData = null;
            self.defaultDashboard = null;
            self.selectedDashboard = null;
        }

        /**
         * Creator : Deepak
         * Function : Fetching metadata for EPA App
         */
        self.fetchMetaData = function () {
            var deferred = $q.defer();
            var dashboardQueryObj = appConfiguration.getQueries().getDashboardsList;
            var query = dashboardQueryObj.query;
            QueryAPI.executeQuery(query).then(function (data) {
                if (data.done) {
                    /* For time being till default dashboard key is not in DB */
                    self.defaultDashboard = data.records[0][dashboardQueryObj.params.developerName];
                    console.log("default dashboard: " + data.records[0][dashboardQueryObj.params.developerName]);
                    self.selectedDashboard = data.records[0][dashboardQueryObj.params.developerName];
                    console.log("selected dashboard: " + self.selectedDashboard);
                    /* Ended */
                    deferred.resolve(buildMetaDataObject(data.records, dashboardQueryObj));
                } else {
                    deferred.resolve(false);
                }
            }, function (error) {
                deferred.reject(error);
            });
            return deferred.promise;
        };

        /**
         * Creator : Deepak
         * Function : Building EPA meta data object having all the dashboards data
         */
        function buildMetaDataObject(metaDataArr, dashboardQueryObj) {
            self.metaData = {};
            angular.forEach(metaDataArr, function (singleDashboardData) {
                var developerNameField = dashboardQueryObj.params.developerName;
                var developerNameValue = singleDashboardData[developerNameField];
                self.metaData[developerNameValue] = new DashboardObj(singleDashboardData, dashboardQueryObj.params);
            });
            console.log("epa meta data:");
            console.log(self.metaData);
            return self.metaData;
        }

        /**
         * Creator : Deepak
         * Function : creating dashboard object
         */
        function DashboardObj(dbObject, queryParams) {
            var selfObject = this;
            angular.forEach(queryParams, function (value, key) {
                selfObject[key] = dbObject[value];
            });
            if (selfObject.isDefault) {
                self.defaultDashboard = dbObject.asv__DeveloperName__c;
                self.selectedDashboard = dbObject.asv__DeveloperName__c;
            }
        }
        /*  function DashboardObj(dbObject) {
              this.chartSize = dbObject.asv__ChartSize__c;
              this.description = dbObject.asv__Description__c;
              this.developerName = dbObject.asv__DeveloperName__c;
              this.filterLogic = dbObject.asv__FilterLogic__c;
              this.id = dbObject.Id;
              this.name = dbObject.Name;
              this.metric = dbObject.asv__Metric__c;
              this.titleColor = dbObject.asv__TitleColor__c;
              this.titleSize = dbObject.asv__TitleSize__c;
              this.title = dbObject.asv__Title__c;
              this.isDefault = dbObject.asv__isMobileDefault__c;
              if (this.isDefault) {
                  self.defaultDashboard = dbObject.asv__DeveloperName__c;
                  self.selectedDashboard = dbObject.asv__DeveloperName__c;
              }
          }*/
        /**
         * Creator : Deepak
         * Function : calls refresh
         */
        self.refreshData = function () {
            refresh();
        }
        return self;
    });