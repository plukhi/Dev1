angular.module('akritivEpa.dashboard')
    .factory('dashboardChartsService', function ($q, appConstants, $timeout, ServerCallQueue, EPAMetaDataService, appConfiguration, QueryAPI) {
        var self = this;

        /**
         * THIS FUNCTION loads a chart with given report ID
         */
        self.loadChart = function (dashboardName, reportId) {
            var deferred = $q.defer();
            // commented for a while
            //var isThisRequestInProgress = ServerCallQueue.fillInQueue(reportId);
            //if (!isThisRequestInProgress) {
            var request = {
                "path": appConfiguration.getQueries().chartsAPIPath.query + dashboardName + "&cnm=" + reportId,
                "method": "GET"
            };

            var requestPath = appConfiguration.getQueries().chartsAPIPath.query + dashboardName + "&cnm=" + reportId;
            QueryAPI.get(requestPath).then(function (response) {
                console.log("response is accurarte for " + dashboardName + " report Id " + reportId);
                var resp = JSON.parse(response);
                if (resp.Data) {
                    deferred.resolve({
                        data: resp.Data,
                        options: resp.Options
                    });
                } else {
                    console.log("response is inaccurate for " + dashboardName + " report Id " + reportId);
                    deferred.reject(new Error("No Chart Found"));
                }
            }, function (error) {
                console.log("response is inaccurate for " + dashboardName + " report Id " + reportId);
                deferred.reject(error);
            });

            //            } else {
            //                deferred.reject(new Error("Fetch request already in process"));
            //            }
            return deferred.promise;
        };

        /**
         * loads all charts -- not being used currently
         */
        self.getCharts = function (response) {
            var deferred = $q.defer();
            var loadedChartCount = 0;
            angular.forEach(response.chartsData, function (chartMetaData, chartId) {
                self.loadChart(chartId).then(function (resp) {
                    loadedChartCount++;
                    if (response.noOfCharts == loadedChartCount) {
                        console.log("all charts loaded");
                        deferred.resolve(true);
                    }
                }, function (error) {
                    loadedChartCount++;
                    if (response.noOfCharts == loadedChartCount) {
                        console.log("all charts loaded");
                        deferred.resolve(true);

                    }
                });
            });
            return deferred.promise;
        };

        return self;
    });