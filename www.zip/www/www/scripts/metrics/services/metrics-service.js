angular.module('akritivEpa.metrics')
    .factory('metricsService', function ($q, QueryAPI, $filter, appConfiguration) {
        var self = this;
        self.metricsArr = [];
        /** 
         * Creator : Deepak 02-02-16
         * Function : fetches metrics data
         */
        self.loadMetrics = function () {
            var deferred = $q.defer();
            var queryObj = appConfiguration.getQueries().getMetrics;
            QueryAPI.executeQuery(queryObj.query).then(function (response) {
                console.log(response);
                if (response.done)
                    deferred.resolve(processMetricsData(response.records, queryObj.params));
            }, function (error) {
                deferred.reject(error);
            });
            return deferred.promise;
        };

        /** 
         * Creator : Deepak 02-02-16
         * Function : creates metrics list and processes list
         */
        function processMetricsData(metricsArr, params) {
            console.log($filter('filter')(metricsArr, {
                "Process__c": "P2P"
            }));
            var metrics = {};
            var processArr = [];
            angular.forEach(metricsArr, function (metric) {
                var idField = params.id;
                var metricId = metric[idField];
                metrics[metricId] = new MetricObject(metric, params);
                var processKey = params.process;
                if (metric[processKey] && metric[processKey] != '' && metric[processKey] != null && processArr.indexOf(metric[processKey]) == -1) {
                    processArr.push(metric[processKey]);
                }
            });
            console.log(metrics);
            console.log(processArr);
            return {
                'metrics': metrics,
                'processes': processArr
            }
        }

        /** 
         * Creator : Deepak 02-02-16
         * Function : Creates metric object
         */
        function MetricObject(metricObj, params) {
            var self = this;
            angular.forEach(params, function (value, key) {
                self[key] = metricObj[value];

            });

            /*     this.id = metricObj.Id;
                 this.dashboardUniqueName = metricObj.asv__DashboardUniqueName__c;
                 this.displayName = metricObj.asv__DisplayName__c;
                 this.description = metricObj.asv__OperationalDescription__c;
                 this.process = metricObj.asv__Process__c;
                 this.subProcess = metricObj.asv__SubProcess__c;*/
        }

        return self;
    });

angular.module('akritivEpa')
    .filter('orderByForObjects', function () {
        return function (data, key, isAscendingOrder) {

            function sortAscending(a, b) {
                if (a[key] != undefined && a[key] != null && (b[key] == undefined || b[key] == null)) {
                    return 1;
                } else
                if (b[key] != undefined && b[key] != null && (a[key] == undefined || a[key] == null)) {
                    return -1;
                } else
                if ((b[key] == undefined || b[key] == null) && (a[key] == undefined || a[key] == null)) {
                    return 0;
                } else
                    return a[key] - b[key];
            }

            function sortDescending(a, b) {
                if (a[key] != undefined && a[key] != null && (b[key] == undefined || b[key] == null)) {
                    return -1;
                } else
                if (b[key] != undefined && b[key] != null && (a[key] == undefined || a[key] == null)) {
                    return 1;
                } else
                if ((b[key] == undefined || b[key] == null) && (a[key] == undefined || a[key] == null)) {
                    return 0;
                } else
                    return b[key] - a[key];
            }

            if (key) {
                var sortedData = {};
                var arrOfData = [];
                angular.forEach(data, function (value, key) {
                    arrOfData.push(value);
                });
                if (isAscendingOrder) {
                    arrOfData.sort(sortAscending);
                } else {
                    arrOfData.sort(sortDescending);
                }
                angular.forEach(arrOfData, function (singleElem) {
                    sortedData[singleElem.id] = singleElem;
                });
                return sortedData;
            } else {
                return data;
            }
        }
    });