angular.module('akritivEpa.metrics')
    .controller('metricsController', function ($scope, metricsService, $filter, EPAMetaDataService, $rootScope, $state, $ionicScrollDelegate, $ionicLoading) {
        console.log("metrics controller called");
        $scope.isDataLoaded = false;

        $scope.isError = false;
        $scope.errorObject = {
            "message": "Couldn't fetch metrics data"
        }
        init();
        /**
         * Creator : Deepak
         * Function : Initializes data for the controller
         */
        function init() {
            metricsService.loadMetrics().then(function (response) {
                $scope.isError = false;
                $scope.processes = response.processes;
                $scope.processes.splice(0, 0, 'ALL');
                $scope.selectedProcess = $scope.processes[0];
                $scope.AllMetricsArr = response.metrics;
                //$scope.metricsArr = response.metrics;
                // To be taken care later - for now to move blank subprocesses to last
                // to be checked and updated later, may be replaced with above line 
                $scope.metricsArr = $filter('orderByForObjects')(response.metrics, 'subProcess', false);
                $scope.isDataLoaded = true;
            }, function (error) {
                $scope.isDataLoaded = true;
                $scope.isError = true;
                $scope.errorObject['helperMessage'] = error;
            });
        }

        /**       
         * Creator : Deepak 03-01-16
         * Function : filters metrics based on process
         */
        $scope.filterMetrics = function (process) {
            console.log("selected metrics= " + process);
            $ionicScrollDelegate.scrollTop();
            if (process.toLowerCase() == 'all') {
                $scope.selectedProcess = process;
                $scope.metricsArr = $filter('orderByForObjects')($scope.AllMetricsArr, 'subProcess', false);;

            } else if (process != $scope.selectedProcess) {
                $scope.selectedProcess = process;
                $scope.metricsArr = [];
                $scope.metricsArr = $filter('objectFilter')($scope.AllMetricsArr, {
                    'process': process
                });
                // To be taken care later - for now to move blank subprocesses to last
                $scope.metricsArr = $filter('orderByForObjects')($scope.metricsArr, 'subProcess', false);
            }
        };

        /**
         * Creator : Deepak
         * Function : On click of a metric, makes that dashboard selected and emits a change view event
         */
        $scope.redirectToDashboard = function (dashboardName) {
            console.log(dashboardName);
            if (dashboardName) {
                /* Checking if that dashboard exists or not */
                if (EPAMetaDataService.metaData[dashboardName]) {
                    EPAMetaDataService.selectedDashboard = dashboardName;
                    $scope.$emit('changeView', 'D');
                } else {
                    $ionicLoading.show({
                        template: "Dashboard doesn't exist.",
                        noBackdrop: true,
                        duration: 1000
                    });

                }
            }
        }


    });