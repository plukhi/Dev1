angular.module('akritivEpa.summarizedMetrics')
    .factory('reportsService', function ($q, appConstants, errorModule, $compile, QueryAPI) {
        var self = this;

        /**
         * Creator : Deepak
         * Functon : With the given report id and filters, fetches data from the server
         */
        self.fetchJSON = function (reportId, filters) {
            var deferred = $q.defer();
            if (!reportId) {
                error = errorModule.throwException(119, false);
                deferred.reject(null);
            } else {

                var requestPath = appConstants.REPORTS_API_PATH + reportId;
                // var requestPath = appConstants.REPORTS_API_PATH + "00Oi0000006AEPBEA4";
                var requestParams = filters ? filters : null;
                //    var requestParams = null;

                QueryAPI.post(requestPath, requestParams).then(function (response) {
                    console.log(response);
                    deferred.resolve(processData(response));
                }, function (error) {
                    deferred.reject("Something went wrong. Please try again later.");
                });
            }
            return deferred.promise;
        };



        /**
         * Creator : Deepak
         * Functon : processes fetched report data and returns data as per use
         */
        function processData(rData) {
            var reportHeaders = getHeaders(rData.reportExtendedMetadata.detailColumnInfo, rData.reportMetadata.detailColumns);
            var reportData = getTableDataObject(rData, reportHeaders);
            var reportMetaData = getReportMetaData(rData.reportMetadata, rData.reportExtendedMetadata);
            return {
                'reportMetaData': reportMetaData,
                'reportHeaders': reportHeaders,
                'reportData': reportData
            };
        }

        /**
         * Creator : Deepak 
         * Function : filter outs headers from report meta data
         */
        function getHeaders(detailedData, headerKeys) {
            var reportTableHeadersArr = [];
            angular.forEach(headerKeys, function (key) {
                if (key.toLowerCase().indexOf('month') != -1) {
                    reportTableHeadersArr.push({
                        'displayName': detailedData[key].label,
                        'dataType': 'string',
                        'actualName': key
                    });
                } else {
                    reportTableHeadersArr.push({
                        'displayName': detailedData[key].label,
                        'dataType': detailedData[key].dataType,
                        'actualName': key
                    });
                }
            });
            return reportTableHeadersArr;
        }

        /**
         * Creator : Deepak
         * Functoin : creates reports array  
         */
        function getTableDataObject(report, reportHeaders) {
            if (report.groupingsAcross.groupings.length > 0) {
                return handleMatrixReport(report, reportHeaders);
            } else
            if (report.groupingsDown.groupings.length > 0) {
                return handleSummaryReport(report, reportHeaders);
            } else {
                var factMapKey = "T!T";
                var groupingsObj = angular.extend({}, report.groupingsDown);
                groupingsObj["data"] = getReportsData(factMapKey, report.factMap, reportHeaders);
                groupingsObj["recordsCount"] = getRecordCount(factMapKey, report.factMap);
                console.log(groupingsObj);
                return groupingsObj;
            }

        }

        function getRecordCount(key, factMap) {
            var rowCount = 0;
            if (factMap[key] && factMap[key].rows && factMap[key].rows.length > 0) {
                rowCount = factMap[key].rows.length;
            }
            return rowCount;
        }


        /**
         * Creator : Deepak
         * Function : handles report with grouping down only -- handles all three levels
         */
        function handleSummaryReport(report, reportHeaders) {
            var groupingsObj = angular.extend({}, report.groupingsDown);
            groupingsObj["recordsCount"] = 0;
            // adding record count for T!T
            angular.forEach(groupingsObj.groupings, function (firstLevelGrouping) {
                firstLevelGrouping["recordsCount"] = getRecordCount(firstLevelGrouping.key + '!T', report.factMap);
                if (firstLevelGrouping.groupings.length > 0) {
                    angular.forEach(firstLevelGrouping.groupings, function (secondLevelGrouping) {
                        secondLevelGrouping["recordsCount"] = getRecordCount(secondLevelGrouping.key + '!T', report.factMap, reportHeaders);
                        if (secondLevelGrouping.groupings.length > 0) {
                            angular.forEach(secondLevelGrouping.groupings, function (thirdLevelGrouping) {
                                thirdLevelGrouping["data"] = getReportsData(thirdLevelGrouping.key + '!T', report.factMap, reportHeaders);
                                thirdLevelGrouping["recordsCount"] = getRecordCount(thirdLevelGrouping.key + '!T', report.factMap, reportHeaders);
                                secondLevelGrouping["recordsCount"] = secondLevelGrouping["recordsCount"] + thirdLevelGrouping["recordsCount"]
                            });
                        } else {
                            secondLevelGrouping["data"] = getReportsData(secondLevelGrouping.key + '!T', report.factMap, reportHeaders);
                        }

                        firstLevelGrouping["recordsCount"] = firstLevelGrouping["recordsCount"] + secondLevelGrouping["recordsCount"];
                    });
                } else {
                    firstLevelGrouping["data"] = getReportsData(firstLevelGrouping.key + '!T', report.factMap, reportHeaders);
                }
                groupingsObj["recordsCount"] += firstLevelGrouping["recordsCount"];
            });
            console.log(groupingsObj);
            return groupingsObj;
        }

        /**
         * Creator : Deepak
         * Function : When getting matrix report from server , processing with this logic
         * POINTS : grouping across wil be available if and only if grouping down is there.
         */
        function handleMatrixReport(report, reportHeaders) {
            var groupingsDownObj = angular.extend({}, report.groupingsDown);
            groupingsDownObj["recordsCount"] = 0;
            angular.forEach(groupingsDownObj.groupings, function (firstLevelGrouping) {
                // initializing top level record count
                firstLevelGrouping["recordsCount"] = 0;
                // FIRST LEVEL OF GROUPING DOWN
                var groupingAcrossKey;
                if (firstLevelGrouping.groupings.length > 0) {

                    // SECOND LEVEL OF GROUPING DOWN AVAILABLE
                    angular.forEach(firstLevelGrouping.groupings, function (secondLevelGrouping) {
                        secondLevelGrouping["recordsCount"] = 0;
                        // SECOND LEVEL OF GROUPING DOWN
                        groupingDownKey = secondLevelGrouping.key;
                        angular.forEach(report.groupingsAcross.groupings, function (frstLevelAcross) {
                            // FIRST LEVEL OG GROUPING ACROSS
                            var firstLevelAcrossGrouping = angular.extend({}, frstLevelAcross);
                            firstLevelAcrossGrouping["recordsCount"] = 0;
                            if (firstLevelAcrossGrouping.groupings.length > 0) {
                                var availableFirstLevelAcrossGroupings = angular.extend({}, firstLevelAcrossGrouping.groupings);
                                firstLevelAcrossGrouping.groupings = [];
                                // SECOND LEVEL OF GROUPING ACROSS AVAILABLE
                                angular.forEach(availableFirstLevelAcrossGroupings, function (scndLevelAcross) {
                                    var secondLevelAcrossGrouping = angular.extend({}, scndLevelAcross);
                                    secondLevelAcrossGrouping["recordsCount"] = 0;
                                    groupingAcrossKey = secondLevelAcrossGrouping.key;
                                    if (!secondLevelAcrossGrouping["data"]) {
                                        secondLevelAcrossGrouping["data"] = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                        secondLevelAcrossGrouping["recordsCount"] = secondLevelAcrossGrouping["data"].length;
                                    } else {
                                        var moreData = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                        secondLevelAcrossGrouping["data"].push.apply(secondLevelAcrossGrouping["data"], moreData);
                                        secondLevelAcrossGrouping["recordsCount"] += moreData.length;
                                    }
                                    firstLevelAcrossGrouping.groupings.push(secondLevelAcrossGrouping);
                                    firstLevelAcrossGrouping["recordsCount"] += secondLevelAcrossGrouping["recordsCount"];
                                });
                            } else {
                                // ONLY ONE LEVEL OF GROUPING ACROSS AVAILABLE
                                groupingAcrossKey = firstLevelAcrossGrouping.key;
                                // ADDING FIRST LEVEL OF GROUPING ACROSS UNDER SECOND LEVEL OF GROUPING DOWN
                                if (!firstLevelAcrossGrouping["data"]) {
                                    firstLevelAcrossGrouping["data"] = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                    firstLevelAcrossGrouping["recordsCount"] = firstLevelAcrossGrouping["data"].length;
                                } else {
                                    var moreData = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                    firstLevelAcrossGrouping["data"].push.apply(firstLevelAcrossGrouping["data"], moreData);
                                    firstLevelAcrossGrouping["recordsCount"] += moreData.length;
                                }
                            }
                            secondLevelGrouping.groupings.push(firstLevelAcrossGrouping);
                            secondLevelGrouping["recordsCount"] += firstLevelAcrossGrouping["recordsCount"];
                        });
                        firstLevelGrouping["recordsCount"] += secondLevelGrouping["recordsCount"];
                    });
                } else {
                    // ONLY ONE LEVEL OF GROUPING DOWN AVAILABLE
                    groupingDownKey = firstLevelGrouping.key;
                    angular.forEach(report.groupingsAcross.groupings, function (frstLevelAcross) {
                        // FIRST LEVEL OF GROUPING ACROSS
                        var firstLevelAcrossGrouping = angular.extend({}, frstLevelAcross);
                        firstLevelAcrossGrouping["recordsCount"] = 0;
                        if (firstLevelAcrossGrouping.groupings.length > 0) {
                            var availableFirstLevelAcrossGroupings = angular.extend({}, firstLevelAcrossGrouping.groupings);
                            firstLevelAcrossGrouping.groupings = [];
                            // SECOND LEVEL OF GROUPING ACROSS AVAILABLE
                            angular.forEach(availableFirstLevelAcrossGroupings, function (scndLevelAcross) {
                                var secondLevelAcrossGrouping = angular.extend({}, scndLevelAcross);
                                secondLevelAcrossGrouping["recordsCount"] = 0;
                                groupingAcrossKey = secondLevelAcrossGrouping.key;
                                if (!secondLevelAcrossGrouping["data"]) {
                                    secondLevelAcrossGrouping["data"] = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                    secondLevelAcrossGrouping["recordsCount"] = secondLevelAcrossGrouping["data"].length;
                                } else {
                                    var moreData = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                    secondLevelAcrossGrouping["data"].push.apply(secondLevelAcrossGrouping["data"], moreData);
                                    secondLevelAcrossGrouping["recordsCount"] += moreData.length;
                                }
                                firstLevelAcrossGrouping.groupings.push(secondLevelAcrossGrouping);
                                firstLevelAcrossGrouping["recordsCount"] += secondLevelAcrossGrouping["recordsCount"];
                            });
                        } else {
                            // ONLY ONE LEVEL OF GROUPING ACROSS AVAILABLE
                            groupingAcrossKey = firstLevelAcrossGrouping.key;
                            // ADDING FIRST LEVEL OF GROUPING ACROSS UNDER SECOND LEVEL OF GROUPING DOWN
                            if (!firstLevelAcrossGrouping["data"]) {
                                firstLevelAcrossGrouping["data"] = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                firstLevelAcrossGrouping["recordsCount"] = firstLevelAcrossGrouping["data"].length;
                            } else {
                                var moreData = getReportsData(groupingDownKey + '!' + groupingAcrossKey, report.factMap, reportHeaders);
                                firstLevelAcrossGrouping["data"].push.apply(firstLevelAcrossGrouping["data"], moreData);
                                firstLevelAcrossGrouping["recordsCount"] += moreData.length;
                            }
                        }
                        firstLevelGrouping.groupings.push(firstLevelAcrossGrouping);
                        firstLevelGrouping["recordsCount"] += firstLevelAcrossGrouping["recordsCount"];
                    });
                }
                groupingsDownObj["recordsCount"] += firstLevelGrouping["recordsCount"];
            });
            console.log(groupingsDownObj);
            return groupingsDownObj;
        }
        /**
         * Creator : Deepak* Function: adds rows to reports obj
for the given level of grouping key
         */

        function getReportsData(factMapKey, factMap, reportHeaders) {
            var rowsArr = [];
            var singleObj = factMap[factMapKey];
            if (singleObj && singleObj.rows.length > 0) {
                angular.forEach(singleObj.rows, function (row) {
                    var rowObj = {};
                    for (var i = 0; i < reportHeaders.length; i++) {
                        var columnKey = reportHeaders[i].actualName;
                        dataCell = row.dataCells[i];
                        if (columnKey == 'CUST_NAME') {
                            rowObj[columnKey] = {};
                            rowObj[columnKey].label = dataCell.label;
                            rowObj[columnKey].value = dataCell.label;
                            rowObj[columnKey].id = dataCell.value;
                        } else {
                            rowObj[columnKey] = dataCell;
                        }

                    }
                    rowsArr.push(rowObj);
                });
                return rowsArr;
            } else
                return [];
        }
        /**
         * Creator : Deepak
         * Function : gets the required meta data from report
         */
        function getReportMetaData(reportMetaData, reportExtendedMetaData) {
            var groupingBaseArr = [];
            if (reportMetaData.groupingsDown.length > 0) {
                angular.forEach(reportMetaData.groupingsDown, function (groupingDownObj) {
                    var groupingDownKey = groupingDownObj.name;
                    var groupingDownDisplayName = reportExtendedMetaData.groupingColumnInfo[groupingDownKey].label;
                    groupingBaseArr.push({
                        key: groupingDownKey,
                        displayName: groupingDownDisplayName
                    });
                });
                angular.forEach(reportMetaData.groupingsAcross, function (groupingAcrossObj) {
                    var groupingAcrossKey = groupingAcrossObj.name;
                    var groupingAcrossDisplayName = reportExtendedMetaData.groupingColumnInfo[groupingAcrossKey].label;
                    groupingBaseArr.push({
                        key: groupingAcrossKey,
                        displayName: groupingAcrossDisplayName
                    });
                });
            }
            var metaData = {
                'reportName': reportMetaData.name,
                'groupingBaseArr': groupingBaseArr
            };
            return metaData;
        }

        return self;
    });