angular.module('akritivEpa.summarizedMetrics')
    .factory('summarizedMetricsService', function ($q, reportsService, QueryAPI, appConfiguration) {

        var self = this;
        self.getReport = function (reportId, isSummaryView, reportFiltersURL) {
            console.log("reportID " + reportId);
            console.log("summary view " + isSummaryView);
            console.log("reportFiltersURL");
            console.log(reportFiltersURL);
            if (isSummaryView) {
                return fetchFilteredReportUrl(reportId, reportFiltersURL);
            } else if (reportFiltersURL) {
                return getFiltersForReport(reportId, reportFiltersURL);
            } else
                return reportsService.fetchJSON(reportId);
        }

        function getFiltersForReport(reportId, reportFiltersUrl) {
            console.log("get filters for report called");
            var deferred = $q.defer();
            var urlToHit = appConfiguration.getQueries().getChartDrillDownURL.query;


            var requestURL = urlToHit + reportFiltersUrl;
            console.log(requestURL);
            QueryAPI.get(requestURL).then(function (response) {
                console.log(response);
                var reportMetaDataObj = JSON.parse(response);
                /**
                 * Time being task, to be taken care later
                 */
                if (reportMetaDataObj && reportMetaDataObj.reportMetadata && reportMetaDataObj.reportMetadata.reportFilters && reportMetaDataObj.reportMetadata.reportFilters.length > 0) {
                    console.log(reportMetaDataObj.reportMetadata);
                    console.log(reportMetaDataObj.reportMetadata.reportFilters);
                    console.log(reportMetaDataObj.reportMetadata.reportFilters.indexOf(null));
                    if (reportMetaDataObj.reportMetadata.reportFilters.indexOf(null) != -1) {
                        var indexToBeSpliced = reportMetaDataObj.reportMetadata.reportFilters.indexOf(null);
                        reportMetaDataObj.reportMetadata.reportFilters.splice(indexToBeSpliced, 1);
                    }
                }
                /**
                 * Ends here
                 */

                if (response) {
                    deferred.resolve(reportsService.fetchJSON(reportId, reportMetaDataObj));
                } else {
                    deferred.reject("issue in getting data.");
                }
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }

        function fetchFilteredReportUrl(reportId, reportFiltersUrl) {
            console.log("get filters for report called");
            var deferred = $q.defer();
            var urlToHit = appConfiguration.getQueries().getChartDrillDownURL.query;


            var requestURL = urlToHit + reportFiltersUrl;
            console.log(requestURL);
            QueryAPI.get(requestURL).then(function (response) {
                console.log(response);
                var reportMetaDataObj = JSON.parse(response);
                /**
                 * Time being task, to be taken care later
                 */
                if (reportMetaDataObj && reportMetaDataObj.reportMetadata && reportMetaDataObj.reportMetadata.reportFilters && reportMetaDataObj.reportMetadata.reportFilters.length > 0) {
                    console.log(reportMetaDataObj.reportMetadata);
                    console.log(reportMetaDataObj.reportMetadata.reportFilters);
                    console.log(reportMetaDataObj.reportMetadata.reportFilters.indexOf(null));
                    if (reportMetaDataObj.reportMetadata.reportFilters.indexOf(null) != -1) {
                        var indexToBeSpliced = reportMetaDataObj.reportMetadata.reportFilters.indexOf(null);
                        reportMetaDataObj.reportMetadata.reportFilters.splice(indexToBeSpliced, 1);
                    }
                }
                /**
                 * Ends here
                 */

                if (response) {

                    deferred.resolve(reportsService.fetchJSON(reportMetaDataObj.reportMetadata.id, reportMetaDataObj));
                } else {
                    deferred.reject("issue in getting data.");
                }
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        }
        return self;
    });