angular.module('akritivEpa.summarizedMetrics')
    .controller('summarizedMetricsController', function ($scope, summarizedMetricsService, $state, $ionicPopover, dashboardMetaDataService, EPAMetaDataService, $rootScope, $timeout, $ionicScrollDelegate) {
        $scope.isPageDataLoaded = false;
        $scope.gotodashboard = function () {
            $state.go('epa.dashboard');
        }

        $scope.expandedGroups = [];
        $scope.filterTempArray = [];
        $scope.colWidth = 16.666666667;
        var reportId = null;
        // $scope.columnFilter = false;
        $scope.isViewUpdating = false;
        $scope.isError = false;
        $scope.errorObject = {
            "message": "Unable to fetch report data"
        };
        $scope.selectedGroupingArr = [];
        init();
        $scope.recordsToDisplay = 0;
        $scope.loadMoreRecords = function (totalRecords, isViewLoaded) {
            if (isViewLoaded)
                $scope.recordsToDisplay = 0;
            if (totalRecords > $scope.recordsToDisplay && !$scope.isViewUpdating) {
                $scope.isViewUpdating = true;
                $timeout(function () {
                    $scope.isViewUpdating = false;
                }, 1000);
                console.log("scrolling called");
                if ($scope.recordsToDisplay < totalRecords) {
                    console.log("more records are loaded");
                    if (($scope.recordsToDisplay + 50) <= totalRecords) {
                        $scope.recordsToDisplay += 50;
                    } else {
                        $scope.recordsToDisplay += (totalRecords - $scope.recordsToDisplay);
                    }
                    console.log($scope.recordsToDisplay);
                }
            }
        };

        function init() {
            reportId = $state.params.reportId;
            var isSummaryView = $state.params.isSummaryView;
            var pageTitle = $state.params.title;
            if (isSummaryView) {
                if (pageTitle) {
                    $scope.title = pageTitle;
                } else {
                    $scope.title = 'DETAILED REPORT';
                }

            } else {
                $scope.title = 'SUMMARIZED METRICS';
            }
            var reportFilters = $state.params.filters;
            console.log($state.params);
            if (!reportFilters)
                reportFilters = null;
            /**
             * Creator :  Shashikant - 10-03-16
             * Function : check screen size for mobile and ipad, 
             */
            var colsToDisplayAsPerDevice = 6;
            $scope.maxnumberFieldmsg = 'Select Maximum 6 Fields';
            if (!$rootScope.isIpad) {
                colsToDisplayAsPerDevice = 3;
                $scope.maxnumberFieldmsg = 'Select Maximum 3 Fields';
            }

            summarizedMetricsService.getReport(reportId, isSummaryView, reportFilters).then(function (response) {
                $scope.isError = false;
                $scope.reportHeaders = response.reportHeaders;
                if ($scope.reportHeaders.length > colsToDisplayAsPerDevice) {
                    //$scope.columnFilter = true;
                    $scope.maxColumnsToDisplay = colsToDisplayAsPerDevice;
                    $scope.currentColumnsToDisplay = colsToDisplayAsPerDevice;
                } else {
                    // $scope.columnFilter = false;
                    $scope.maxColumnsToDisplay = $scope.reportHeaders.length;
                    $scope.currentColumnsToDisplay = $scope.reportHeaders.length;

                }
                setColWidth();
                $scope.reportMetaData = response.reportMetaData;
                $scope.reportName = response.reportMetaData.reportName;
                $scope.groupingBaseArr = response.reportMetaData.groupingBaseArr;

                var visibleColumnCounter = 0;
                var visibleColumnArr = [];
                for (key in $scope.reportHeaders) {
                    if (visibleColumnCounter < colsToDisplayAsPerDevice) {
                        $scope.reportHeaders[key].isColumnVisible = true;
                        visibleColumnCounter++;
                    } else {
                        $scope.reportHeaders[key].isColumnVisible = false;

                    }
                }
                $scope.filterTempArray = angular.copy($scope.reportHeaders);
                $scope.isAscendingOrder = true;
                $scope.reportData = response.reportData;
                $scope.isPageDataLoaded = true;
            }, function (error) {
                console.log(error);
                $scope.isPageDataLoaded = true;
                $scope.isError = true;
                $scope.errorObject['helperMessage'] = error;
            });

        }
        $scope.changeHeadersDropdownSelections = function (headerIndex, key) {
            if (key) {
                $scope.currentColumnsToDisplay--;
            } else {
                $scope.currentColumnsToDisplay++;
            }

            $scope.filterTempArray[headerIndex].isColumnVisible = !key;
        };

        $scope.changeHeadersOfReport = function () {
            $scope.popover.hide();
            $scope.isPageDataLoaded = false;
            $timeout(function () {
                $scope.reportHeaders = angular.copy($scope.filterTempArray);
                setColWidth();

                $scope.isPageDataLoaded = true;
            }, 200);


        }

        function setColWidth() {
            $scope.colWidth = (100 / $scope.currentColumnsToDisplay);
        }
        $scope.sortTable = function (columnKey, columnType) {
            if (columnType.toLowerCase() !== 'html') {
                if ($scope.sortedColumnName == columnKey) {
                    $scope.isAscendingOrder = !$scope.isAscendingOrder;
                } else {
                    $scope.sortedColumnName = columnKey;
                    $scope.isAscendingOrder = true;
                }
            }
        }


        $scope.openPopover = function ($event) {
            $scope.popover.show($event);
        };


        $scope.cancalheaderofReports = function () {
            $scope.popover.hide();
        }

        // .fromTemplateUrl() method
        $ionicPopover.fromTemplateUrl('my-popover.html', {
            scope: $scope
        }).then(function (popover) {
            $scope.popover = popover;
        });

        $scope.toggleGroupView = function (groupKey, isFirstTime) {
            $ionicScrollDelegate.resize();
            if (isFirstTime && $scope.expandedGroups.length == 0) {
                $scope.expandedGroups.push(groupKey);
            } else if (!isFirstTime) {
                if ($scope.expandedGroups.indexOf(groupKey) != -1) {
                    $scope.expandedGroups.splice($scope.expandedGroups.indexOf(groupKey), 1);
                } else {
                    $scope.expandedGroups.push(groupKey);
                }
            }

        };

        $scope.isGroupOpen = function (groupKey) {
            return $scope.expandedGroups.indexOf(groupKey) != -1;
        };
        /**
         * Creator : Deepak
         * Function : when clicking button on summarized metrics report, opens up detailed report
         */
        $scope.openDetailedReport = function (url) {
            var title = null;
            if (url && url.toLowerCase().indexOf('rpun') != -1) {
                title = "Summary Report"
            } else {
                title = "Detailed Report"
            }

            console.log("url to go " + url);
            $state.go('epa.summarizedMetrics', {
                'reportId': reportId,
                'filters': url,
                'isSummaryView': true,
                'title': title
            });
        };

        $scope.goBackInReport = function () {
            if ($scope.selectedLevel == -1) {

                $scope.selectedLevel = $scope.selectedGroup = $scope.selectedGroupingArr[$scope.selectedGroupingArr.length - 1].lastSelectedLevel
            } else {
                $scope.selectedLevel--;

            }
            $scope.selectedGroup = $scope.selectedGroupingArr[$scope.selectedGroupingArr.length - 1].lastSelectedObj;
            $scope.selectedGroupingArr.splice($scope.selectedGroupingArr.length - 1, 1);

        };
        $scope.drillDownToSelected = function (groupingBaseName, groupingsObj, currentLevel, lastGroupingObj) {
            $scope.selectedGroupingArr.push({
                'selectedGroupingName': groupingBaseName,
                'selectedGroupingValue': groupingsObj.label,
                'lastSelectedObj': lastGroupingObj,
                'lastSelectedLevel': currentLevel
            });

            if (groupingsObj.groupings.length > 0)
                $scope.selectedLevel = currentLevel + 1;
            else {
                $scope.selectedLevel = -1;
            }

            $scope.selectedGroup = groupingsObj;
        };
        $scope.initalizeBase = function () {
            if (!$scope.selectedGroup) {
                $scope.selectedGroup = $scope.reportData;
                $scope.selectedLevel = $scope.reportData.groupings.length > 0 ? 1 : -1
            }
        };

    });

angular.module('akritivEpa.summarizedMetrics')
    .filter('sortReport', function () {
        return function (tableData, key, isAscendingOrder) {
            if (key) {
                var copyData = angular.extend([], tableData);
                if (isAscendingOrder)
                    copyData.sort(sortAscending);
                else
                    copyData.sort(sortDescending);

                function sortAscending(a, b) {
                    if (a[key].value != undefined && a[key].value != null && (b[key].value == undefined || b[key].value == null)) {
                        return 1;
                    }
                    if ((a[key].value == undefined || a[key].value == null) && b[key].value != undefined && b[key].value != null) {
                        return -1;
                    }
                    if ((a[key].value == undefined || a[key].value == null) && (b[key].value == undefined || b[key].value == null)) {
                        return 0;
                    }
                    if (typeof a[key].value == 'object') {
                        var val1 = a[key].value;
                        var val2 = b[key].value;
                        return val1.amount - val2.amount;
                    } else if (typeof a[key].value == 'string') {
                        return a[key].value.localeCompare(b[key].value);
                    } else {
                        return a[key].value - b[key].value;
                    }
                }

                function sortDescending(a, b) {
                    if (a[key].value != undefined && a[key].value != null && (b[key].value == undefined || b[key].value == null)) {
                        return -1;
                    }
                    if ((a[key].value == undefined || a[key].value == null) && b[key].value != undefined && b[key].value != null) {
                        return 1;
                    }
                    if ((a[key].value == undefined || a[key].value == null) && (b[key].value == undefined || b[key].value == null)) {
                        return 0;
                    }
                    if (typeof a[key].value == 'object') {
                        var val1 = a[key].value;
                        var val2 = b[key].value;
                        return val2.amount - val1.amount;
                    } else if (typeof a[key].value == 'string') {
                        return b[key].value.localeCompare(a[key].value);
                    } else {
                        return b[key].value - a[key].value;
                    }
                }
                return copyData;
            } else
                return tableData;

        };
    });


angular.module('akritivEpa.summarizedMetrics')
    .directive('compile', function ($compile) {
        return {
            replace: true,
            restrict: 'A',
            link: function (scope, elem, attrs) {
                var html = attrs.compile;
                if (html.indexOf("<img") == 0) {
                    while (html.indexOf('src="/') != -1) {
                        var index = html.indexOf('src="/') + 4;
                        html = html.slice(0, index + 1) + html.slice(index + 2);
                    }
                    elem.append(html);
                } else
                if (html.indexOf("<a") == 0) {
                    var re = /\>(.*)\<+/ig;
                    var buttonText = html.match(re).toString();
                    buttonText = buttonText.substring(1, buttonText.length - 1);
                    var urlToGo = getUrlFromLink(html);

                    function getUrlFromLink(link) {
                        link = link.substring(link.indexOf('?') + 1);
                        link = link.substring(0, link.indexOf("\""));
                        return link;
                    }

                    updatedHtml = "<button class='button blue-button' ng-click=openDetailedReport('" + urlToGo + "')>" + buttonText + "</button>";
                    var compiledHtml = $compile(updatedHtml)(scope);
                    elem.append($compile(updatedHtml)(scope));
                } else {
                    elem.append(html);
                }
                $compile(elem.contents())(scope);
            }
        }


    });