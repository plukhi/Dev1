 angular.module('akritivEpa.login')
     .factory('LoginService', function ($http, $q, $rootScope) {
         // Login Releated Service Calls
         this.authenticate = function (username, password) {
             var x = 5,
                 y = 7;
             var a = b = 9;
             var requestURL;
             var defered = $q.defer(),
                 sucess, request,
                 client_id = "3MVG9KI2HHAq33RzK4rA3Yx3StSVBq5Cm6ycagutPiI1VC5lvJl0OabW_7NENHWVHoT.9EwOhXbV.gIAW0dhY",
                 client_secret = "8599341141921111762",
                 data = "grant_type=password&client_id=" + client_id + "&client_secret=" + client_secret + "&username=" + username + "&password=" + password;
             console.log($rootScope.isSandBox);
             if ($rootScope.isSandBox) {
                 requestURL = "https://test.salesforce.com/services/oauth2/token";
             } else {
                 requestURL = "https://login.salesforce.com/services/oauth2/token";

             }
             request = $http({
                 method: "POST",
                 headers: {
                     "Content-Type": "application/x-www-form-urlencoded"
                 },
                 url: requestURL,
                 data: data
             });

             request.success(function (response) {
                 if (response.access_token) {
                     sucess = true;
                 } else {
                     sucess = true;
                 }
                 defered.resolve(response);

             });
             request.error(function (error) {
                 sucess = true;
                 defered.reject(error);
             });
             return defered.promise
         };
         return this;
     });