angular.module('akritivEpa.login')
    .controller('loginCtrl', function ($scope, $state, LoginService, AppData, $rootScope, $ionicPopover) {

        $scope.data = {};
//        $scope.data.username = "google.user@smartview.dev2";
//        $scope.data.password = "welcome@123";
        $scope.data.username = "report.user@epa.qa";
        $scope.data.password = "Admin@123";
//        $scope.data.username = "genpact.user@epa.demo";
//        $scope.data.password = "demouser1";
        $scope.loader = false;
        $scope.errorFound = false;
        $scope.errMsg = "";
        $rootScope.isSandBox = false;
        $scope.getValueRadio = function (newVal) {
            $rootScope.isSandBox = newVal;
        };
        $scope.login = function () {
            if ($rootScope.isOnline()) {
                if ($scope.data.username && $scope.data.username != "" && $scope.data.password && $scope.data.password != "") {
                    $scope.loader = true;
                    LoginService.authenticate($scope.data.username, $scope.data.password, $scope.isSandBox).then(function (result) {
                            AppData.set("loginData", result);
                            if (result.access_token && result.instance_url) {
                                initializeForce(result.access_token, result.instance_url);
                                $scope.loader = false;
                                $state.go('loading');
                            } else {
                                $scope.errorFound = true;
                                $scop.errMsg = "Sorry,Invalid Username or Password";
                                $scope.data.password = "";
                                $scope.loader = false;
                            }
                        },
                        function (error) {
                            $scope.errorFound = true;
                            $scope.errMsg = "Unable to login. Check your credentials or contact your administrator";
                            console.log("Error Came in processing request");
                            $scope.loader = false;
                        });
                } else {
                    $scope.errorFound = true;
                    $scope.errMsg = "Please fill both username and password to login";
                    console.log("username and/or password not filled");
                }
            } else {
                $scope.errorFound = true;
                $scope.errMsg = "Check your internet connection!";
                $scope.loader = false;
            }
        };

        $ionicPopover.fromTemplateUrl('templates/popover.html', {
            scope: $scope,
        }).then(function (popover) {
            $scope.popover = popover;
        });
        $scope.closePopover = function () {
            $scope.popover.hide();
        };


        function initializeForce(accessToken, instanceUrl) {
            localStorage.access_token = accessToken;
            localStorage.instance_url = instanceUrl;
            force.init({
                apiVersion: 'v30.0',
                accessToken: accessToken,
                instanceURL: instanceUrl,
                proxyURL: instanceUrl,
                refreshToken: accessToken,
            });
        }

    });