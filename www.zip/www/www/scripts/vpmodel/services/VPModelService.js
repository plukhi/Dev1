angular.module('akritivEpa.vpmodel')
    .factory("VPModelService", function ($http,AppData, $q, appConfig) {

        return {

            fetchJSON: function (api) {
                var deferred = $q.defer();
//                if (appConfig.demoMode) {
                if (true) {
                    $http.get('js/static-data/vpmodel.json')
                        .success(function (data) {
                            deferred.resolve(data);
                        })
                        .error(function (error) {
                            deferred.reject(error);
                        });
                } else {
                    var obj = {
                        "path": api,
                        "method": "POST",
                        "data": {}
                    };

                    force.request(obj,
                        function (response) {
                            // console.log("executive summary");
                            // console.log(response);
                            deferred.resolve(response);
                        },
                        function (error) {
                            if (typeof error != "string")
                                error = error[0];
                            error = errorModule.throwException(error, false);
                            deferred.reject(error);
                        });
                }
                return deferred.promise;


            }
        }
    });