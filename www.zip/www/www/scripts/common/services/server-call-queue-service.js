angular.module('akritivEpa')
    .factory('ServerCallQueue', ['appConfig',
    function (appConfig) {
            var queue = {};

            var uniqueName = function (reportId) {
                var key;
                angular.forEach(appConfig.settings, function (val, k) {
                    if (val.reportId == reportId) {
                        key = k;
                    }
                });
                return key;
            }

            var clearQueue = function () {
                //        console.log("clearing off all the reportIds that is with status = done");
                angular.forEach(queue, function (val, key) {
                    if (val = "done") {
                        delete queue[key];
                    }
                });
            }

            var fillInQueue = function (reportId) {
                //        clearQueue();
                var isInQueue = false;
                if (queue.hasOwnProperty(reportId)) {
                    if (queue[reportId] == "progress") {
                        isInQueue = true;
                        //                console.log("call for reportId = "+uniqueName(reportId)+" is already in progress");
                    }
                }
                if (!isInQueue) {
                    //            console.log("filling in this reportId = "+uniqueName(reportId)+", with status = progress");
                    queue[reportId] = "progress";
                }
                return isInQueue;
            }

            var setAsDone = function (reportId) {

                var isInQueue = false;
                if (queue.hasOwnProperty(reportId)) {
                    if (queue[reportId] == "progress") {
                        isInQueue = true;
                    }
                }
                if (isInQueue) {
                    //            console.log("filling in this reportId = "+uniqueName(reportId)+", with status = done");
                    queue[reportId] = "done";
                } else {
                    if (queue.hasOwnProperty(reportId)) {
                        //                console.log("the reportId = "+uniqueName(reportId)+", is already with the status = done");
                    } else {
                        //                console.log("the reportId = "+uniqueName(reportId)+", is not present in queue. So cant set status = done");
                    }
                }
                return isInQueue;
            }

            var removeFromQueue = function (reportId) {
                if (queue.hasOwnProperty(reportId)) {
                    delete queue[reportId];
                }
            }
            return {
                fillInQueue: function (reportId) {
                    return fillInQueue(reportId);
                },
                setAsDone: function (reportId) {
                    return setAsDone(reportId);
                },
                removeFromQueue: function (reportId) {
                    removeFromQueue(reportId);
                }
            }
    }
]);