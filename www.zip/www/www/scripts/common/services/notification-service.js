angular.module('akritivEpa').factory('notificationService', function ($q, QueryAPI, appConfiguration) {
    var self = this;
    self.getAlertsList = function () {
        var deferred = $q.defer();
        var queryObj = appConfiguration.getQueries().getAlerts;
        QueryAPI.executeQuery(queryObj.query).then(function (response) {
            if (response.done) {
                deferred.resolve(buildAlertsArr(response.records, queryObj.params));
            } else {
                deferred.resolve([]);
            }
        }, function (error) {
            deferred.reject(error);
        });
        return deferred.promise;
    };

    self.getNotificationsList = function () {
        var deferred = $q.defer();
        var requestObj = {
            "path": "/services/data/v30.0/chatter/feeds/news/me/feed-items"
        };
        force.request(requestObj, function (response) {
            if (response.items) {
                deferred.resolve(buildNotificationsArr(response.items));
            } else {
                deferred.resolve([]);
            }

        }, function (error) {
            deferred.reject(error);
        });
        return deferred.promise;
    };

    function buildAlertsArr(alerts, params) {
        console.log(alerts);
        var recordsArr = [];
        angular.forEach(alerts, function (alert) {
            recordsArr.push(new Alert(alert, params));
        });
        console.log(recordsArr);
        return recordsArr;
    }

    function Alert(alertObj, params) {
        var self = this;
        angular.forEach(params, function (value, key) {
            self[key] = alertObj[value];
        });
        /*this.id = alertObj.Id;
        this.message = alertObj.asv__Message__c;
        this.metric = alertObj.asv__MetricName__c;
        this.reportDate = alertObj.asv__ReportDate__c;*/
    }

    function buildNotificationsArr(notificationItems) {
        console.log(notificationItems);
        var notificationsArr = [];
        angular.forEach(notificationItems, function (item) {
            notificationsArr.push({
                'name': item.actor.name,
                'message': item.body.text,
                'messageTime': item.createdDate,
            })
        });
        return notificationsArr;
    }
    return self;
});