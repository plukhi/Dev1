angular.module('akritivEpa')
    .factory('Sorting', ['$location',

    function ($location) {

            var months = {
                    january: 0,
                    february: 1,
                    march: 2,
                    april: 3,
                    may: 4,
                    june: 5,
                    july: 6,
                    august: 7,
                    september: 8,
                    october: 9,
                    november: 10,
                    december: 12
                },
                monthsShort = {
                    jan: 0,
                    feb: 1,
                    mar: 2,
                    apr: 3,
                    may: 4,
                    jun: 5,
                    jul: 6,
                    aug: 7,
                    sep: 8,
                    oct: 9,
                    nov: 10,
                    Dec: 12
                },
                ifMonth = false,
                ifMonthShort = false,
                computedValA = "",
                computedValB = "";

            function checkMonth(a, b) {
                try {
                    computedValA = a[column].split('-')[0].toLowerCase();
                    computedValB = b[column].split('-')[0].toLowerCase();
                } catch (err) {
                    //                    console.log("no value for computed A or B");
                    computedValA = "";
                    computedValB = "";
                };
                if (typeof a == "string") {
                    a[column] = a[column].toLowerCase();
                }
                if (typeof b == "string") {
                    b[column] = b[column].toLowerCase();
                }
                try {
                    if (!ifMonth || !ifMonthShort) {
                        angular.forEach(months, function (v, i) {
                            if (computedValA == i)
                                ifMonth = true;
                        });
                        angular.forEach(monthsShort, function (v, i) {
                            if (computedValA == i)
                                ifMonthShort = true;
                        });
                    }
                    //                    console.log("computed values for A and B : "+computedValA+" ; "+computedValB);
                } catch (err) {
                    //                    console.log("the sorting is not on months");
                    ifMonth = false;
                    ifMonthShort = false;
                };
            }

            function ascending(data, column) {
                console.log(data);
                console.log(column);
                var newData = [];
                //  console.log("ascending:" + column)

                computedValB = "";
                ifMonth = false;
                ifMonthShort = false;

                function compare(a, b) {
                    //                console.log("comapring");
                    // checkMonth(a, b);
                    console.log(column);
                    if (ifMonth) {
                        return months[computedValA] - months[computedValB];
                    } else if (ifMonthShort) {
                        return months[computedValA] - months[computedValB];
                    } else {
                        console.log("comparing");
                        if (a[column] < b[column])
                            return -1;
                        if (a[column] > b[column])
                            return 1;
                    }
                    return 0;
                }

                function dateForm(str) {
                    var d = new Date(str);
                    var n = d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
                    return n;
                }


                data.sort(compareAs);

                function compareAs(x, y) {
                    // Comparing if either of the value is null
                    if ((!x[column] || x[column] == '' || x[column] == null) && y[column] && y[column] != '' && y[column] != null) {
                        return -1;
                    }
                    if ((!y[column] || y[column] == '' || y[column] == null) && x[column] && x[column] != '' && x[column] != null) {
                        return 1;
                    }
                    if ((x[column] == '' || x[column] == null) && (y[column] == '' || y[column] == null)) {
                        return 0;
                    }
                    a = angular.extend({}, x);
                    b = angular.extend({}, y);
                    //removing extra whitespaces and changing to lower case for comparison
                    a[column] = (typeof x[column] == 'string') ? x[column].toLowerCase().trim() : x[column];
                    b[column] = (typeof y[column] == 'string') ? y[column].toLowerCase().trim() : y[column];

                    if (typeof (a[column]) == "string") {
                        if (a[column].indexOf("/") != -1) {
                            var a1 = new Date(Date.parse(a[column]));
                            var b1 = new Date(Date.parse(b[column]));
                            return a1 - b1;
                        } else {
                            if (Date.parse(a[column]) == null) {
                                return a[column].localeCompare(b[column]);
                            } else {
                                var a = new Date(Date.parse(a[column]));
                                var b = new Date(Date.parse(b[column]));
                                return a - b;
                            }
                        }
                    } else {
                        return a[column] - b[column];

                    }
                }
                return data;
                // 
            };

            function descending(data, column) {
                //            console.log("inside sorting factory's descending fn. for column : " + column);
                //            console.log("with data : ");
                //            console.log(data);
                // console.log("descending:" + column)

                computedValA = "";
                computedValB = "";
                ifMonth = false;
                ifMonthShort = false;

                function compare(a, b) {
                    //  checkMonth(a, b);

                    //                console.log(a[column]);
                    if (ifMonth) {
                        return months[computedValB] - months[computedValA];
                    } else if (ifMonthShort) {
                        return months[computedValB] - months[computedValA];
                    } else {
                        //                    console.log("comapring");
                        if (a[column] > b[column])
                            return -1;
                        if (a[column] < b[column])
                            return 1;
                    }
                    return 0;
                }

                data.sort(compareAs);

                function compareAs(x, y) {
                    if ((!x[column] || x[column] == '' || x[column] == null) && y[column] && y[column] != '' && y[column] != null) {
                        return 1;
                    }
                    if ((!y[column] || y[column] == '' || y[column] == null) && x[column] && x[column] != '' && x[column] != null) {
                        return -1;
                    }
                    if ((x[column] == '' || x[column] == null) && (y[column] == '' || y[column] == null)) {
                        return 0;
                    }
                    a = angular.extend({}, x);
                    b = angular.extend({}, y);
                    a[column] = (typeof x[column] == 'string') ? x[column].toLowerCase().trim() : x[column];
                    b[column] = (typeof y[column] == 'string') ? y[column].toLowerCase().trim() : y[column];
                    if (typeof (a[column]) == "string") {
                        if (a[column].indexOf("/") != -1) {
                            var a1 = new Date(Date.parse(a[column]));
                            var b1 = new Date(Date.parse(b[column]));
                            return b1 - a1;
                        } else {

                            if (Date.parse(a[column]) == null) {
                                return b[column].localeCompare(a[column]);
                            } else {
                                var a = new Date(Date.parse(a[column]));
                                var b = new Date(Date.parse(b[column]));
                                return b - a;
                            }
                        }
                    } else {
                        return b[column] - a[column];

                    }
                }
                return data;

            };
            return {
                ascending: function (data, column) {
                    if ($location.url().split('/')[2] == "summarizedMetrics")
                        column = column.toLowerCase();
                    //                console.log("checking the values of 1st and 2nd row for this column");
                    //                console.log($location.url().split('/')[2]);
                    //                console.log(data[0][column]);
                    //                console.log(data[1][column]);
                    return ascending(data, column);
                },
                descending: function (data, column) {
                    if ($location.url().split('/')[2] == "summarizedMetrics")
                        column = column.toLowerCase();
                    //                console.log("checking the values of 1st and 2nd row for this column");
                    //                console.log($location.url());
                    //                console.log(data[0][column]);
                    //                console.log(data[1][column]);
                    return descending(data, column);
                }
            }
    }
]);