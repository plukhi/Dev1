angular.module('akritivEpa')
    .factory("revokeToken", function ($q, $http, $state, AppData, $window, $sessionStorage) {

        return {
            removeToken: function () {
                // var token = force.getToken();
                var s = AppData.get("loginData");
                console.log("value in s");
                console.log(s);
                if (s == null) {
                    s = $sessionStorage["loginData"];
                }
                var obj = {
                    "access_token": s.access_token,
                    "instance_url": s.instance_url
                }
                console.log(obj);
                var defered = $q.defer(),
                    sucess = true;

                force.request({
                        // "path": '/services/apexrest/MobileLogout',
                        "path": '/services/oauth2/revoke?token=' + s.access_token,
                        "method": "GET",
                        //"method": "POST",
                        // "data": obj
                    },
                    function (success) {
                        console.log("token revoked successfuly");
                        //console.log(success);

                        //                    if (success.statusCode == "200") {
                        //                        defered.resolve(success);
                        //                    } else {
                        //                        defered.reject("Logout status not 200");
                        //                    }
                        defered.resolve(sucess);
                    },
                    function (error) {
                        console.log("token revoke not possible");
                        console.log(error);
                        defered.reject(error);
                    });
                return defered.promise;
            },

            //        getSessionId: function() {
            //
            //            var defered = $q.defer();
            //            force.request({
            //                    "path": '/services/apexrest/SessionID',
            //                    "method": "POST",
            //                    "data": {}
            //                },
            //                function(success) {
            //                    //  console.log("getSessionId  successfuly");
            //                    //  console.log(success);
            //                    defered.resolve(success);
            //                    // $window.__sfdcSessionId = success.sessionId;
            //
            //                },
            //                function(error) {
            //                    console.log("getSessionId  not possible");
            //                    console.log(error);
            //                    defered.reject(error);
            //                });
            //            return defered.promise;
            //
            //        },

            testApex: function () {
                var defered = $q.defer();
                //     __sfdcSessionId = AppData.get("sessionId"),

                //  result = AppData.get("loginData");
                // sforce.connection.init(__sfdcSessionId, result.instance_url); // here pass current session id of the org from which you are making request.
                //            //
                //            sforce.connection.remoteFunction({
                //                url: "https://login.salesforce.com",
                //                requestHeaders: {
                //                    "Authorization": "Bearer " + __sfdcSessionId,
                //                    "Content-Type": "application/json"
                //                }, // here pass the session id of the org in which you have your REST service
                //                method: "POST",
                //                onSuccess: function(response) {
                //                    console.log(response);
                //                },
                //                onFailure: function(response) {
                //                    alert("Failed" + response)
                //                }
                //            });
                var q = "SELECT Description,Id,Priority,Status,Subject,CreatedDate FROM Task ORDER BY CreatedDate DESC NULLS LAST";
                console.log("forcetk.Client in testApex:" + forcetk.Client.prototype.query);
                forcetk.Client.prototype.query(q, function (success) {
                    //  console.log("layoutResults in testApex");
                    //  console.log(success);
                    defered.resolve(success);
                }, function (error) {
                    console.log("queryFailed in testApex");
                    console.log(error);
                    defered.reject(error);
                });

                //            sforce.connection.query("SELECT Description,Id,Priority,Status,Subject,CreatedDate FROM Task ORDER BY CreatedDate DESC NULLS LAST", callback);
                //            var callback = {
                //                onSuccess: layoutResults,
                //                onFailure: queryFailed,
                //            };
                //
                //            function queryFailed(error) {
                //                console.log("queryFailed in testApex");
                //                console.log(error);
                //                defered.reject(error);
                //            }
                //
                //            function layoutResults(queryResult, source) {
                //                if (queryResult.size > 0) {
                //                    var records = queryResult.getArray('records');
                //                    console.log("layoutResults in testApex");
                //                    console.log(records);
                //                    defered.resolve(records);
                //                }
                //            }
                defered.promise;
            }

        }
    });