angular.module('akritivEpa')
    .factory('QueryAPI', ['$q', '$rootScope', 'errorModule', 'ServerCallQueue', '$ionicLoading', '$state', '$rootScope',
    function ($q, $rootScope, errorModule, ServerCallQueue, $ionicLoading, $state, $rootScope) {

            var self = this;

            self.executeQuery = function (queryString) {
                var deferred = $q.defer();
                if ($rootScope.isOnline()) {
                    force.query(queryString, function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        console.log(error);
                        console.log(typeof error);
                        if (typeof error == 'string') {
                            deferred.reject(error);
                        } else {
                            if (error[0].errorCode && error[0].errorCode == "INVALID_SESSION_ID") {
                                $ionicLoading.show({
                                    template: "Session Expired.",
                                    noBackdrop: true,
                                    duration: 3000
                                });
                                $state.go('login');
                                deferred.reject(error[0].message);
                            } else {
                                deferred.reject(error[0].message);
                            }
                        }
                    });
                } else {
                    deferred.reject("No Internet Connection");
                }

                return deferred.promise;
            };

            self.post = function (requestURL, requestParams) {
                console.log("requestURL " + requestURL);
                console.log("requestParams " + JSON.stringify(requestParams));
                var deferred = $q.defer();
                if ($rootScope.isOnline()) {
                    var request = {
                        "path": requestURL,
                        "method": "POST",
                        "contentType": "application/json"
                    }
                    if (requestParams)
                        request['data'] = requestParams;
                    console.log(request);
                    force.request(request, function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        console.log(error);
                        console.log(typeof error);
                        if (typeof error == 'string') {
                            deferred.reject(error);
                        } else {
                            if (error[0].errorCode && error[0].errorCode == "INVALID_SESSION_ID") {
                                $ionicLoading.show({
                                    template: "Session Expired.",
                                    noBackdrop: true,
                                    duration: 3000
                                });
                                $state.go('login');
                                deferred.reject(error[0].message);
                            } else {
                                deferred.reject(error[0].message);
                            }
                        }
                    });
                } else {
                    deferred.reject("No Internet Connection");
                }

                return deferred.promise;
            };

            self.get = function (requestURL) {
                console.log("requestURL " + requestURL);
                var deferred = $q.defer();
                if ($rootScope.isOnline()) {
                    var request = {
                        "path": requestURL,
                        "method": "GET",
                        "contentType": "application/json"
                    }
                    force.request(request, function (response) {
                        deferred.resolve(response);
                    }, function (error) {
                        console.log(error);
                        console.log(typeof error);
                        if (typeof error == 'string') {
                            deferred.reject(error);
                        } else {
                            if (error[0].errorCode && error[0].errorCode == "INVALID_SESSION_ID") {
                                $ionicLoading.show({
                                    template: "Session Expired.",
                                    noBackdrop: true,
                                    duration: 3000
                                });
                                $state.go('login');
                                deferred.reject(error[0].message);
                            } else {
                                deferred.reject(error[0].message);
                            }
                        }
                    });
                } else {
                    deferred.reject("No Internet Connection");
                }
                return deferred.promise;
            };

            return self;
    }]);