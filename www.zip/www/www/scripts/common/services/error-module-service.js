angular.module('akritivEpa').factory('errorModule', function ($log, $http, appConfig, $rootScope) {

    // Logs to be written to a Remote Server
    function logToRemote(object) {
        // Will be implemented when a Web Service is available for the same

    }

    function findMessage(code) {
        var message;
        angular.forEach(new messages(), function (value, key) {
            if (code == value.Code)
                message = value.Message;
        });
        return message;
    }

    var messages = function () {
        return [{
                "Code": "100",
                "Message": "No network connection."
            }, {
                "Code": "101",
                "Message": "First error of the app."
            }, {
                "Code": "102",
                "Message": "Second error of the app."
            }, {
                "Code": "111",
                "Message": "Server did not respond for Overall SLAs"
            }, {
                "Code": "112",
                "Message": "Server did not respond for CPI SLAs"
            }, {
                "Code": "113",
                "Message": "Server did not respond for KPI SLAs"
            }, {
                "Code": "114",
                "Message": "Server did not respond for SLA Trends by Time"
            }, {
                "Code": "115",
                "Message": "Server did not respond for monthly SLA Trends by Region"
            }, {
                "Code": "116",
                "Message": "Server did not respond for quarterly SLA Trends by Region"
            }, {
                "Code": "117",
                "Message": "Server did not respond for yearly SLA Trends by Region"
            }, {
                "Code": "118",
                "Message": "! No Executive Summary data uploaded. !"
            }, {
                "Code": "119",
                "Message": "Report not set by Salesforce Administrator."
            }, {
                "Code": "200",
                "Message": "Data is unavailable. Cannot show Overall SLA data."
            }, {
                "Code": "201",
                "Message": "Data is unavailable. Cannot show CPI SLA data."
            }, {
                "Code": "202",
                "Message": "Data is unavailable. Cannot show KPI SLA data."
            }, {
                "Code": "203",
                "Message": "No data for SLA MET"
            }, {
                "Code": "204",
                "Message": "No data for SLA NOT-MET"
            }, {
                "Code": "205",
                "Message": "No data for SLA EXCEED"
            }, {
                "Code": "210",
                "Message": "Data is unavailable. Cannot show SLA by Time data."
            }, {
                "Code": "211",
                "Message": "Data unavailable for AMERICAS"
            }, {
                "Code": "212",
                "Message": "Data unavailable for APAC"
            }, {
                "Code": "213",
                "Message": "Data unavailable for EMEA"
            }, {
                "Code": "214",
                "Message": "Data Not available for this month for Americas"
            }, {
                "Code": "215",
                "Message": "Data Not available for this month for APAC"
            }, {
                "Code": "216",
                "Message": "Data Not available for this month for EMEA"
            }, {
                "Code": "220",
                "Message": "Data is unavailable. Cannot show Monthly SLA trends by Region data."
            }, {
                "Code": "221",
                "Message": "Data is unavailable. Cannot show Quarterly SLA trends by Region data."
            }, {
                "Code": "222",
                "Message": "Data is unavailable. Cannot show Yearly SLA trends by Region data."
            }, {
                "Code": "223",
                "Message": "CPI not found for "
            }, {
                "Code": "224",
                "Message": "KPI not found for "
            }, {
                "Code": "230",
                "Message": "There is no data to display with the filters that you applied"
            }, {
                "Code": "231",
                "Message": "No data found for summarized metrics"
            }, {
                "Code": "232",
                "Message": "No data found for METRICS"
            }, {
                "Code": "233",
                "Message": "No data found for detailed metrics"
            }, {
                "Code": "240",
                "Message": "Cant show filtermetrics data"
            }, {
                "Code": "NOT_FOUND",
                "Message": "Resource not found on server!"
            }, {
                "Code": "FORBIDDEN",
                "Message": "You do not have access to the resource.!"
            }

        ]
    };

    var errorMsgQueue = [];

    return {
        throwException: function (code, showAsError) {
            console.log(code);
            sendToRemote = appConfig.remoteLogging;
            code = code || "100";
            var obj = {
                "Code": "007",
                "Message": ""
            };

            if (code !== null && typeof code === 'string' && isNaN(code)) {
                obj.Message = code;
            } else {
                obj.Code = code;
                if (code !== null && typeof code === 'object') {
                    if (!code.hasOwnProperty('errorCode'))
                        obj.Code = 100;
                    else
                        obj.Code = code.errorCode;
                }
                obj.Message = findMessage(obj.Code);
                if (!obj.Message) {
                    obj.Message = "Server responded unexpectedly, please try after some time.";
                    obj.errorMessage = code.message;
                }
            }

            // Add timestamp for the Error
            obj.timeStamp = new Date();


            if (sendToRemote)
                logToRemote(obj);

            if (showAsError) {
                errorMsgQueue.push(obj);
                $rootScope.$broadcast("showErrorEvent", errorMsgQueue.length);
            }

            $log.error(obj);
            return obj.Message;
        },
        log: function (message, type, sendToRemote) {
            sendToRemote = sendToRemote || appConfig.remoteLogging;

            if (sendToRemote)
                logToRemote(obj);

            if (typeof type === null || typeof type === "undefined")
                $log.log(message);
            else if (type === "warn")
                $log.warn(message);
            else if (type === "debug")
                $log.debug(message);
            else if (type === "info")
                $log.info(message);
        },
        queueLength: function () {
            return errorMsgQueue.length;
        },
        getNextErrorMsg: function () {
            var errorObj = errorMsgQueue.shift();
            return errorObj.Message;
        }
    }
});