angular.module('akritivEpa')
    .factory('ServerConfig', ['QueryAPI', '$q', 'AppData', 'errorModule', 'appConfig',
    function (QueryAPI, $q, AppData, errorModule, appConfig) {
            //        function convertJSONtoArray(settingsCollection) {
            //            var settingsList = {};
            //            for (key in settingsCollection) {
            //                settingsList[settingsCollection[key]["Name"]] = {
            //                    "reportId": settingsCollection[key]["ReportId__c"]
            //                };
            //            }
            //            return settingsList;
            //        }
            function convertJSONtoArray(settingsCollection) {
                var settingsList = {};
                // console.log(settingsCollection);
                for (var i = 0; i < settingsCollection.length; i++) {
                    for (key in settingsCollection[i]) {

                        if (key == "Name") {
                            settingsList[settingsCollection[i].Name] = {
                                "reportId": settingsCollection[i].ReportId__c
                            };
                        }
                    }
                }
                console.log("settingsList");
                console.log(settingsList);
                return settingsList;
            }

            return {
                fetchFromServer: function () {
                    var deferred = $q.defer();
                    var configSettings = AppData.get("ConfigSettings");
                    if (configSettings != null) {
                        deferred.resolve(configSettings);
                    } else {
                        var queryText = "SELECT ComponentName__c,Id,LastModifiedDate,Name,Query__c,ReportFilter__c,ReportId__c,ScreenName__c FROM MobileApp__c";

                        QueryAPI.query(queryText).then(
                            function (data) {
                                appConfig.settings = convertJSONtoArray(data.records);
                                var viewCounts = 0;

                                for (var i = 0; i < data.records.length; i++) {
                                    if (data.records[i].Name == "barDash-year" || data.records[i].Name == "barDash-month" || data.records[i].Name == "barDash-quarter" || data.records[i].Name == "areaDash" || data.records[i].Name == "pieDash1" || data.records[i].Name == "pieDash2" || data.records[i].Name == "pieDash3")
                                        viewCounts++;
                                }
                                //console.log("viewcounts:  "+viewCounts);
                                if (viewCounts == 7)
                                    deferred.resolve("success");
                                else
                                    deferred.reject("Incompatible configuration object found for this user instance. Cannot proceed further");
                            },
                            function (error) {
                                if (typeof error != "string")
                                    error = error[0];
                                error = errorModule.throwException(error, true);
                                var errorMsg = "Authentication Failed :";
                                deferred.reject(errorMsg);
                            }
                        );
                    }
                    return deferred.promise;
                },

                //            fetchFromServer1: function() {
                //                var deferred = $q.defer();
                //                var obj = {
                //                    "method": "POST",
                //                    "path": "/services/apexrest/MobileApp",
                //                    "data": {}
                //                };
                //
                //                force.request(obj, function(success) {
                //                    // console.log("serverconfig data");
                //                    //  console.log(success);
                //                    appConfig.settings = convertJSONtoArray(success.data);
                //                    deferred.resolve("success");
                //                }, function(error) {
                //                    console.log("serverconfig data error");
                //                    console.log(error);
                //                    deferred.reject(error);
                //                });
                //                return deferred.promise;
                //            }
            }
    }
]);