angular.module('akritivEpa')
    .factory("AppData", ['$localStorage', '$q', '$timeout', 'errorModule', '$sessionStorage',
    function ($localStorage, $q, $timeout, errorModule, $sessionStorage) {
            var allData = {};

            return {
                set: function (key, response, setLocalNow) {
                    //                                console.log("setting in App data for key : "+key);
                    allData[key] = response;
                    if (key == "loginData") {
                        $sessionStorage[key] = response;
                    }

                    if (setLocalNow) {
                        //                    console.log("Setting localstorage for " + key);
                        // $localStorage[key] = allData[key];
                    }
                },
                get: function (key) {
                    //console.log(typeof $localStorage[key] +" for "+key);
                    if (typeof allData[key] !== 'undefined' && allData[key] != null) {
                        return allData[key];
                        //                    console.log("getting from already stored AppData service for reportId = "+key+". seems like same session");
                    } else if (typeof $localStorage[key] != 'undefined' && $localStorage[key] != null) {
                        //console.log("getting from local storage FOR " + key + ". seems like we have got a new session");
                        allData[key] = $localStorage[key];
                        return allData[key];
                    } else {
                        //                                        console.log("not getting from AppData or localstorage for reportId ="+key);
                        return null;
                    }
                },
                setLocal: function () {
                    //                console.log("in setLocal function");
                    var allKeys = Object.keys(allData);
                    var locallyStored = 0;
                    var alreadyLocal = false;

                    /* angular.forEach(allData, function (item, key) {
                        $localStorage[key] = allData[key];
                    });
                    */
                    //$localStorage["reports"] = allData;
                    return [true, true];
                },
                refresh: function () {
                    var online = navigator.onLine;
                    //                console.log("reset function");
                    //            console.log(online);

                    if (online) {
                        for (key in allData) {
                            if (key == "loginData") {} else {
                                allData[key] = "";
                            }
                        }
                        $localStorage.$reset();
                    } else {
                        errorModule.throwException(100, true);
                    }
                },
                reset: function () {
                    var online = navigator.onLine;
                    if (online) {
                        allData = {};
                        $localStorage.$reset();
                        //$sessionStorage.$reset();
                    } else {
                        errorModule.throwException(100, true);
                    }
                },
                getAllData: function () {
                    return allData;
                }
            }

    }
]);