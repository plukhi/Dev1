angular.module('akritivEpa')
    .factory('getLocalJSON', function ($http, $q, $rootScope, appConfig, $localStorage, AppData) {

        function fetchJSON(reportId) {

            var deferred = $q.defer();
            var fileUrl;

            if (reportId == '00Oo0000001FKUe')
                fileUrl = 'js/static-data/OverallSLA.json';
            else if (reportId == '00Oo0000001FKUc')
                fileUrl = 'js/static-data/CPISLA.json';
            else if (reportId == '00Oo0000001FKUd')
                fileUrl = 'js/static-data/KPISLA.json';
            else if (reportId == 'CslaFlip')
                fileUrl = 'js/static-data/CslaFlip.json';
            else if (reportId == 'KslaFlip')
                fileUrl = 'js/static-data/KslaFlip.json';
            else if (reportId == '00Oo0000001FKUh')
                fileUrl = 'js/static-data/SLA-TrendOverTim.json';
            else if (reportId == '00Oo0000001HV1X')
                fileUrl = 'js/static-data/SLA-TrendOverRegion-Mont.json';
            else if (reportId == '00Oo0000001HV1h')
                fileUrl = 'js/static-data/SLA-TrendOverRegion-Quarte.json';
            else if (reportId == '00Oo0000001HV1m')
                fileUrl = 'js/static-data/SLA-TrendOverRegion-Year.json';
            else if (reportId == 'global-feeds')
                fileUrl = 'js/static-data/global-feeds.json';
            else if (reportId == 'alerts')
                fileUrl = 'js/static-data/alerts.json';

            if (AppData.get(reportId) == null) {
                $http.get(fileUrl)
                    .success(function (data) {
                        //$localStorage[reportId] = data;
                        AppData.set(reportId, data);
                        deferred.resolve(data);
                        //console.log("data revceived for url: " + fileUrl);
                        //console.log(data);
                    })
                    .error(function (error) {
                        AppData.set(reportId, null);
                        //console.log('cant get data for ' + fileUrl);
                        // console.log('sending deferred.reject');
                        deferred.reject(error);
                    });
            } else {
                //deferred.resolve($localStorage[reportId]);
                deferred.resolve(AppData.get(reportId));
            }

            return deferred.promise;
        }

        return {
            fetchJSON: function (reportId) {
                return fetchJSON(reportId);
            }
        }
    });