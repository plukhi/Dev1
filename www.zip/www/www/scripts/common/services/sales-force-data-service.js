angular.module('akritivEpa')
    .factory('salesForceData', function () {
        var output = [];
        /* to extract data from factmap.rows with multiple filtering*/
        function extractData1(treeObj, data) {
            try {
                if (treeObj.groupings == null) {

                    var key = treeObj.key + "!T";
                    //alert("key" + key);
                    //alert("data: " + JSON.stringify(data[key]));
                    if (typeof data[key] != "undefined") {

                        for (j = 0; j < data[key].rows.length; j++) {
                            output.push(data[key].rows[j]);
                        }
                    } else {
                        $scope.errMsg = errorModule.throwException(122);
                        $scope.errorFoundtable = true;
                    }
                } else if (treeObj.groupings != null && treeObj.groupings.length > 0) {
                    for (var i = 0; i < treeObj.groupings.length; i++)
                        extractData1(treeObj.groupings[i], data);
                } else {
                    var key1 = treeObj.key;
                    //console.log("key is : " + key1);
                    if (typeof data[key1 + "!T"] != "undefined") {
                        for (j = 0; j < data[key1 + "!T"].rows.length; j++) {
                            output.push(data[key1 + "!T"].rows[j]);
                        }
                    } else {
                        $scope.errMsg = "No Data found";
                        $scope.errorFoundtable = true;
                    }
                }

            } catch (err) {
                //            console.log("error in extracting rows data from fact map : ");
                //            console.log(err);
                return err;
            }
            //        try {
            //            if (treeObj.groupings.length > 0) {
            //                console.log("check point for key no key defined");
            //                for (var i = 0; i < treeObj.groupings.length; i++)
            //                    extractData1(treeObj.groupings[i], data);
            //            } else {
            //                var key1 = treeObj.key;
            //                console.log("check point for key: " + key1)
            //                if (typeof data[key1 + "!T"] != "undefined") {
            //                    for (j = 0; j < data[key1 + "!T"].rows.length; j++) {
            //                        output.push(data[key1 + "!T"].rows[j].dataCells);
            //                    }
            //                } else {
            //                    $scope.errMsg = errorModule.throwException(122);
            //                    $scope.errorFoundtable = true;
            //                }
            //            }
            //            //  return output;
            //        } catch (err) {
            //            //            console.log("error in extracting rows data from fact map : ");
            //            //            console.log(err);
            //            return err;
            //        }
        };

        function extractAggregates(treeObj, data) {
            try {
                if (treeObj.groupings.length > 0) {
                    for (var i = 0; i < treeObj.groupings.length; i++)
                        extractAggregates(treeObj.groupings[i], data);
                } else {
                    var key1 = treeObj.key;
                    if (typeof data[key1 + "!T"] != "undefined") {
                        //                for (j = 0; j < data[key1 + "!T"].rows.length; j++) {
                        output.push(data[key1 + "!T"].aggregates);
                        //                }
                    } else {
                        $scope.errMsg = errorModule.throwException(122);
                        $scope.errorFoundtable = true;
                    }
                }
            } catch (err) {
                //            console.log("error in extracting aggregate data from fact map : ");
                //            console.log(err);
                return err;
            }
        };

        function firstLevelGroupNames(data) {
            var groups = [];
            try {
                for (var i = 0; i < data.groupingsDown.groupings.length; i++) {
                    groups.push(data.groupingsDown.groupings[i].value);
                }
            } catch (err) {
                groups.push(err);
            }
            return groups;
        };

        function secondLevelGroupNames(data, ifall) {
            var allGroups = {};
            var anyOneGroup = [];
            try {
                var level1groups = firstLevelGroupNames(data);
                //            console.log("level 1 grouping in secondLevelGrp fn: ");
                //            console.log(level1groups);
                for (var i = 0; i < data.groupingsDown.groupings.length; i++) {
                    anyOneGroup = [];
                    if (typeof data.groupingsDown.groupings[i].groupings != "undefined") {
                        for (var j = 0; j < data.groupingsDown.groupings[i].groupings.length; j++) {
                            anyOneGroup.push(data.groupingsDown.groupings[i].groupings[j].value);
                        }
                    }
                    allGroups[level1groups[i]] = anyOneGroup;
                }
                if (ifall) {
                    return allGroups;
                } else {
                    var maxLengthProp = level1groups[0];
                    for (var k = 1; k < level1groups.length; k++) {
                        //                    console.log("for region : "+level1groups[k]+", range of time is of length : "+allGroups[level1groups[k]].length);
                        if (allGroups[level1groups[k]].length > allGroups[maxLengthProp].length) {
                            maxLengthProp = level1groups[k];
                        }
                    }
                    //                console.log("max length of time in secondLevelGrp fn : ");
                    //                console.log(maxLengthProp);
                    //                console.log("data for that is: ");
                    //                console.log(allGroups[maxLengthProp]);
                    return allGroups[maxLengthProp];
                }
            } catch (err) {
                return err;
            }
        };

        function getAggregateInfo(data) {
            try {
                var arrAgr = [];
                for (var i = 0; i < data.reportMetadata.aggregates.length; i++) {
                    arrAgr.push(data.reportExtendedMetadata.aggregateColumnInfo[data.reportMetadata.aggregates[i]].label);
                }
                return arrAgr;
            } catch (err) {
                //            console.log("error in getting the aggregate info from report meta data : ");
                //            console.log(err);
                return err;
            }
        };

        return {
            extractData: function (treeObj, data) {
                output = [];
                extractData1(treeObj, data);
                return output;
            },
            firstLevelGroupNames: function (data) {
                return firstLevelGroupNames(data);
            },
            secondLevelGroupNames: function (data, ifall) {
                return secondLevelGroupNames(data, ifall);
            },
            extractAggregates: function (treeObj, data) {
                output = [];
                extractAggregates(treeObj, data);
                return output;
            },
            getAggregateInfo: function (data) {
                return getAggregateInfo(data);
            }
        }

    });