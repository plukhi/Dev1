angular.module('akritivEpa')
    .directive("epaError", ['ChartDimen', 'AppData', 'appConfig', '$rootScope', '$timeout',
    function (ChartDimen, AppData, appConfig, $rootScope, $timeout) {
            var linkIt = function (scope, elem) {
                //alert('inside epaError directive and the TYPE is: ' + scope.type);
                //        console.log('message from parent about error is: ' + scope.msg);
                var attr;
                if (scope.zoomcol) {
                    //            console.log("zooming column chart is true");
                    elem.height(ChartDimen.slaRegionZoom.height);
                    elem.width(ChartDimen.slaRegionZoom.width);
                    //            console.log("height of zoomed column chart is : "+ChartDimen.slaRegionZoom.height);
                } else if (scope.zoomarea) {
                    //            console.log("zooming area chart is true");
                    elem.height(ChartDimen.slaTimeZoom.height);
                    elem.width(ChartDimen.slaTimeZoom.width);
                    //            console.log("height of zoomed area chart is : "+ChartDimen.slaTimeZoom.height);
                    //        }
                    //        if (scope.zoom) {
                    //            console.log("zooming chart is true");
                    //            elem.height(ChartDimen.slaRegionZoom.height);
                    //            elem.width(ChartDimen.slaRegionZoom.width);
                    //            console.log("height of zoomed chart is : "+ChartDimen.slaRegionZoom.height);
                } else if (scope.type == 'pie') {
                    elem.height(ChartDimen.slas.height);
                    elem.width(ChartDimen.slas.width);
                } else if (scope.type == 'slaTime') {
                    elem.height(ChartDimen.slatime.height);
                    elem.width(ChartDimen.slatime.width);
                } else if (scope.type == 'slaReg') {
                    elem.height(ChartDimen.slaregion.height);
                    elem.width(ChartDimen.slaregion.width);
                }
                appConfig.reportCounts = appConfig.reportCounts + 1;
                //                  console.log("in epa error directive and reportcounts = "+appConfig.reportCounts);
                //        console.log("a chart has been formed by epa-error directive for- " + appConfig.reportCounts + " -time");
                if (appConfig.reportCounts == 5) {
                    //            console.log("5 charts have been drawn");
                    var localStatusArray = AppData.setLocal();
                    //console.log("localStatusArray = " + JSON.stringify(localStatusArray));
                    if (localStatusArray[0]) {
                        if (!localStatusArray[1]) {
                            $timeout(function () {
                                appConfig.refreshing = false;
                                $rootScope.$broadcast('showChartsHideLoader', true);
                            }, 1300);
                        } else {
                            appConfig.refreshing = false;
                            $rootScope.$broadcast('showChartsHideLoader', true);
                        }

                    }

                } else {
                    //            console.log("5 charts have not been drawn");
                }
            };
            return {
                restrict: 'E',
                scope: {
                    msg: '=',
                    type: '@',
                    fontColor: '@',
                    fontSize: '@',
                    bgColor: '@',
                    zoom: '=',
                    zoomcol: '=',
                    zoomarea: '=',
                },
                replace: true,
                template: "<div id='epaError' class='epaError'>" +
                    "<p>{{msg}}</p>" +
                    "</div>",
                compile: function (elem, attr) {
                    //alert('inside compile fn of directive');
                    //console.log("attributes in error dir: " + JSON.stringify(attr.type));
                    //            if (attr.type == 'slas') {
                    //                elem.height(ChartDimen.slas.height);
                    //                elem.width(ChartDimen.slas.width);
                    //                // elem.css('line-height', elem.height() + "px");
                    //            } else if (attr.type == 'slaTime') {
                    //                elem.height(ChartDimen.slatime.height);
                    //                elem.width(ChartDimen.slatime.width);
                    //                //elem.css('line-height', elem.height() + "px");
                    //            } else if (attr.type == 'slaReg') {
                    //                elem.height(ChartDimen.slaregion.height);
                    //                elem.width(ChartDimen.slaregion.width);
                    //                // elem.css('line-height', elem.height() + "px");
                    //            }
                    if (typeof attr.height != "undefined" && attr.height != null) {

                        elem.height(attr.height);
                    } else if (typeof attr.width != "undefined" && attr.width != null) {
                        elem.width(attr.width);
                    }

                    return linkIt;
                }
            }
    }
]);