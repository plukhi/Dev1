angular.module('akritivEpa')
    .directive('chart', ['appConfig', '$rootScope', 'AppData', '$timeout', '$parse', '$window',

    function (appConfig, $rootScope, AppData, $timeout, $parse, $window) {
            return {
                restrict: 'E',
                template: '<div class="pieChart" ></div>',
                replace: true,
                link: function (scope, element, attrs) {

                    // Whatch the chart values for changes
                    scope.$watch(attrs.values, function (value, oldValue) {
                        if (!value) {
                            return;
                        }
                        // Parsing the data
                        var chartData = value;
                        var type = attrs.type; // Chart type
                        if (attrs.width)
                            width = parseFloat(attrs.width.replace('%', '')) * (window.innerWidth) / 100;
                        else if (type === 'pie')
                            width = 270;
                        else if (chartData.width) {
                            width = chartData.width;
                        } else
                            width = null;
                        if (attrs.height || chartData.height) {
                            if (chartData.height != null)
                                height = chartData.height;
                            else
                                height = attrs.height;
                        } else if (type === 'pie')
                            height = 270;
                        else
                            height = null;
                        var chartConfig;
                        //                    Highcharts.Axis.prototype.hasData = function() {
                        //                        return this.hasVisibleSeries;
                        //                    }
                        //                    console.log(attrs);
                        var callBackOnClick = {};
                        //                    console.log("typeof attrs.callbackclick : " + attrs.callbackclick);
                        if (type === "pie") {
                            if (typeof attrs.callbackclick != "undefined") {
                                var method = attrs.callbackclick.substring(0, attrs.callbackclick.length - 1);
                                callBackOnClick.click = function (serialNo) {
                                    //                            console.log("in chart directive the value after clicking a tile is : "+serialNo);
                                    //                            console.log("overall method is : "+method +"'"+ serialNo+ "'" + ")");
                                    scope.$eval(method + "'" + serialNo + "'" + ")");
                                }
                            }
                        } else if (type === "column") {
                            if (typeof attrs.callbackclick != "undefined") {
                                var method = attrs.callbackclick.substring(0, attrs.callbackclick.length - 1);
                                callBackOnClick.click = function (serialNo, yVal) {
                                    //                            console.log("in chart directive the value after clicking a tile is : "+serialNo);
                                    console.log("overall method is : " + method + "'" + serialNo + "'" + "," + yVal + ")");
                                    scope.$eval(method + "'" + serialNo + "'" + "," + "'" + yVal + "'" + ")");
                                }
                            }
                        }


                        // Create the chart config with private method
                        if (type === "pie") {
                            //                        console.log("trying to form pie chart");
                            chartConfig = _createPieChart(element, type, width, height, chartData.series, chartData.title, callBackOnClick);
                        } else if (type === "areaspline") {
                            //                        console.log("trying to form areaspline chart");
                            chartConfig = _createAreaSplineChart(element, type, width, height, chartData.xAxis, chartData.yAxis, chartData.series, chartData.title, chartData.plotOptions);
                        } else if (type === 'area') {
                            //                        console.log("trying to form area chart");
                            chartConfig = _createBasicAreaChart(element, type, width, height, chartData.chart.plotBackgroundColor, chartData.xAxis, chartData.yAxis, chartData.series, chartData.title);
                        } else if (type === 'column') {
                            //                        console.log("trying to form column chart");
                            chartConfig = _createColumnChart(element, type, width, height, chartData.chart.plotBackgroundColor, chartData.xAxis, chartData.yAxis, chartData.series, chartData.title, callBackOnClick);
                        }

                        if (chartConfig) {

                            var chart = new Highcharts.Chart(chartConfig, function () {
                                //                            console.log("forming a chart for "+chartConfig.chart.type+" with highchart object as : ");
                                //                            console.log(chartConfig);

                                appConfig.reportCounts = appConfig.reportCounts + 1;
                                //                            console.log("in epa chart directive and reportcounts = "+appConfig.reportCounts);
                                if (appConfig.reportCounts == 5) {
                                    //                                console.log("5 charts have been drawn");
                                    var localStatusArray = AppData.setLocal();
                                    var timeAng = new Date();
                                    if (localStatusArray[0]) {

                                        if (!localStatusArray[1]) {
                                            $timeout(function () {
                                                appConfig.refreshing = false;
                                                $rootScope.$broadcast('showChartsHideLoader', true);
                                            }, 1300);
                                        } else {
                                            appConfig.refreshing = false;
                                            $rootScope.$broadcast('showChartsHideLoader', true);
                                        }

                                    }

                                } else {
                                    //                                console.log("5 charts have not been drawn");
                                }


                            });

                        }


                    });

                }
            };
    }
]);


/*
 * Private Method for creating the PieChart configuration
 *
 * @param {_element} The elemnt the chart is rendered to
 * @param {_type} The chart type (default = pie)
 * @param {_width} Container width
 * @param {_height} Container height
 * @param {_seriesData} The series data for the chart
 * @param {_title} Chart title
 * @return {object} Chart configuration
 */
var _createPieChart = function (_element, _type, _width, _height, _seriesData, _title, _callBackOnClick) {
    //    console.log("Callback Object");
    //    console.log(_callBackOnClick);

    function clickHandler(event) {
        //        console.log("inside click event of highcharts with event object as : ");

        if (this.name == "Exceeds")
            _callBackOnClick.click(0);
        else if (this.name == "Met")
            _callBackOnClick.click(1);
        else if (this.name == "Not Met")
            _callBackOnClick.click(2);
    }

    return {
        chart: {
            renderTo: _element[0],
            type: _type || 'pie',
            width: _width || null,
            height: _height || null,
            plotBackgroundColor: 'rgba(255,255,255,0)',
            plotBorderWidth: null,
            plotShadow: false,
            backgroundColor: null
        },
        title: {
            //removed title so as to show just pie chart without any text
            text: '',
            style: {
                display: 'none'
            }
        },
        tooltip: {
            enabled: false
        },
        size: {
            height: _height,
            width: _width
        },

        plotOptions: {
            pie: {
                allowPointSelect: false,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '{point.percentage:.1f} %'
                },
                showInLegend: true,
                series: {
                    allowPointSelect: true
                },
                point: {
                    events: {
                        click: clickHandler,
                        legendItemClick: clickHandler
                    }
                }
            }
        },
        series: [{
            type: _seriesData.type,
            name: _seriesData.name,
            data: _seriesData.data
        }]
    }
};

/*
 * Private Method for creating the Areaspline Chart configuration
 *
 * @param {_element} The elemnt the chart is rendered to
 * @param {_type} The chart type (default = Areaspline)
 * @param {_width} Container width
 * @param {_height} Container height
 * @param {_seriesData} The data series for the chart
 * @param {_title} Chart title
 * @return {object} Chart configuration
 */
var _createAreaSplineChart = function (_element, _type, _width, _height, _xAxis, _yAxis, _seriesData, _title, _plotOptions) {
    _yAxis.min = 0;
    _yAxis.min = 0;
    return {
        chart: {
            renderTo: _element[0],
            type: _type || 'areaspline',
            height: _height || null,
            width: _width || null,
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false
        },
        title: {
            text: _title
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: '#000'
        },
        xAxis: _xAxis,
        yAxis: _yAxis,
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        size: {
            height: _height,
            width: _width
        },
        plotOptions: {
            //area : _plotOptions.area,
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: _seriesData
    };
};

var _createBasicAreaChart = function (_element, _type, _width, _height, _plotBackgroundColor, _xAxis, _yAxis, _seriesData, _title) {

    /* Little Hack to set width Dynamically for Drawing Chart */
    _width = parseInt(angular.element(_element[0]).parent()[0].offsetWidth) - 3;
    _xAxis.labels = {
        rotation: -45,
        useHTML: true,
        style: {
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
        }

    };
    //    _yAxis.minRange = 20;
    //    _yAxis.maxRange = '';
    _yAxis.min = 0;
    //  alert(JSON.stringify(_yAxis));

    function clickHandler(event) {
        //        console.log("inside click event of highcharts with event object as : ");
        //        console.log(this.name);
        //        if (this.name == "Exceeds")
        //            _callBackOnClick.click(0);
        //        else if (this.name == "Met")
        //            _callBackOnClick.click(1);
        //        else if (this.name == "Not Met")
        //            _callBackOnClick.click(2);
    }

    return {
        chart: {
            renderTo: _element[0],
            type: _type || 'area',
            height: _height || null,
            width: _width || null,
            backgroundColor: _plotBackgroundColor || null,
            plotBorderWidth: null,
            plotShadow: false,
            spacing: [10, 30, 30, 30],
            style: {
                fontColor: 'rgb(190,196,196)'
            }
        },
        title: {
            //removed title so as to show just pie chart without any text
            text: '',
            style: {
                display: 'none'
            }
        },
        xAxis: _xAxis,
        yAxis: _yAxis,
        tooltip: {
            shared: true,
            valueDecimals: 1,
            pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: <b>{point.y} %</b><br/>'
        },
        credits: {
            enabled: false
        },
        size: {
            height: _height,
            width: _width
        },
        plotOptions: {
            area: {

                pointInterval: 24 * 3600 * 1000 * 30, // one month
                fillOpacity: 0.1,
                pointStart: 0,
                dataLabels: {
                    enabled: false,
                },
                showInLegend: false,

                marker: {
                    lineColor: null,
                    lineWidth: 2,
                    symbol: 'circle',
                    radius: 7,
                    fillColor: '#FFFFFF',
                },
                point: {
                    events: {
                        click: clickHandler,
                        legendItemClick: clickHandler
                    }
                }
            }
        },
        series: _seriesData
    };
};

var _createColumnChart = function (_element, _type, _width, _height, _plotBackgroundColor, _xAxis, _yAxis, _seriesData, _title, _callBackOnClick) {
    /* Little Hack to set width Dynamically for Drawing Chart */
    _width = parseInt(angular.element(_element[0]).parent()[0].offsetWidth) - 3;
    _xAxis.labels = {
        rotation: -45,
        useHTML: true,
        style: {
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
        }
    };

    function clickHandler(event) {
        //        console.log("inside click event of highcharts with event object as : ");
        // console.log(Object.keys(this));
        //        console.log(this.category);//returns the name of region...will be used as filter
        _callBackOnClick.click(this.category, this.series.name);
    }

    return {
        chart: {
            renderTo: _element[0],
            type: _type || 'area',
            height: _height || null,
            width: _width || null,
            backgroundColor: _plotBackgroundColor || null,
            plotBorderWidth: null,
            plotShadow: false,
            spacing: [10, 30, 0, 30]
        },
        title: {
            //removed title so as to show just pie chart without any text
            text: '',
            style: {
                display: 'none'
            }
        },
        legend: {
            y: 0,
            x: 10,
            padding: 10,
            itemMarginTop: -18,
            itemMarginBottom: 11,
            rtl: true,
            itemStyle: {
                lineHeight: '1px',
                fontWeight: 'normal',
                color: 'rgb(133,137,137)',
                fontSize: '10px'
            }
        },
        tooltip: {
            shared: true,
            valueDecimals: 1,
            pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: <b>{point.y} %</b><br/>'
        },
        symbolHeight: 10,
        symbolWidth: 10,
        xAxis: _xAxis,
        yAxis: _yAxis,
        credits: {
            enabled: false
        },
        size: {
            height: _height,
            width: _width
        },
        plotOptions: {
            column: {
                dataLabels: {
                    enabled: false,
                },
                pointPadding: 0,
                borderWidth: 0,
                point: {
                    events: {
                        click: clickHandler,
                        legendItemClick: clickHandler
                    }
                }
            }
        },
        series: _seriesData
    }
}
