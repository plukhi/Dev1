angular.module('akritivEpa')
    .directive('infiniteScroll', function () {
        return {
            restrict: 'A',
            link: function ($scope, element, attrs) {
                //            console.log("inside infinite scroll directive");
                var myElement = element[0];
                element.bind('scroll', function () {
                    if (myElement.scrollTop + myElement.offsetHeight > myElement.scrollHeight - 2) {
                        $scope.increaseLimit();
                        $scope.$apply();
                    }
                });
            }
        };
    });