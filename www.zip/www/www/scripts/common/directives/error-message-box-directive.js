angular.module('akritivEpa')
    .directive("errorMsgBox", ['appConfig', '$interval', '$rootScope', 'errorModule',
    function (appConfig, $interval, $rootScope, errorModule) {
            return {
                restrict: "E",
                scope: {},
                replace: true,
                template: "<div class='errorMsgBox' ng-show='errorShown'>{{ message }}</div>",
                link: function (scope, elem, attr) {
                    scope.errorShown = false;
                    var stop;
                    $rootScope.$on("showErrorEvent", function (e, d) {
                        if (errorModule.queueLength() > 0 && scope.errorShown == false) {
                            changeMessage();
                            stop = $interval(function () {
                                changeMessage();
                            }, 3000);

                        }
                    });

                    function changeMessage() {
                        if (errorModule.queueLength() > 0) {
                            scope.errorShown = true;
                            scope.message = errorModule.getNextErrorMsg();
                        } else {
                            scope.errorShown = false;
                            $interval.cancel(stop);
                        }
                    }

                }
            }
    }
]);