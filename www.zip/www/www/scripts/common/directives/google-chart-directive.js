/**
 * Creator : Deepak
 * Function : directive for the google charts
 */
angular.module('akritivEpa')
    .directive('googleChart', function ($compile, $filter) {
        return {
            scope: {
                type: '&type',
                id: '&id',
                callbackClickEvent: '&',
                screen: '=screen',
                chartMeta: '&chartMeta',
                chartCounter: '@'
            },
            link: function (scope, elem, attrs) {
                var chartMeta = scope.chartMeta();
                var options = chartMeta.chartData.options;
                var data = chartMeta.chartData.data;
                console.log(chartMeta);
                for (var i = 0; i < data.cols.length; i++) {
                    data.cols[i].id = i + 1;
                }
                scope.id = scope.id() ? scope.id() : 'googleChart';
                scope.type = scope.type() ? scope.type() : 'column';
                var template = "<div id='" + scope.id + "' style='width:100px'></div>";
                var compiledTemplate = $compile(template);
                elem.append(compiledTemplate(scope));
                var chartDataObj = null;

                var chartObj = null;
                buildChart();
                drawChart(chartDataObj, options);
                var customisedOptions;


                /**
                 * CREATOR : DEEPAK
                 * FUNCTION : Function to build chart obj
                 * DATE : 20-01-2016
                 */
                function buildChart() {
                    chartDataObj = new google.visualization.DataTable();
                    angular.forEach(data.cols, function (column) {
                        chartDataObj.addColumn(column);
                    });


                    for (var i = 0; i < data.rows.length; i++) {
                        var row = data.rows[i];
                        var rowArr = [];
                        for (var j = 0; j < row.c.length; j++) {
                            var singleElem = row.c[j];
                            if (data.cols[j].type == 'string' && chartMeta.dateFormat) {
                                if (new Date(singleElem.v) && new Date(singleElem.v) != 'Invalid Date' && (singleElem.v.indexOf('-') != -1 || singleElem.v.indexOf('/') != -1)) {
                                    var filteredDate = $filter('date')(new Date(singleElem.v), chartMeta.dateFormat);
                                    rowArr.push(filteredDate);
                                } else {
                                    rowArr.push(singleElem.v);
                                }
                            } else {
                                rowArr.push(singleElem.v);
                            }

                        }
                        chartDataObj.addRow(rowArr);
                    }

                    console.log(chartDataObj);
                }
                /**
                 * CREATOR : DEEPAK
                 * FUNCTION : Handles options provided to customize the chart
                 * DATE : 20-01-2016
                 */
                function getCustomisedChartOptions(availableOptions, chartType) {
                    var options = availableOptions;
                    if (chartType) {
                        var cType = chartType.toLowerCase();
                        if (cType == 'pie' || cType == 'pie3d' || cType == 'donut') {
                            options.chartArea = {
                                alignment: 'center',
                                width: '85%',
                                height: '65%',
                                top: '20'
                            };
                        } else {
                            options.chartArea = {
                                alignment: 'center',
                                width: '75%',
                                height: '55%',
                                top: '20'
                            };
                        }
                        if (cType == 'pie' && !options.slices) {
                            if (!options.slices) {
                                options.slices = {
                                    0: {
                                        color: 'rgb(86, 194, 64)'
                                    },
                                    1: {
                                        color: 'rgb(26, 162, 226)'
                                    },
                                    2: {
                                        color: 'rgb(222, 88, 82)'
                                    }
                                };
                            }
                        } else if (cType == 'pie3d') {
                            options.is3D = true;
                            if (!options.slices) {
                                options.slices = {
                                    0: {
                                        color: 'rgb(86, 194, 64)'
                                    },
                                    1: {
                                        color: 'rgb(26, 162, 226)'
                                    },
                                    2: {
                                        color: 'rgb(222, 88, 82)'
                                    }
                                };
                            }

                        } else if (cType == 'donut') {
                            if (!options.slices) {
                                options.slices = {
                                    0: {
                                        color: 'rgb(86, 194, 64)'
                                    },
                                    1: {
                                        color: 'rgb(26, 162, 226)'
                                    },
                                    2: {
                                        color: 'rgb(222, 88, 82)'
                                    }
                                };
                            }
                            options.pieHole = 0.3;
                        }
                    }
                    /* 
                     * Creater : Brahm Singh
                     * New custom style for chart
                     */
                    if (options.legend) {
                        options.legend.position = 'bottom';
                    }

                    options.tooltip = {
                        trigger: 'none'
                    };

                    //setting date format
                    options.format = chartMeta.dateFormat;


                    // horrizontal axis options
                    if (!options.hAxis) {
                        options.hAxis = {};
                    }
                    options.hAxis.slantedText = true;
                    options.hAxis.slantedTextAngle = 45;
                    options.hAxis.textStyle = {
                        fontSize: '12',
                        // marginLeft: '100'
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',

                    };
                    options.hAxis.dateFormat = chartMeta.dateFormat;

                    // vertical axis options
                    if (!options.vAxis) {
                        options.vAxis = {};
                    }
                    options.vAxis.slantedText = true;
                    options.vAxis.viewWindowMode = 'explicit';
                    options.vAxis.slantedTextAngle = 20;

                    console.log(options);
                    return options;
                }
                /**
                 * CREATOR : DEEPAK 
                 * Function : Handles click event - returns chart id, selected column and selected row
                 * DATE : 20-01-2016
                 */
                function handleChartClickEvent() {
                    console.log(chartDataObj);

                    var selectedItemArr = chartObj.getSelection();
                    if (selectedItemArr[0]) {
                        var colIndex = selectedItemArr[0].column;
                        var rowIndex = selectedItemArr[0].row;
                    }
                    var value = chartDataObj.getValue(rowIndex, 0)
                    var dataType = chartDataObj.getColumnType(0);
                    //getting selected label
                    if (colIndex) {
                        var role = chartDataObj.getColumnProperty(colIndex, 'role');
                        if (role && role != '' && role.toLowerCase() == 'annotation') {
                            var selectedLabel = chartDataObj.getColumnLabel(colIndex - 1);
                        } else
                            selectedLabel = chartDataObj.getColumnLabel(colIndex);
                    } else {
                        selectedLabel = "";
                    }

                    chartObj.setSelection();
                    scope.callbackClickEvent({
                        'chartId': scope.id,
                        'selectedObj': {
                            'colIndex': colIndex,
                            'rowIndex': rowIndex,
                            'value': value,
                            'dataType': dataType,
                            'columnLabel': selectedLabel,
                            'currentlySelectedColumn': colIndex ? colIndex : 1
                        }
                    });
                }
                /**
                 * CREATOR : DEEPAK
                 * FUNCTION :draws chart
                 * DATE : 20-01-2016
                 */
                function drawChart(data, options) {
                    chartObj = getChartObject(scope.type);
                    google.visualization.events.addListener(chartObj, 'select', handleChartClickEvent);
                    //                    if (scope.type.toLowerCase() == "column") {
                    //                        console.log(data);
                    //                    }
                    console.log("counter " + scope.chartCounter * 100);
                    setTimeout(function () {
                        chartObj.draw(data, getCustomisedChartOptions(options, scope.type));
                    }, scope.chartCounter * 400);

                }

                /**
                 * CREATOR : DEEPAK
                 * FUNCTION :based on chart type selected, creates google chart visualization
                 * DATE : 20-01-2016
                 */
                function getChartObject(_type) {
                    var returnVal;
                    if (_type == "area") {
                        returnVal = new google.visualization.AreaChart(elem[0]);
                    } else if (_type == "bar" || _type == "bars") {
                        returnVal = new google.visualization.BarChart(elem[0]);
                    } else if (_type == "pie") {
                        returnVal = new google.visualization.PieChart(elem[0]);
                    } else if (_type == "column") {
                        returnVal = new google.visualization.ColumnChart(elem[0]);
                    } else if (_type == "line") {
                        returnVal = new google.visualization.LineChart(elem[0]);
                    } else if (_type == "combo") {
                        returnVal = new google.visualization.ComboChart(elem[0]);
                    } else if (_type == "donut") {
                        returnVal = new google.visualization.PieChart(elem[0]);
                    } else if (_type == "table") {
                        returnVal = new google.visualization.Table(elem[0]);
                    } else if (_type == "stackedcolumn") {
                        returnVal = new google.visualization.ColumnChart(elem[0]);
                    } else if (_type == "pie3d")
                        returnVal = new google.visualization.PieChart(elem[0]);
                    else if (_type == "gauge")
                        return Val = new google.visualization.Gauge(elem[0]);
                    else if (_type == "histogram")
                        return Val = new google.visualization.Histogram(elem[0]);
                    return returnVal;
                }
            }
        }
    });