angular.module('akritivEpa')
    .filter('formatDate', function () {
        return function (input) {
            return moment(input).format('DD-MM-YYYY | HH:mm') + ' hrs';
        };
    });