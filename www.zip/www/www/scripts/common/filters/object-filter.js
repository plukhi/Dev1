/**
 * Creator : Deepak 3-1-16
 * Filters object - pass objects those are in key value format, and filter condition
 * Similar to angular's filter but filters objects with key value instead of array 
 * Application usage : for metrics and summarized metrics screen filtering
 */
angular.module('akritivEpa')
    .filter('objectFilter', function () {
        return function (objectsArr, filterCondition) {
            var filteredObjects = {};
            angular.forEach(objectsArr, function (value, key) {
                var isConditionMet = true;
                for (k in filterCondition) {
                    if (value[k] && value[k] != filterCondition[k]) {
                        isConditionMet = false;
                    }
                }
                if (isConditionMet) {
                    filteredObjects[key] = value;
                }
            });
            return filteredObjects;
        }
    });
