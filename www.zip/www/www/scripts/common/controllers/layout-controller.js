angular.module('akritivEpa')
    .controller('layoutController', ['$scope', '$state', '$rootScope', '$ionicSideMenuDelegate', '$timeout', 'notificationService', 'EPAMetaDataService', 'appConfig', function ($scope, $state, $rootScope, $ionicSideMenuDelegate, $timeout, notificationService, EPAMetaDataService, appConfig) {

        $scope.isAlreadyOpen = false;
        $scope.currentRightView = 'null';
        $scope.currentVersion = appConfig.currentVersion;
        $scope.selectedView = 'D';

        /*
         * Creator : Brahm 
         * Function : handles chanage in view from left menu
         */
        $scope.changeView = function (view) {
            console.log(view);
            console.log($scope.selectedView);
            if ($scope.selectedView == 'D' && view == 'D') {
                console.log("selected view = view");
                EPAMetaDataService.selectedDashboard = EPAMetaDataService.defaultDashboard;
                $scope.$broadcast('refresh');
            } else if ($scope.selectedView != view) {
                $scope.selectedView = view;
                //                if ($scope.selectedView == 'H') {
                //                    $state.go('epa.home');
                //                }
                if ($scope.selectedView == 'D') {
                    EPAMetaDataService.selectedDashboard = EPAMetaDataService.defaultDashboard;
                    $state.go('epa.dashboard');
                }

                if ($scope.selectedView == 'M') {
                    $state.go('epa.metrics');
                }
                
                if ($scope.selectedView == 'V') {
                    $state.go('epa.vpmodel');
                }


            }

        };

        function redirect(view) {
            if (view == 'M') {
                $state.go('epa.metrics');
            } else if (view == 'D') {
                $state.go('epa.dashboard');
            } else if (view == 'H') {
                $state.go('epa.home');
            } else if (view == 'V') {
                $state.go('epa.vpmodel');
            }
        }

        /**
         * Creator : Deepak
         * function : handles change in left menu  
         */
        $scope.$on('changeView', function (event, viewName) {
            $scope.selectedView = viewName;
            if (viewName)
                redirect(viewName);
        });

        /**
         * Creator : Deepak
         * Function : Refresh event is generated from here
         */
        $scope.refreshPage = function () {
            console.log('refresh called');
            $scope.$broadcast('refresh');

        };
        $scope.toggleLeftMenu = function () {
            $ionicSideMenuDelegate.toggleLeft();
        };

        /**
         * Creator : Deepak 
         * Function Toggles right menu
         */
        $scope.toggleRightMenu = function (viewName, event) {
            console.log("toggle right menu called " + viewName);
            if ($ionicSideMenuDelegate.isOpenRight()) {
                if ($scope.currentRightView != viewName) {
                    $scope.currentRightView = viewName
                } else {
                    $scope.isAlreadyOpen = false;
                    $ionicSideMenuDelegate.toggleRight();
                }
            } else {
                $ionicSideMenuDelegate.toggleRight();
                $scope.isAlreadyOpen = true;
                $scope.currentRightView = viewName
            }
            console.log($scope.currentRightView);
        };

        $scope.closeMenuNow = function () {
            console.log("called");
            closeRightMenu = true;
        }

    }]);