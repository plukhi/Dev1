angular.module('akritivEpa').controller('alertsController', ['$scope', 'notificationService', function ($scope, notificationService) {
    $scope.isDataLoaded = false;
    init();

    function init() {
        notificationService.getAlertsList().then(function (alertsList) {
            $scope.alerts = alertsList;
            $scope.isDataLoaded = true;
        }, function (error) {
            $scope.isDataLoaded = true;
            $scope.error = error;
        });
    }
    }]);