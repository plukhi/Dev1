angular.module('akritivEpa').controller('NotificationsCtrl', function ($scope, $stateParams, notificationService) {
    $scope.isDataLoaded = false;

    init();

    function init() {
        notificationService.getNotificationsList().then(function (notifications) {
            $scope.notifications = notifications;
            $scope.isDataLoaded = true;
        }, function (error) {
            $scope.isDataLoaded = true;
            $scope.isErrorInLoading = true;
            $scope.error = errr;
        });
    }
});