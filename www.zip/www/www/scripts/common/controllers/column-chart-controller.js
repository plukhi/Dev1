angular.module('akritivEpa')
    .controller('columnChart', ['$scope', 'Reports', '$localStorage', 'getLocalJSON', 'appConfig', 'SLAbyRegion', '$rootScope', '$timeout', 'AppData', 'errorModule', '$state', '$window',
    function ($scope, Reports, $localStorage, getLocalJSON, appConfig, SLAbyRegion, $rootScope, $timeout, AppData, errorModule, $state, $window) {

            $scope.timePeriod = 'quarter';
            $scope.showLoader = true;
            $scope.errorSlaReg = false;
            $scope.errorMsg = "Data is unavailable for this chart.";
            var reportIds = [];
            $scope.pieMargin = {
                "margin-top": -5 + "%"
            };
            $rootScope.buttonbar = {
                "height": "51px"
            }
            if (typeof appConfig.settings == "undefined") {
                reportIds[0] = "noId";
                reportIds[1] = "noId";
                reportIds[2] = "noId";
            } else {

                if (typeof appConfig.settings['barDash-month'] == "undefined")
                    reportIds[0] = "noId";
                else
                    reportIds[0] = appConfig.settings['barDash-month'].reportId;

                if (typeof appConfig.settings['barDash-quarter'] == "undefined")
                    reportIds[1] = "noId";
                else
                    reportIds[1] = appConfig.settings['barDash-quarter'].reportId;

                if (typeof appConfig.settings['barDash-year'] == "undefined")
                    reportIds[2] = "noId";
                else
                    reportIds[2] = appConfig.settings['barDash-year'].reportId;
            }
            //$scope.$on('createColChart',function(event,data){
            //console.log("getting column chart data");
            //        var $scope.tabName = data1.groupingsDown.groupings[0].groupings[0].groupings[0].label;
            // console.log("month -" + reportIds[0] + "year- " + reportIds[2]);
            $scope.tabName = [];

            if (appConfig.demoMode) {
                getLocalJSON.fetchJSON(reportIds[1], "false").then(function (data) {
                        $scope.tabName.push(data.groupingsDown.groupings[0].groupings[0].groupings[0].label);
                        var dataQuarter = data;

                        //                    console.log('in error for quarterly data with reportId = ' + reportIds[1]);
                        getLocalJSON.fetchJSON(reportIds[0], "false").then(function (data) {
                                $scope.tabName.push(data.groupingsDown.groupings[0].groupings[0].groupings[0].label);
                                saveRepMetaData(data);
                                getLocalJSON.fetchJSON(reportIds[2], "false").then(function (data) {
                                    $scope.tabName.push(data.groupingsDown.groupings[0].groupings[0].groupings[0].label);
                                    saveRepMetaData(data);
                                    slaByReg(dataQuarter);
                                }, function (error) {
                                    $scope.errorMsg = errorModule.throwException(error);
                                    //                                console.log('receiving deffered.reject');
                                    //                                if (error)
                                    //                                    console.log('error: server was not hit');
                                    //                                if ($scope.timePeriod == 'year')
                                    $scope.errorSlaReg = true;
                                });
                            },
                            // error handling when ajax request fails for getting monthly sla trends by region
                            function (error) {
                                $scope.errorMsg = errorModule.throwException(error);
                                //                            console.log('receiving deffered.reject');
                                //                            if (error)
                                //                                console.log('error: server was not hit');
                                //                            if ($scope.timePeriod == 'month')
                                $scope.errorSlaReg = true;
                            });

                    },
                    // error handling when ajax request fails for getting quarterly sla trends by region
                    function (error) {
                        $scope.errorMsg = errorModule.throwException(error);
                        //                    console.log('receiving deffered.reject');
                        //                    if (error)
                        //                        console.log('error: server was not hit');
                        //                    if ($scope.timePeriod == 'quarter') 
                        $scope.errorSlaReg = true;

                    });
            } else {
                //            console.log("report ids in sla over region: " + reportIds[0] + ", " + reportIds[1] + ", " + reportIds[2]);
                Reports.fetchJSON(reportIds[1], "false").then(function (data) {
                        //dataReg.quarter = data;
                        //                    console.log("in success of sla trend by region (bar-quarter)");
                        if (typeof data.groupingsDown.groupings[0].groupings[0].groupings[0] != "undefined")
                            $scope.tabName.push(data.groupingsDown.groupings[0].groupings[0].groupings[0].label);
                        else
                            $scope.tabName.push("Quarter");
                        saveRepMetaData(data, 'barDash-quarter');
                        var dataQuarter = data;
                        Reports.fetchJSON(reportIds[0], "false").then(function (data) {
                                //                            console.log("in success of sla trend by region (bar-month)");
                                //                            console.log(JSON.stringify(data));
                                if (typeof data.groupingsDown.groupings[0].groupings[0].groupings[0] != "undefined")
                                    $scope.tabName.splice(0, 0, data.groupingsDown.groupings[0].groupings[0].groupings[0].label);
                                else
                                    $scope.tabName.splice(0, 0, "Month");
                                saveRepMetaData(data, 'barDash-month');
                                Reports.fetchJSON(reportIds[2], "false").then(function (data) {
                                        //                                    console.log("in success of sla trend by region (bar-year)");
                                        //                                    console.log(JSON.stringify(data));
                                        if (data.groupingsDown.groupings.length > 0) {
                                            if (typeof data.groupingsDown.groupings[0].groupings[0].groupings[0] != "undefined")
                                                $scope.tabName.push(data.groupingsDown.groupings[0].groupings[0].groupings[0].label);
                                            else
                                                $scope.tabName.push("Year");
                                            saveRepMetaData(data, 'barDash-year');
                                            slaByReg(dataQuarter);
                                        } else {
                                            $scope.tabName.push("Year");
                                            saveRepMetaData(data, 'barDash-year');
                                            slaByReg(dataQuarter);
                                        }
                                    },
                                    function (error) {
                                        //                                    console.log("error received for sla trend by region(bar-year)");
                                        $scope.tabName.push("Year");
                                        //                                    $scope.errorMsg = errorModule.throwException(error);
                                        //                                    if (error)
                                        //                                        console.log('error: server was not hit');
                                        //                                    if ($scope.timePeriod == 'year')
                                        //                                    $scope.errorSlaReg = true;
                                        slaByReg(dataQuarter);
                                    });
                            },
                            // error handling when ajax request fails for getting monthly sla trends by region
                            function (error) {
                                //                            console.log("error received for sla trend by region(bar-month)");
                                $scope.tabName.push("Year")
                                $scope.tabName.splice("Month", 0, 0);
                                //                            $scope.errorMsg = errorModule.throwException(error);
                                //                            if (error)
                                //                                console.log('error: server was not hit');
                                //                            if ($scope.timePeriod == 'month')
                                //                            $scope.errorSlaReg = true;
                                slaByReg(dataQuarter);
                            });

                    },
                    // error handling when ajax request fails for getting quarterly sla trends by region
                    function (error) {
                        //                    console.log("error received for sla trend by region(bar-quarter)");
                        $scope.tabName = ["Month", "Quarter", "Year"];
                        $scope.errorMsg = errorModule.throwException(error);
                        //                    console.log('receiving deffered.reject');
                        //                    if (error)
                        //                        console.log('error: server was not hit');
                        //                    if ($scope.timePeriod == 'quarter') 
                        $scope.errorSlaReg = true;

                    });
            }

            /*function to save Reportmeta data in AppData and localStorage with key as rMetaData_uniqueName*/
            function saveRepMetaData(data, uniqueName) {
                var getString = "rMetaData_" + uniqueName;
                if (AppData.get(getString) == null) {
                    AppData.set(getString, data.reportMetadata, true);
                } else {

                }
            }

            $scope.changeState = function (serialNum, yVal) {
                //            console.log("a callback function on the click of pie chart in controller from directive with serial num : " + serialNum);

                //            console.log("params for state.go : ");
                console.log("serialNum, yVal" + serialNum + "," + yVal)
                var btn;
                var reportIdUniqueName = function () {
                    if ($scope.timePeriod == 'month') {
                        btn = 1;
                        return 'barDash-month'
                    } else if ($scope.timePeriod == 'quarter') {
                        btn = 2;
                        return 'barDash-quarter'
                    } else if ($scope.timePeriod == 'year') {
                        btn = 3;
                        return 'barDash-year'
                    }
                }();

                $state.go("epa.homeSummarizedMetrics", {
                    id: serialNum,
                    sla: serialNum,
                    component: reportIdUniqueName,
                    btn: btn,
                    lable: yVal

                });
                //            console.log(serialNum + " ; " + serialNum + " ; " + reportIdUniqueName + " ; " + btn + " ; ");
            }


            $scope.zoomCol = false;
            $scope.zoomColFn = function (yes) {
                var containHeight = $window.innerHeight;
                if (yes) {
                    $rootScope.tileHeightColumn = {
                        "height": (containHeight * 0.945) + "px",

                    };
                    $scope.pieMargin = {
                        "margin-top": 0 + "%"
                    }
                    $rootScope.buttonbar = {
                        "height": "74px"
                    }

                } else {
                    $rootScope.tileHeightColumn = {
                        "height": (containHeight * 0.43) + "px"
                    };
                    $scope.pieMargin = {
                        "margin-top": -5 + "%"
                    }
                    $rootScope.buttonbar = {
                        "height": "51px"
                    }
                }
                $scope.zoomCol = yes;
                $scope.errorSlaReg = false;
                $scope.$emit('zoomColt', yes);
                getTimeChartData($scope.timePeriod);

            }

            $scope.columnChartChange = function (timePeriod) {
                $scope.timePeriod = timePeriod;
                //            whichTimeChart(timePeriod);
                getTimeChartData(timePeriod);
            }

            var getTimeChartData = function (timePeriod) {
                //            console.log("in get time chart data with timeperiod : " + timePeriod);
                $scope.showLoader = true;
                var reportId = "noId";
                if ($scope.timePeriod == 'month')
                    reportId = reportIds[0];
                else if ($scope.timePeriod == 'quarter')
                    reportId = reportIds[1];
                else if ($scope.timePeriod == 'year')
                    reportId = reportIds[2];

                if (appConfig.demoMode) {
                    getLocalJSON.fetchJSON(reportId).then(function (data) {
                        slaByReg(data);
                        $scope.showLoader = false;
                    }, function (error) {
                        //                    console.log('error: server was not hit');
                        $scope.errorMsg = errorModule.throwException(error);
                        $scope.errorSlaReg = true;
                    });
                } else {
                    Reports.fetchJSON(reportId).then(function (data) {
                        slaByReg(data);
                        $scope.showLoader = false;
                    }, function (error) {
                        //                    console.log('error: server was not hit');
                        $scope.errorMsg = errorModule.throwException(error);
                        $scope.errorSlaReg = true;
                    });
                }
            }

            /**
             *error handling starts
             */
            function handleError(errors) {
                if (errors.noMonthData != "") {
                    //alert("SLA trend over region monthly data not available");
                } else if (errors.noQuarterData != "") {
                    //alert("SLA trend over region quarterly data not available");
                } else if (errors.noYearData != "") {
                    //alert("SLA trend over region yearly data not available");
                }
                if (errors.noCpi != []) {
                    for (var i = 0; i < errors.noCpi.length; i++) {
                        //alert(errors.noCpi[i]);
                    }
                }
                if (errors.noKpi != []) {
                    for (var i = 0; i < errors.noKpi.length; i++) {
                        //alert(errors.noKpi[i]);
                    }
                }

            }

            var results = [];

            function slaByReg(data) {
                //console.log('in sla by reg');
                $scope.errorSlaReg = false;
                results = SLAbyRegion.sanitizeData(data);
                columnNewChart = results[0];
                if ($scope.zoomCol) {
                    columnNewChart.height = 550;
                    columnNewChart.xAxis.labels.rotation = 0;
                } else {
                    // columnNewChart.width = 313;
                    columnNewChart.xAxis.labels.rotation = 70;
                }
                if (results[1])
                    handleError(results[1]);

                /**
                 *error handling
                 *type2 error - server is hitting and coming back with empty data. In this case we have to
                 *handle error and hide loaders even if data is not available
                 **/
                if ($scope.timePeriod == 'quarter' && results[1].noQuarterData != "") {
                    $scope.errorMsg = results[1].noQuarterData;
                    $timeout(function () {
                        $scope.errorSlaReg = true;
                    }, 2);
                    //                console.log("sla by region quarterly data's column chart has not formed");
                } else if ($scope.timePeriod == 'month' && results[1].noMonthData != "") {
                    $scope.errorMsg = results[1].noMonthData;
                    $timeout(function () {
                        $scope.errorSlaReg = true;
                    }, 2);
                    //                console.log("sla by region monthly data's column chart has not formed");
                } else if ($scope.timePeriod == 'year' && results[1].noYearData != "") {
                    $scope.errorMsg = results[1].noYearData;
                    $timeout(function () {
                        $scope.errorSlaReg = true;
                    }, 2);
                    //                 console.log("sla by region yearly data's column chart has not formed");
                }
                // if no error found then form chart
                else {
                    //                console.log(columnNewChart);
                    $scope.columnChart = columnNewChart;
                }
                $scope.$on('showChartsHideLoader', function (event, data) {
                    $scope.showLoader = false;
                });
            }
            $scope.$on('showChartsHideLoader', function (event, data) {
                //console.log('hiding loader of column chart');
                $scope.showLoader = false;
            });

    }
]);
