var appQueries = {
    "demoOrgQueries": {
        "getDashboardsList": {
            "query": "SELECT Id, Name,  asv__ChartSize__c, asv__Description__c,asv__isMobileDefault__c, asv__DeveloperName__c, asv__FilterLogic__c,  asv__Metric__c, asv__TitleColor__c, asv__TitleSize__c, asv__Title__c FROM asv__EPADashboardMeta__c ORDER BY asv__Title__c",
            "params": {
                "id": "Id",
                "name": "Name",
                "chartSize": "asv__ChartSize__c",
                "description": "asv__Description__c",
                "isDefault": "asv__isMobileDefault__c",
                "developerName": "asv__DeveloperName__c",
                "filterLogic": "asv__FilterLogic__c",
                "metric": "asv__Metric__c",
                "titleColor": "asv__TitleColor__c",
                "titleSize": "asv__TitleSize__c",
                "title": "asv__Title__c"
            }
        },
        "getDashboardMetaData": {
            "query": "Select Id, Name, asv__ChartType__c, asv__ChartDataFormat__c, asv__DataSource__c, asv__DecimalPlaces__c, asv__DrillDownTo__c,asv__DateDisplayFormat__c , asv__GridPosition__c, asv__GroupingColumn__c, asv__hAxisOptions__c, asv__LegendPosition__c, asv__ReportUniqueName__c, asv__ShowValues__c,asv__SortField__c, asv__ShowTimeRangeFilter__c, asv__vAxisOptions__c ,asv__VerticalAxisTitle__c , asv__TooltipConfig__c , asv__Title__c from asv__EPADashboardChartMeta__c where asv__EPADashboardMeta__r.asv__DeveloperName__c ='/developerName/'",
            "params": {
                "id": "Id",
                "name": "Name",
                "chartType": "asv__ChartType__c",
                "chartDataFormat": "asv__ChartDataFormat__c",
                "dataSoruce": "asv__DataSource__c",
                "decimalPlaces": "asv__DecimalPlaces__c",
                "drillDownTo": "asv__DrillDownTo__c",
                "groupingColumn": "asv__GroupingColumn__c",
                "hAxisOptions": "asv__hAxisOptions__c",
                "gridPosition": "asv__GridPosition__c",
                "dateFormat": "asv__DateDisplayFormat__c",
                "legendPosition": "asv__LegendPosition__c",
                "reportUniqueName": "asv__ReportUniqueName__c",
                "showValues": "asv__ShowValues__c",
                "sortField": "asv__SortField__c",
                "vAxisOptions": "asv__vAxisOptions__c",
                "verticalAxisTitle": "asv__VerticalAxisTitle__c",
                "toolTipConfig": "asv__TooltipConfig__c",
                "title": "asv__Title__c"
            }
        },
        "getDashboardFilters": {
            "query": "SELECT asv__DisplayName__c, asv__FieldName__c, Id, Name, asv__Operator__c, asv__Type__c FROM asv__EPADashboardFilter__c where asv__EPADashboardMeta__c = '/dashboardId/'",
            "params": {}
        },
        "getAlerts": {
            "query": "SELECT Id, asv__Message__c, asv__MetricName__c,asv__Month__c,Name,OwnerId,asv__ReportDate__c FROM asv__SlaAlert__c",
            "params": {
                "id": "Id",
                "message": "asv__Message__c",
                "metric": "asv__MetricName__c",
                "month": "asv__Month__c",
                "name": "Name",
                "ownerId": "OwnerId",
                "reportDate": "asv__ReportDate__c"
            }
        },
        "chartsAPIPath": {
            "query": "/services/apexrest/asv/EPAWSChartData?dbnm="
        },
        "dashboardMetaDataPath": {
            "query": "/services/apexrest/asv/EPAWSChartDetailMobile?dbnm="
        },
        "getMetrics": {
            "query": "SELECT Id, asv__MetricNumber__c , asv__DashboardUniqueName__c,asv__DisplayName__c, asv__OperationalDescription__c,asv__Process__c,asv__SubProcess__c FROM asv__Metric__c where asv__Active__c = true order by asv__MetricNumber__c",
            "params": {
                "id": "Id",
                "dashboardUniqueName": "asv__DashboardUniqueName__c",
                "displayName": "asv__DisplayName__c",
                "description": "asv__OperationalDescription__c",
                "process": "asv__Process__c",
                "subProcess": "asv__SubProcess__c",
                "metricName": "asv__MetricNumber__c"
            }
        },
        "getChartDrillDownURL": {
            "query": "services/apexrest/asv/EPAWSReportDrill?"
        }
    },
    "devOrgQueries": {
        "getDashboardsList": {
            "query": "SELECT Id, Name,  ChartSize__c, Description__c,isMobileDefault__c, DeveloperName__c, FilterLogic__c,  Metric__c, TitleColor__c, TitleSize__c, Title__c FROM EPADashboardMeta__c ORDER BY Title__c",
            "params": {
                "id": "Id",
                "name": "Name",
                "chartSize": "ChartSize__c",
                "description": "Description__c",
                "isDefault": "isMobileDefault__c",
                "developerName": "DeveloperName__c",
                "filterLogic": "FilterLogic__c",
                "metric": "Metric__c",
                "titleColor": "TitleColor__c",
                "titleSize": "TitleSize__c",
                "title": "Title__c"
            }
        },
        "getDashboardMetaData": {
            "query": "Select Id, Name, ChartType__c, ChartDataFormat__c, DataSource__c, DecimalPlaces__c, DrillDownTo__c, DateDisplayFormat__c , GridPosition__c, GroupingColumn__c, hAxisOptions__c, LegendPosition__c, ReportUniqueName__c, ShowValues__c, SortField__c, ShowTimeRangeFilter__c, vAxisOptions__c , VerticalAxisTitle__c , TooltipConfig__c , Title__c from EPADashboardChartMeta__c where EPADashboardMeta__r.DeveloperName__c ='/developerName/'",
            "params": {
                "id": "Id",
                "name": "Name",
                "chartType": "ChartType__c",
                "chartDataFormat": "ChartDataFormat__c",
                "dataSoruce": "DataSource__c",
                "decimalPlaces": "DecimalPlaces__c",
                "drillDownTo": "DrillDownTo__c",
                "groupingColumn": "GroupingColumn__c",
                "hAxisOptions": "hAxisOptions__c",
                "gridPosition": "GridPosition__c",
                "dateFormat": "DateDisplayFormat__c",
                "legendPosition": "LegendPosition__c",
                "reportUniqueName": "ReportUniqueName__c",
                "showValues": "ShowValues__c",
                "sortField": "SortField__c",
                "vAxisOptions": "vAxisOptions__c",
                "verticalAxisTitle": "VerticalAxisTitle__c",
                "toolTipConfig": "TooltipConfig__c",
                "title": "Title__c"
            }
        },
        "getDashboardFilters": {
            "query": "SELECT DisplayName__c, FieldName__c, Id, Name, Operator__c, Type__c FROM EPADashboardFilter__c where EPADashboardMeta__c = '/dashboardId/'",
            "params": {}
        },
        "getAlerts": {
            "query": "SELECT Id, Message__c, MetricName__c, Month__c, Name, OwnerId, ReportDate__c FROM SlaAlert__c",
            "params": {
                "id": "Id",
                "message": "Message__c",
                "metric": "MetricName__c",
                "month": "Month__c",
                "name": "Name",
                "ownerId": "OwnerId",
                "reportDate": "ReportDate__c"
            }
        },
        "chartsAPIPath": {
            "query": "/services/apexrest/EPAWSChartData?dbnm="
        },
        "dashboardMetaDataPath": {
            "query": "/services/apexrest/EPAWSChartDetailMobile?dbnm="
        },
        "getMetrics": {
            "query": "SELECT Id, MetricNumber__c, DashboardUniqueName__c,DisplayName__c, OperationalDescription__c,Process__c,SubProcess__c FROM Metric__c where Active__c=true order by MetricNumber__c",
            "params": {
                "id": "Id",
                "dashboardUniqueName": "DashboardUniqueName__c",
                "displayName": "DisplayName__c",
                "description": "OperationalDescription__c",
                "process": "Process__c",
                "subProcess": "SubProcess__c",
                "metricName": "asv__MetricNumber__c"
            }
        },
        "getChartDrillDownURL": {
            "query": "services/apexrest/EPAWSReportDrill?"
        }
    }
};