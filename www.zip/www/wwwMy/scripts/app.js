// Deliinova Demo App

/* Authentication Logic to be Called Before Angular Bootstrap
 * Blocks the UI Thread as the SFOAuth Plugin runs in the Main Thread
 */

/*
 * Start of Angular Specific Code
 */

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'akritivEpa' is the name of this angular module example (also set in a <body> attribute in index.html)

function OnDeviceReady() {
    navigator.splashscreen.hide();
}

document.addEventListener("deviceready", OnDeviceReady, true);

angular.module('delinnovaDemo', ['delinnovaDemo.login'])
    .value('appConfiguration', {
        'appQueries': {}
    })
    /**
     * TODO : -- NOT IN USE - TO BE TAKEN CARE LATER
     */
    .value('appConfig', {
        currentVersion: "2.1.8",
        refreshing: false,
        themes: {
            "bright-theme": {
                "red": "#de5852",
                "blue": "#1aa2e2",
                "green": "#56c240",
                "chartBgColor": "#e4f0f5",
                "darkblue": "#0a4f6c"
            },
            "standard": {
                "red": "#E0574D",
                "blue": "#0B89C6",
                "green": "#16BFC2"
            }
        },
        selectedTheme: "bright-theme"
    })


.run(function ($ionicPlatform, $state, appConfig, $rootScope, $localStorage, $location, $urlRouter, AppData, ServerConfig, $state, revokeToken, $ionicPopup, $ionicHistory, EPAMetaDataService, dashboardMetaDataService, appConfiguration) {

    $rootScope.isOnline = function () {
        console.log(navigator.onLine);
        return navigator.onLine;
        //        return navigator.connection.type != 'none';
    };


    $ionicPlatform.registerBackButtonAction(function (event) {
        event.preventDefault();
    }, 100);

    var screenwidth = screen.width;
    if (screenwidth > 414) {
        $rootScope.isIpad = true;
        $rootScope.landscape = false;
        $rootScope.dist = -30;
    } else {
        $rootScope.isIpad = false;
        $rootScope.landscape = true;
        $rootScope.dist = -16;
    }
    var isDemoOrg = true;
    if (isDemoOrg) {
        $rootScope.isDemoOrg = true;
        appConfiguration.setQueries(appQueries.demoOrgQueries);
    } else {
        $rootScope.isDemoOrg = false;
        appConfiguration.setQueries(appQueries.devOrgQueries);
    }
    var now = new Date();
    $rootScope.currentTime = now;

    $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
        var stateName = toState.name.toLowerCase();
        if (stateName == 'login') {
            /*
               Clear the all history and refresh the whole page
               Created by Brahm on 23rd Feb-2016
            */

            $ionicHistory.clearHistory();
            $ionicHistory.clearCache();
            EPAMetaDataService.refreshData();
            dashboardMetaDataService.refreshData();
        } else
        if (stateName == 'epa.dashboard' || stateName == 'epa.metrics' || stateName == 'epa.vpmodel') {
            $rootScope.isLeftMenuToDisplay = true;
        } else {
            $rootScope.isLeftMenuToDisplay = false;
        }

        if (stateName == 'epa.dashboard') {
            $rootScope.showRefresh = true;
        } else {
            $rootScope.showRefresh = false;
        }
    });
    $rootScope.retry = function () {
        $rootScope.errorFound = false;
        $rootScope.errMsg = "";
        $state.go("login");
    }

    $rootScope.logout = function () {
        var logoutPopup = $ionicPopup.confirm({
            // title: 'Logout',
            cssClass: 'logOutpop',
            template: 'Are you sure you want to logout?',
            okType: 'button-calm logout-btn',
            cancelType: 'button-outline button-stable'

        });
        logoutPopup.then(function (res) {
            if (res) {
                revokeToken.removeToken().then(function (data) {
                    $rootScope.errorFound = false;
                    $rootScope.errMsg = "";
                    AppData.reset();
                    $state.go("login");
                }, function (e) {
                    $rootScope.errorFound = false;
                    $rootScope.errMsg = "";
                    AppData.reset();
                    $state.go("login");
                });
            } else {}

        });
    }


})



.config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
    $ionicConfigProvider.backButton.previousTitleText(false);
    $ionicConfigProvider.backButton.icon('ion-chevron-left');
    $ionicConfigProvider.views.swipeBackEnabled(false);
    $ionicConfigProvider.backButton.text('')
    $stateProvider
        .state('login', {
            cache: false,
            url: '/epalogin',
            templateUrl: 'scripts/login/views/loginView.html',
            controller: 'loginCtrl',

        })
        .state('loading', {
            url: '/loading',
            templateUrl: 'scripts/dashboard/views/loading.html',
            controller: 'LoadingCtrl',
            cache: false,
        })
        .state('epa', {
            cache: false,
            url: '/epa',
            views: {
                '': {
                    templateUrl: 'scripts/common/views/layout.html',
                    controller: 'layoutController'
                },
                'notificationsView@epa': {
                    templateUrl: 'scripts/common/views/notifications.html',
                    controller: 'NotificationsCtrl'
                },
                'alertsView@epa': {
                    templateUrl: 'scripts/common/views/alerts.html',
                    controller: 'alertsController'
                },
                'alertAndNotificationsView@epa': {
                    templateUrl: 'scripts/common/views/alerts-and-notification-view.html'
                }
            }
        })

    .state('epa.dashboard', {
            url: '/dashboard',
            cache: false,
            views: {
                'bodyView': {
                    templateUrl: 'scripts/dashboard/views/dashboard-view.html',
                    controller: 'dashboardController'
                },
                'dashboardcharts@epa.dashboard': {
                    templateUrl: 'scripts/dashboard/views/dash-charts.html',
                    controller: 'dashboardChartsController'
                }
            }
        })
        .state('epa.summarizedMetrics', {
            url: '/summarizedMetrics/ :reportId /:isSummaryView / :filters / :title',
            views: {
                'bodyView': {
                    templateUrl: 'scripts/summarized-metrics/views/summarized-metrics.html',
                    controller: 'summarizedMetricsController'
                },
                'filtersView@epa.summarizedMetrics': {
                    templateUrl: 'scripts/dashboard/views/dash-charts.html',
                    controller: 'dashboardChartsController'
                }
            }
        })
        .state('epa.metrics', {
            url: '/metrics',
            views: {
                'bodyView': {
                    templateUrl: 'scripts/metrics/views/metric.html',
                    controller: 'metricsController'
                }
            }
        })
        .state('epa.vpmodel', {
            url: '/vpmodel',
            views: {
                'bodyView': {
                    templateUrl: 'scripts/vpmodel/views/vpmodel.html',
                    controller: 'VPModelController'
                }
            }
        })
    $urlRouterProvider.otherwise('/epalogin');

});

angular.module('akritivEpa')
    .factory('appConfiguration', function () {
        var self = this;
        var appQueries = {};
        self.setQueries = function (queries) {
            appQueries = queries;
        };
        self.getQueries = function () {
            return appQueries;
        };
        return self;
    });